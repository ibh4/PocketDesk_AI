# RetroSyn 逆合成分析工具 — 一日开发全记录

> 2026-04-26

## 项目概述

从零构建桌面逆合成分析工具：PySide6 + RDKit，支持分子逆合成路线规划、3D可视化、AI辅助分析。

## 上午：初始构建

- Python 3.11 venv 环境
- 核心依赖：PySide6 6.11.0, rdkit-pypi, httpx, PyTorch
- 桌面双击启动（macOS .app bundle）

## 中午：AI API 接入

- 接入 MiMo 大模型 API
- 思考模式会消耗大量 reasoning_tokens，需 max_tokens=4096
- 从 reasoning_content 回退提取 JSON 的容错逻辑

## 下午：五个方向迭代

| # | 方向 | 状态 | 说明 |
|---|------|------|------|
| 1 | AiZynthFinder | ❌ | 需TensorFlow+2GB权重，下载太慢 |
| 2 | 分子生成升级 | ✅ | PyTorch + transformers |
| 3 | 3D可视化 | ✅ | 3Dmol.js HTML交互式 |
| 4 | Graphviz逆合成树 | ✅ | dot渲染PNG |
| 5 | HTML报告导出 | ✅ | Jinja2模板，暗色主题 |

- 产率预测系统：20+种反应类型查表
- 反应路线图渲染：分子base64 PNG + 箭头 + 产率标签

## 傍晚：架构文档

- 完整技术架构报告（17KB）和Mermaid流程图
- 推送到 Obsidian 知识库

## 晚上：GUI大改

- 逆合成方法从3种扩充到 **13种**：
  - BRICS / 官能团 / 命名反应18种 / 环切断 / FGI / 骨架 / 6种专项模板
- GUI配色从深色改为亮色主题（白底黑字红蓝强调）
- 分子图尺寸减半（400×300→200×150）
- 默认SMILES设为阿司匹林

---

## AI4S Agent CNS 挑战赛

### 比赛任务
- 靶向分子研发与合成规划智能体
- 总分 = 分子评分×0.7 + 路线评分×0.3

### 评分体系
- 分子: binding(0.8) + validity(0.1) + SA(0.1) — validity=0则归零
- 路线: route_validity(0.55) + material_avail(0.30) + 其他(0.15)
- 一票否决：路线产物≠设计分子 / 原子凭空出现 / balance=0

### 排行榜分析
- 第1名: 0.840分, 只提交1个分子, binding=0.829
- 第2名: 0.690分, 提交50个分子, binding=0.553
- **结论：质量 > 数量，binding_score 占总分56%是核心战场**

### Agent 开发进展
- AutoDock Vina 对接工具已安装
- **PDBQT格式关键发现**: 79列精确格式，需要固定宽度列对齐
- Agent流水线：受体准备→口袋检测→分子生成→Vina对接→路线规划→CSV输出
- 3轮迭代优化（30→50→80分子）
- 最终输出43个分子

### 参考论文启发
1. **Coscientist** (Nature 2023, CMU) — GPT-4主控，4种命令模块，代码Docker隔离执行
2. **MOSAIC** (Nature 2026, Yale) — 2498个专家，反应指纹RSFP，成功率71%
