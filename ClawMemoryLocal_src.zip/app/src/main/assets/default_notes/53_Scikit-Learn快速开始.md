# Scikit-Learn快速开始

> **分类:** 技术工具

---

快速开始 Scikit-Learn｜使用 Scikit-Learn 建立机器学习模型

©️ _Copyright 2023 @ Authors_
 _作者：阙浩辉 📨_
 _日期：2023-05-09_
 _共享协议：本作品采用知识共享署名-非商业性使用-相同方式共享 4.0 国际许可协议进行许可。_

🎯 本教程旨在 _快速掌握_ 使用 scikit-learn 建立机器学习模型的范式周期。

一键运行，你可以快速在实践中检验你的想法。
 丰富完善的注释，对于入门者友好。

在 Bohrium Notebook 界面，你可以点击界面上方蓝色按钮 `开始连接`，选择 `bohrium-notebook` 镜像及任何一款节点配置，稍等片刻即可运行。

> 了解 Scikit-Learn 在建立机器学习模型中的基础功能，并能够使用 Scikit-Learn 的范式快速建立机器学习模型。

使用 Scikit-Learn 快速创建某一类型的数据或加载现有数据。
 对数据进行预处理，例如归一化与标准化，以及快速划分数据集。
 进行特征选择的一些方法，例如过滤法、包装法及嵌入法。
 使用 Scikit-Learn 的范式快速建立机器学习模型。
 使用 sklearn.metric 来评价模型质量。
 使用交叉验证以及自动查找最佳的评估器参数。

阅读该教程【最多】约需 30 分钟，让我们开始吧！

背景
 实践
 1 认识 Scikit-Learn
 1.1 什么是 Scikit-Learn
 1.2 安装 Scikit-Learn【Bohrium 中可直接运行，无需安装】
 1.3 验证安装并查看 Scikit-Learn 版本
 2 Scikit-Learn 方法
 2.1 提供数据集
 2.1.1 自建数据集
 2.1.2 使用 Scikit-Learn 提供的数据集
 ……
