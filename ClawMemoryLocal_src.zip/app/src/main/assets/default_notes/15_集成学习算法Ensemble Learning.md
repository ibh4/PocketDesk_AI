# 集成学习算法Ensemble Learning

> **分类:** 专业技术

---

集成学习算法 (Ensemble Learning)

集成学习算法 (Ensemble Learning)

分类: 机器学习 / 字数: 10102 / 标签: 集成学习, Ensemble Learning, Bagging, Bootstrap Aggregating, Boosting, 模型融合, Averaging, Voting, Stacking, Stacked Generalization, 随机森林, Random Forest, Adaboost, 梯度提升, Gradient Boosting, GBDT, GBM, GBRT, MART, XGBoost, LightGBM, Gradient-based One-Side Sampling, GOSS, Exclusive Feature Bundling, EFB, Level-wise Tree Growth, Depth-wise Tree Growth, Leaf-wise Tree Growth, Best-first Tree Growth, CatBoost

传统机器学习算法 (例如：决策树，人工神经网络，支持向量机，朴素贝叶斯等) 的目标都是寻找一个最优分类器尽可能的将训练数据分开。集成学习 (Ensemble Learning) 算法的基本思想就是将多个分类器组合，从而实现一个预测效果更好的集成分类器。集成算法可以说从一方面验证了中国的一句老话：三个臭皮匠，赛过诸葛亮。

Thomas G. Dietterich 1 2 指出了集成算法在统计，计算和表示上的有效原因：

一个学习算法可以理解为在一个假设空间 H 中选找到一个最好的假设。但是，当训练样本的数据量小到不够用来精确的学习到目标假设时，学习算法可以找到很多满足训练样本的分类器。
