# 预测算法Baseline机器学习

> **分类:** 技术工具

---

import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = "SimHei" #解决中文乱码问题

import seaborn as sns

from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

from sklearn.preprocessing import LabelEncoder

from sklearn.metrics import accuracy_score

from sklearn import model_selection

from sklearn.neighbors import KNeighborsRegressor

df_train = pd.read_csv(r'C:\Users\gaohao\Downloads\data_format1\train_format1.csv') df_test = pd.read_csv(r'C:\Users\gaohao\Downloads\data_format1\test_format1.csv') user_info = pd.read_csv(r'C:\Users\gaohao\Downloads\data_format1\user_info_format1.csv')

df_train = pd.read_csv(r'C:\Users\gaohao\Downloads\data_format1\train_format1.csv')

df_test = pd.read_csv(r'C:\Users\gaohao\Downloads\data_forma……
