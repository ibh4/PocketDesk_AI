# RDKit说明书

> **分类:** 技术工具

---

本文档提供了如何使用 RDKit 执行特定任务的示例方法 功能。内容由 RDKit 社区贡献， 使用最新的 RDKit 版本进行了测试，然后编译到本文档中。 RDKit Cookbook 是用 reStructuredText 编写的，它支持 Sphinx 文档测试， 允许在适当的情况下更轻松地验证和维护 RDKit 说明书代码示例。

包含的示例来自各种在线资源，例如博客、共享 gist 和 RDKit 邮件列表。通常，只对 格式一致性并合并 DocTests。我们做出了有意识的努力 适当地注明原始来源和作者。首要任务之一 document 来编译 RDKit 邮件列表上分享的有用的简短 示例，如 这些可能很难发现。这需要一些时间，但我们希望扩大这一点 document 转换为 100 多个示例。随着文档的增长，确定优先级可能是有意义的 RDKit 说明书中包含的示例（基于社区需求）。

如果您有关于如何改进 Cookbook 的建议和/或您想要的示例 包括，请直接在源文档（.rst 文件）中贡献。 或者，您也可以将 Cookbook 修订和添加请求发送到邮件列表： （您需要先订阅）。

索引 ID#（例如，RDKitCB_## ）只是一种跟踪 Cookbook 条目和图像文件名的方法。 新添加的 Cookbook 将按顺序进行索引编号，无论它们放置在何处 在文档中。因此，作为参考，下一个 Cookbook 条目为 RDKitCB_41 。

作者： Takayuki Serizawa

from rdkit import Chem
 from rdkit.Chem.Draw import IPythonConsole
 from rdkit.Chem import Draw
 IPythonConsole.ipython_useSVG=True #
