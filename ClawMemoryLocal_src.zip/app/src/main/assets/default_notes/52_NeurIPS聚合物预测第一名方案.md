# NeurIPS聚合物预测第一名方案

> **分类:** 技术工具

---

NeurIPS - Open Polymer Prediction 2025 第一名方案

NeurIPS - Open Polymer Prediction 2025

Solution Writeup · 1st place · Sep 17, 2025

My solution is an ensemble of BERT, AutoGluon, and Uni-Mol models. I believe the unique aspects that allowed me to win were:

1. Post-processing the predicted glass transition temperatures to account for a distribution shift between the training & leaderboard datasets.
 2. Pretraining the BERT models on a pseudolabeled subset of PI1M.

I also got major gains from training on external labeled datasets and some tabular feature engineering tricks, but doubt those aspects were particularly unique.

Scores for each of the models in my final ensemble are included below. These are _raw_ scores, without the postprocessing trick. All models in the final ensemble were ……
