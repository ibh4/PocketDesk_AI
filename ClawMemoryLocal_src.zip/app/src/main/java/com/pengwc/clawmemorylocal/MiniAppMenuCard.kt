package com.pengwc.clawmemorylocal

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MiniAppMenuCard(
    title: String,
    subtitle: String,
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(84.dp)
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(1.dp, InputBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(44.dp)) {
            icon()
        }
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 15.sp, color = AiTextColor)
            Text(subtitle, fontSize = 12.sp, color = SecondaryTextColor)
        }
    }
}

@Composable
fun WheelIconCanvas() {
    Canvas(modifier = Modifier.size(36.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f
        drawCircle(color = UserBubbleBackground, radius = radius, center = center)
        repeat(6) { index ->
            val angle = index * (2 * PI / 6) - PI / 2
            drawLine(
                color = PrimaryPurple,
                start = center,
                end = Offset(
                    x = center.x + cos(angle).toFloat() * radius,
                    y = center.y + sin(angle).toFloat() * radius,
                ),
                strokeWidth = 2f,
            )
        }
        drawCircle(color = Color.White, radius = radius * 0.28f, center = center)
        drawCircle(color = PrimaryPurple, radius = radius * 0.09f, center = center)
        val pointer = Path().apply {
            moveTo(center.x, 2f)
            lineTo(center.x - 4f, 12f)
            lineTo(center.x + 4f, 12f)
            close()
        }
        drawPath(pointer, color = Color(0xFFEF4444))
    }
}

@Composable
fun PythonIconCanvas() {
    Canvas(modifier = Modifier.size(36.dp)) {
        drawRoundRect(
            color = AppConversationBackground,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f),
        )
        val left = Path().apply {
            moveTo(size.width * 0.36f, size.height * 0.28f)
            lineTo(size.width * 0.20f, size.height * 0.50f)
            lineTo(size.width * 0.36f, size.height * 0.72f)
        }
        val right = Path().apply {
            moveTo(size.width * 0.64f, size.height * 0.28f)
            lineTo(size.width * 0.80f, size.height * 0.50f)
            lineTo(size.width * 0.64f, size.height * 0.72f)
        }
        drawPath(left, color = PrimaryPurple, style = Stroke(width = 4f, cap = StrokeCap.Round))
        drawPath(right, color = PrimaryPurple, style = Stroke(width = 4f, cap = StrokeCap.Round))
        drawLine(
            color = SecondaryTextColor,
            start = Offset(size.width * 0.44f, size.height * 0.74f),
            end = Offset(size.width * 0.56f, size.height * 0.26f),
            strokeWidth = 3f,
            cap = StrokeCap.Round,
        )
    }
}

@Composable
fun FileSearchIconCanvas() {
    Canvas(modifier = Modifier.size(36.dp)) {
        val folder = Path().apply {
            moveTo(size.width * 0.14f, size.height * 0.34f)
            lineTo(size.width * 0.36f, size.height * 0.34f)
            lineTo(size.width * 0.44f, size.height * 0.24f)
            lineTo(size.width * 0.84f, size.height * 0.24f)
            lineTo(size.width * 0.84f, size.height * 0.68f)
            lineTo(size.width * 0.14f, size.height * 0.68f)
            close()
        }
        drawPath(folder, color = Color.White)
        drawPath(folder, color = PrimaryPurple, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(
            color = Color.White,
            radius = size.minDimension * 0.12f,
            center = Offset(size.width * 0.68f, size.height * 0.64f),
        )
        drawCircle(
            color = PrimaryPurple,
            radius = size.minDimension * 0.12f,
            center = Offset(size.width * 0.68f, size.height * 0.64f),
            style = Stroke(width = 2.4f),
        )
        drawLine(
            color = PrimaryPurple,
            start = Offset(size.width * 0.76f, size.height * 0.72f),
            end = Offset(size.width * 0.88f, size.height * 0.84f),
            strokeWidth = 2.4f,
            cap = StrokeCap.Round,
        )
    }
}
