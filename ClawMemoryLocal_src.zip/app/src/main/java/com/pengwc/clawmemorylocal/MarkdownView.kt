package com.pengwc.clawmemorylocal

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownView(
    markdown: String,
    modifier: Modifier = Modifier,
    textColorHex: String = "#111827",
    backgroundColorHex: String = "#F8FAFC",
    onImportPythonCode: ((String) -> Unit)? = null,
    onRunPythonCode: ((String) -> Unit)? = null,
) {
    val blocks = rememberMarkdownBlocks(markdown)
    val context = LocalContext.current
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        blocks.forEach { block ->
            when (block) {
                is MarkdownBlock.Heading -> {
                    val fontSize = when (block.level) {
                        1 -> 21.sp
                        2 -> 19.sp
                        else -> 17.sp
                    }
                    Text(
                        text = block.text,
                        color = AiTextColor,
                        fontSize = fontSize,
                        lineHeight = (fontSize.value + 7).sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }

                is MarkdownBlock.ListItem -> {
                    Text(
                        text = buildInlineMarkdown("• ${block.text}"),
                        color = AiTextColor,
                        lineHeight = 24.sp,
                        fontSize = 15.sp,
                    )
                }

                is MarkdownBlock.Code -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFFDBEAFE), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (onImportPythonCode != null && block.canImportToPython()) {
                                Row {
                                    Text(
                                        text = block.languageLabel(),
                                        color = SecondaryTextColor,
                                        fontSize = 11.sp,
                                    )
                                    Spacer(Modifier.weight(1f))
                                    if (onRunPythonCode != null) {
                                        OutlinedButton(
                                            onClick = { onRunPythonCode(block.text.trimEnd()) },
                                        ) {
                                            Text("运行", fontSize = 12.sp, color = PrimaryPurple)
                                        }
                                    }
                                    OutlinedButton(
                                        onClick = { onImportPythonCode(block.text.trimEnd()) },
                                    ) {
                                        Text("导入", fontSize = 12.sp, color = PrimaryPurple)
                                    }
                                }
                            }
                            Text(
                                text = block.text.trimEnd(),
                                color = Color(0xFF0F172A),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                lineHeight = 20.sp,
                            )
                        }
                    }
                }

                is MarkdownBlock.Paragraph -> {
                    Text(
                        text = buildInlineMarkdown(block.text),
                        color = AiTextColor,
                        lineHeight = 24.sp,
                        fontSize = 15.sp,
                    )
                }

                is MarkdownBlock.Blockquote -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF0FDF4), RoundedCornerShape(8.dp))
                            .border(width = 3.dp, color = Color(0xFF86EFAC))
                            .padding(12.dp),
                    ) {
                        Text(
                            text = buildInlineMarkdown(block.text),
                            color = AiTextColor,
                            lineHeight = 22.sp,
                            fontSize = 14.sp,
                        )
                    }
                }

                is MarkdownBlock.HorizontalRule -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(DividerSoft),
                    )
                }

                is MarkdownBlock.ImageBlock -> {
                    var showFullscreen by remember { mutableStateOf(false) }
                    val bmp = remember(block.path) {
                        runCatching { BitmapFactory.decodeFile(block.path) }.getOrNull()
                    }
                    if (bmp != null) {
                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = block.alt,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 120.dp, max = 400.dp)
                                    .clickable { showFullscreen = true },
                            )
                        }
                        if (showFullscreen) {
                            AlertDialog(
                                onDismissRequest = { showFullscreen = false },
                                confirmButton = {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            saveBitmapToGallery(context, bmp)
                                            showFullscreen = false
                                        }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White)) {
                                            Text("保存到相册")
                                        }
                                        Button(onClick = { showFullscreen = false }, colors = ButtonDefaults.buttonColors(containerColor = Color.Gray, contentColor = Color.White)) {
                                            Text("关闭")
                                        }
                                    }
                                },
                                title = null,
                                text = {
                                    Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().heightIn(max = 600.dp))
                                },
                            )
                        }
                    } else {
                        Text(
                            text = "[${block.alt.ifBlank { "图片" }}] " + block.path.takeLast(24),
                            color = SecondaryTextColor,
                            fontSize = 12.sp,
                        )
                    }
                }

                is MarkdownBlock.Table -> {
                    if (block.rows.isEmpty()) return@forEach
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(10.dp))
                            .border(1.dp, DividerSoft, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        verticalArrangement = Arrangement.spacedBy(0.dp),
                    ) {
                        block.rows.forEachIndexed { rowIndex, row ->
                            if (row.isEmpty()) return@forEachIndexed
                            val isHeader = rowIndex == 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isHeader) Color(0xFFF1F5F9) else Color.Transparent)
                                    .padding(horizontal = 2.dp, vertical = 6.dp),
                            ) {
                                row.forEachIndexed { cellIndex, cell ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 4.dp, vertical = 2.dp),
                                    ) {
                                        Text(
                                            text = buildInlineMarkdown(cell),
                                            color = AiTextColor,
                                            fontSize = 13.sp,
                                            fontWeight = if (isHeader) FontWeight.SemiBold else FontWeight.Normal,
                                            lineHeight = 20.sp,
                                            softWrap = true,
                                            maxLines = 8,
                                        )
                                    }
                                }
                            }
                            if (rowIndex < block.rows.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(DividerSoft),
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun looksLikeMarkdownContent(text: String): Boolean {
    val markdownSignals = listOf(
        "```",
        "![",
        "|",
        "> ",
        "---",
        "***",
        "**",
        "__",
        "\n#",
        "\n- ",
        "\n* ",
        "\n1. ",
        "\n2. ",
        "\n3. ",
    )
    if (markdownSignals.any { text.contains(it) }) return true
    if (text.trimStart().startsWith("#")) return true
    if (text.trimStart().startsWith("> ")) return true
    if (text.trimStart().startsWith("- ")) return true
    if (text.trimStart().startsWith("|")) return true
    return false
}

@Composable
private fun rememberMarkdownBlocks(markdown: String): List<MarkdownBlock> {
    return parseMarkdownBlocks(markdown)
}

private fun parseMarkdownBlocks(markdown: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = markdown.replace("\r\n", "\n").split('\n')
    var index = 0
    val paragraphBuffer = mutableListOf<String>()

    fun flushParagraph() {
        if (paragraphBuffer.isNotEmpty()) {
            val text = paragraphBuffer.joinToString("\n").trim()
            if (text.isNotBlank()) blocks += MarkdownBlock.Paragraph(text)
            paragraphBuffer.clear()
        }
    }

    while (index < lines.size) {
        val line = lines[index]
        val trimmed = line.trimEnd()

        if (trimmed.startsWith("```")) {
            flushParagraph()
            val language = trimmed.removePrefix("```").trim().lowercase()
            index++
            val codeLines = mutableListOf<String>()
            while (index < lines.size && !lines[index].trimEnd().startsWith("```")) {
                codeLines += lines[index]
                index++
            }
            val codeText = codeLines.joinToString("\n")
            if (language == "markdown" || language == "md") {
                blocks += parseMarkdownBlocks(codeText)
            } else {
                blocks += MarkdownBlock.Code(language = language, text = codeText)
            }
            if (index < lines.size && lines[index].trimEnd().startsWith("```")) {
                index++
            }
            continue
        }

        if (trimmed.isBlank()) {
            flushParagraph()
            index++
            continue
        }

        val imageMatch = Regex("""^!\[(.*)]\((\S+)\)$""").matchEntire(trimmed)
        if (imageMatch != null) {
            flushParagraph()
            blocks += MarkdownBlock.ImageBlock(
                alt = imageMatch.groupValues[1],
                path = imageMatch.groupValues[2],
            )
            index++
            continue
        }
        val inlineImageMatch = Regex("""!\[(.*)]\((\S+)\)""").find(trimmed)
        if (inlineImageMatch != null) {
            flushParagraph()
            blocks += MarkdownBlock.ImageBlock(
                alt = inlineImageMatch.groupValues[1],
                path = inlineImageMatch.groupValues[2],
            )
            blocks += MarkdownBlock.Paragraph(trimmed.replace(Regex("""!\[.*]\(\S+\)"""), "").trim())
            index++
            continue
        }

        val isTableRow = trimmed.trimStart().startsWith("|") ||
            (trimmed.contains("|") && trimmed.count { it == '|' } >= 2 && !trimmed.startsWith("#") && !trimmed.startsWith(">") && !trimmed.startsWith("- ") && !trimmed.startsWith("```"))
        if (isTableRow) {
            flushParagraph()
            val rawTableLines = mutableListOf<String>()
            rawTableLines += trimmed
            index++
            while (index < lines.size) {
                val next = lines[index].trimEnd()
                if (next.isBlank()) {
                    index++
                    break
                }
                val nextIsTable = next.trimStart().startsWith("|") ||
                    next.matches(Regex("""^[-:| ]+$""")) ||
                    (next.contains("|") && next.count { it == '|' } >= 2 && !next.startsWith("#") && !next.startsWith(">") && !next.startsWith("- ") && !next.startsWith("* ") && !next.startsWith("```"))
                if (nextIsTable) {
                    rawTableLines += next
                    index++
                } else {
                    break
                }
            }
            val tableRows = mutableListOf<List<String>>()
            for (line in rawTableLines) {
                val cells = line
                    .trim()
                    .trimStart('|')
                    .trimEnd('|')
                    .split("|")
                    .map { it.trim() }
                    .filter { it.isNotBlank() || line.startsWith("|") }
                if (cells.isEmpty()) continue
                tableRows += cells
            }
            val sepIndex = tableRows.indexOfFirst { row ->
                row.all { it.matches(Regex("""^[-:]+$""")) }
            }
            if (sepIndex >= 0) tableRows.removeAt(sepIndex)
            if (tableRows.isNotEmpty()) blocks += MarkdownBlock.Table(tableRows)
            continue
        }

        if (trimmed.startsWith("> ")) {
            flushParagraph()
            val quoteLines = mutableListOf<String>()
            while (index < lines.size) {
                val next = lines[index].trimEnd()
                if (next.startsWith("> ")) {
                    quoteLines += next.removePrefix("> ").trim()
                    index++
                } else if (next.isBlank() && index + 1 < lines.size && lines[index + 1].trimEnd().startsWith("> ")) {
                    quoteLines += ""
                    index++
                } else {
                    break
                }
            }
            blocks += MarkdownBlock.Blockquote(quoteLines.joinToString("\n"))
            continue
        }

        if (trimmed.matches(Regex("""^[-*_]{3,}\s*$"""))) {
            flushParagraph()
            blocks += MarkdownBlock.HorizontalRule()
            index++
            continue
        }

        val headingMatch = Regex("^(#{1,4})\\s*(.*)$").matchEntire(trimmed)
        if (headingMatch != null && headingMatch.groupValues[2].isNotBlank()) {
            flushParagraph()
            blocks += MarkdownBlock.Heading(
                level = headingMatch.groupValues[1].length,
                text = headingMatch.groupValues[2].trim(),
            )
            index++
            continue
        }

        val listMatch = Regex("""^([-*]|\d+\.)\s+(.*)$""").matchEntire(trimmed)
        if (listMatch != null) {
            flushParagraph()
            blocks += MarkdownBlock.ListItem(listMatch.groupValues[2].trim())
            index++
            continue
        }

        paragraphBuffer += trimmed
        index++
    }

    flushParagraph()
    return blocks
}

private fun buildInlineMarkdown(text: String): AnnotatedString {
    val regex = Regex("""\*\*(.+?)\*\*""")
    val matches = regex.findAll(text).toList()
    if (matches.isEmpty()) return AnnotatedString(text)
    return buildAnnotatedString {
        var lastIndex = 0
        matches.forEach { match ->
            if (match.range.first > lastIndex) {
                append(text.substring(lastIndex, match.range.first))
            }
            pushStyle(SpanStyle(fontWeight = FontWeight.Bold))
            append(match.groupValues[1])
            pop()
            lastIndex = match.range.last + 1
        }
        if (lastIndex < text.length) {
            append(text.substring(lastIndex))
        }
    }
}

private sealed interface MarkdownBlock {
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class ListItem(val text: String) : MarkdownBlock
    data class Code(val language: String, val text: String) : MarkdownBlock
    data class Paragraph(val text: String) : MarkdownBlock
    data class Table(val rows: List<List<String>>) : MarkdownBlock
    data class Blockquote(val text: String) : MarkdownBlock
    data class HorizontalRule(val text: String = "") : MarkdownBlock
    data class ImageBlock(val alt: String, val path: String) : MarkdownBlock
}

private fun MarkdownBlock.Code.canImportToPython(): Boolean {
    if (language == "python" || language == "py" || language.isBlank()) {
        return looksPythonic(text)
    }
    return false
}

private fun MarkdownBlock.Code.languageLabel(): String {
    return when {
        language.isBlank() -> "代码块"
        language == "py" -> "python"
        else -> language
    }
}

private fun saveBitmapToGallery(context: android.content.Context, bitmap: android.graphics.Bitmap) {
    try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "photo_note_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhotoNotes")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, out)
            }
        }
    } catch (_: Exception) { }
}

private fun looksPythonic(code: String): Boolean {
    val signals = listOf(
        "print(",
        "def ",
        "import ",
        "for ",
        "while ",
        "if ",
        "elif ",
        "else:",
        "class ",
        "return ",
        "len(",
        "range(",
    )
    if (signals.any { code.contains(it) }) return true
    val hasBraces = code.contains("{") || code.contains("}")
    val hasSemicolons = code.contains(";")
    return !hasBraces && !hasSemicolons
}
