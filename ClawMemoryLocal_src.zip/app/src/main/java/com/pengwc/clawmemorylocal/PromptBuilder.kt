package com.pengwc.clawmemorylocal

object PromptBuilder {
    fun build(
        history: List<ChatMessage>,
        userInput: String,
        evidenceMode: Boolean,
        performanceMode: PerformanceMode,
        identityContext: String = "",
        memoryContext: String = "",
        workspaceContext: String = "",
        accessPermissionEnabled: Boolean = false,
    ): PromptBuildResult {
        val truncatedInput = userInput.take(USER_INPUT_CHAR_LIMIT)
        val inputWasTruncated = userInput.length > USER_INPUT_CHAR_LIMIT
        val systemRaw = buildSystemPrompt(
            evidenceMode = evidenceMode,
            identityContext = identityContext,
            memoryContext = memoryContext,
            workspaceContext = workspaceContext,
            accessPermissionEnabled = accessPermissionEnabled,
        )
        val maxSystemChars = (performanceMode.promptCharLimit * 0.75).toInt().coerceAtLeast(2000)
        val system = systemRaw.trim().take(maxSystemChars)
        val userContent = buildString {
            append(truncatedInput)
            append("\n\n请使用简体中文回答。")
        }

        val recentPairs = history
            .filter { it.role == "user" || it.role == "assistant" }
            .takeLast(performanceMode.historyTurns * 2)

        val clipped = mutableListOf<ChatMessage>()
        var totalChars = 0
        for (message in recentPairs.asReversed()) {
            val cleanContent = ThinkContentParser.strip(message.content)
            val length = cleanContent.length
            if (totalChars + length > performanceMode.promptCharLimit) break
            clipped += message.copy(content = cleanContent, thinking = "")
            totalChars += length
        }
        val orderedHistory = clipped.asReversed()
        val messages = buildList {
            add(ChatMessage("system", system.trim()))
            addAll(orderedHistory)
            add(ChatMessage("user", userContent))
        }
        val promptChars = messages.sumOf { it.content.length }
        return PromptBuildResult(
            messages = messages,
            userContent = userContent,
            promptChars = promptChars,
            estimatedTokens = estimateTokens(promptChars),
            historyTurns = orderedHistory.count { it.role == "user" },
            inputWasTruncated = inputWasTruncated,
            performanceMode = performanceMode,
            memoryChars = memoryContext.length,
            workspaceChars = workspaceContext.length,
        )
    }

    private fun estimateTokens(chars: Int): Int = (chars / 1.7f).toInt().coerceAtLeast(1)

    private fun buildSystemPrompt(
        evidenceMode: Boolean,
        identityContext: String,
        memoryContext: String,
        workspaceContext: String,
        accessPermissionEnabled: Boolean,
    ): String {
        val base = if (evidenceMode) LIFE_EVIDENCE_PROMPT else CHINESE_SYSTEM_PROMPT
        return buildString {
            append(base.trim())
            append("\n\n你有一个可持久化的记忆文件 memory.md。每次对话前，系统都会把 memory.md 的内容摘要提供给你。请优先依据其中的内容回答用户关于身份、偏好、长期事项、项目背景的问题。尤其优先参考其中的「关键字段」区和「近期任务 / 待提醒事项」区。不要声称自己没有记忆，除非 memory.md 里确实没有相关信息。")
            if (identityContext.isNotBlank()) {
                append("\n\n以下是必须优先记住的用户身份信息。回答「用户是谁」「用户在哪工作」「用户的长期项目是什么」这类问题时，优先基于这里作答：\n<identity>\n")
                append(identityContext.trim())
                append("\n</identity>")
            }
            append("\n\n回答简洁直接，可以用至多两个表格。每次回复不少于300字，表格后必须有1-2段「下一步建议」，给出具体可执行的后续行动。")
            if (memoryContext.isNotBlank()) {
                append("\n\n以下是你的长期记忆，请仅在相关时引用：\n<memory>\n")
                append(memoryContext.trim())
                append("\n</memory>")
            }
            if (workspaceContext.isNotBlank()) {
                append("\n\n以下是当前辅助上下文摘要，可能来自文件索引或网页搜索结果。只在相关时引用；若其中声明「仅扫描文件名」或「仅包含网页摘要」，则严禁假设完整正文内容：\n<workspace>\n")
                append(workspaceContext.trim())
                append("\n</workspace>")
            }
            if (accessPermissionEnabled) {
                append("\n\n可读取笔记内容（已在workspace中提供）。支持网页搜索、运行Python代码、创建自定义小程序和笔记归档。保存笔记请用：[创建笔记:标题] 内容 [/创建笔记]。")
            } else {
                append("\n\n当前访问权限已关闭，你无法直接访问用户的笔记和日志内容。")
            }
        }
    }
}

fun looksMostlyEnglish(text: String): Boolean {
    val letters = text.count { it in 'A'..'Z' || it in 'a'..'z' }
    val cjk = text.count { it.code in 0x4E00..0x9FFF }
    return letters > 80 && letters > cjk * 2
}
