package com.pengwc.clawmemorylocal

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID
import kotlin.math.max

class FileNameScanRepository(
    context: Context,
    private val logger: AppLogger,
) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("file_search_scan", Context.MODE_PRIVATE)
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val indexDir = File(appContext.filesDir, "PocketDeskAI/file_index")
    private val indexFile = File(indexDir, "filename_index.json")

    @Volatile
    private var cancelRequested = false

    fun requestCancelScan() {
        cancelRequested = true
    }

    suspend fun loadUiState(): FileSearchUiState = withContext(Dispatchers.IO) {
        val uriString = prefs.getString(KEY_TREE_URI, "").orEmpty()
        val payload = readIndexPayload()
        val hasPermission = hasPersistedPermission(uriString)
        val folderName = payload?.rootName.orEmpty().ifBlank {
            if (uriString.isBlank()) "" else DocumentFile.fromTreeUri(appContext, Uri.parse(uriString))?.name.orEmpty()
        }
        val records = payload?.records.orEmpty()
        val display = FileNameSearchEngine.search(records, "", FileSearchFilter.All, FileSearchSort.Name)
        FileSearchUiState(
            folderStatus = when {
                uriString.isBlank() -> "未选择"
                hasPermission -> "已选择"
                else -> "授权失效"
            },
            folderName = folderName,
            folderUri = uriString,
            hasValidPermission = hasPermission,
            fileCount = payload?.fileCount ?: 0,
            folderCount = payload?.folderCount ?: 0,
            lastScannedAt = payload?.scannedAt?.let(FileNameSearchEngine::formatTime).orEmpty(),
            scanTruncated = payload?.truncated ?: false,
            records = records,
            displayRecords = display,
        )
    }

    suspend fun attachFolder(uri: Uri, permissionFlags: Int): FileSearchUiState = withContext(Dispatchers.IO) {
        val persistFlags = permissionFlags and
            (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        runCatching {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                if (persistFlags == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION else persistFlags,
            )
        }
        prefs.edit().putString(KEY_TREE_URI, uri.toString()).apply()
        val name = DocumentFile.fromTreeUri(appContext, uri)?.name.orEmpty()
        logger.fileSearch("选择文件夹：name=${name.ifBlank { "未知" }}")
        loadUiState()
    }

    suspend fun disconnectFolder(): FileSearchUiState = withContext(Dispatchers.IO) {
        val uriString = prefs.getString(KEY_TREE_URI, "").orEmpty()
        if (uriString.isNotBlank()) {
            runCatching {
                appContext.contentResolver.releasePersistableUriPermission(
                    Uri.parse(uriString),
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
        }
        prefs.edit().remove(KEY_TREE_URI).apply()
        logger.fileSearch("断开文件夹授权")
        loadUiState()
    }

    suspend fun clearIndex(): FileSearchUiState = withContext(Dispatchers.IO) {
        if (indexFile.exists()) indexFile.delete()
        logger.fileSearch("清空文件名索引")
        loadUiState()
    }

    suspend fun scan(
        onProgress: (processed: Int, fileCount: Int, folderCount: Int) -> Unit,
    ): FileSearchUiState = withContext(Dispatchers.IO) {
        cancelRequested = false
        val uriString = prefs.getString(KEY_TREE_URI, "").orEmpty()
        if (uriString.isBlank()) return@withContext loadUiState().copy(folderStatus = "未选择")
        val uri = Uri.parse(uriString)
        if (!hasPersistedPermission(uriString)) {
            logger.fileSearch("扫描失败：授权失效")
            return@withContext loadUiState().copy(folderStatus = "授权失效", hasValidPermission = false)
        }
        val root = DocumentFile.fromTreeUri(appContext, uri)
            ?: return@withContext loadUiState().copy(folderStatus = "授权失效", hasValidPermission = false)

        logger.fileSearch("扫描开始：folder=${root.name.orEmpty()} maxFiles=$MAX_FILES maxDepth=$MAX_DEPTH timeoutSec=30")
        val startedAt = System.currentTimeMillis()
        var fileCount = 0
        var folderCount = 0
        var truncated = false
        val records = mutableListOf<FileNameRecord>()

        fun walk(dir: DocumentFile, currentPath: String, depth: Int) {
            if (cancelRequested) return
            if (System.currentTimeMillis() - startedAt > SCAN_TIMEOUT_MS) {
                truncated = true
                return
            }
            if (depth > MAX_DEPTH) {
                truncated = true
                return
            }
            val children = runCatching { dir.listFiles() }.getOrDefault(emptyArray())
            for (child in children) {
                if (cancelRequested) return
                if (System.currentTimeMillis() - startedAt > SCAN_TIMEOUT_MS) {
                    truncated = true
                    return
                }
                val name = child.name ?: continue
                val relativePath = if (currentPath.isBlank()) name else "$currentPath/$name"
                val isDirectory = child.isDirectory
                if (isDirectory) {
                    folderCount += 1
                } else {
                    fileCount += 1
                    if (fileCount > MAX_FILES) {
                        truncated = true
                        return
                    }
                }
                records += FileNameRecord(
                    id = child.uri.toString().ifBlank { UUID.randomUUID().toString() },
                    name = name,
                    relativePath = relativePath,
                    extension = if (isDirectory) "" else name.substringAfterLast('.', "").lowercase(),
                    sizeBytes = max(0L, child.length()),
                    lastModified = max(0L, child.lastModified()),
                    isDirectory = isDirectory,
                    depth = depth,
                    indexedAt = startedAt,
                )
                onProgress(records.size, fileCount, folderCount)
                if (isDirectory && depth < MAX_DEPTH) {
                    walk(child, relativePath, depth + 1)
                }
                if (truncated) return
            }
        }

        walk(root, "", 1)
        if (cancelRequested) {
            logger.fileSearch("扫描取消：processed=${records.size} files=$fileCount folders=$folderCount")
            return@withContext loadUiState().copy(
                isScanning = false,
                scanProgressText = "已取消扫描",
            )
        }

        val payload = FileNameIndexPayload(
            rootUri = uriString,
            rootName = root.name.orEmpty(),
            scannedAt = System.currentTimeMillis(),
            fileCount = fileCount.coerceAtMost(MAX_FILES),
            folderCount = folderCount,
            truncated = truncated,
            records = records,
        )
        indexDir.mkdirs()
        indexFile.writeText(json.encodeToString(payload))
        logger.fileSearch(
            "扫描完成：folder=${payload.rootName.ifBlank { "未知" }} files=${payload.fileCount} folders=${payload.folderCount} truncated=$truncated"
        )
        loadUiState()
    }

    private fun readIndexPayload(): FileNameIndexPayload? =
        if (!indexFile.exists()) null else runCatching {
            json.decodeFromString<FileNameIndexPayload>(indexFile.readText())
        }.getOrNull()

    private fun hasPersistedPermission(uriString: String): Boolean {
        if (uriString.isBlank()) return false
        val target = uriString
        return appContext.contentResolver.persistedUriPermissions.any { it.uri.toString() == target && it.isReadPermission }
    }

    companion object {
        private const val KEY_TREE_URI = "tree_uri"
        const val MAX_FILES = 1000
        const val MAX_DEPTH = 5
        const val SCAN_TIMEOUT_MS = 30_000L
    }
}

