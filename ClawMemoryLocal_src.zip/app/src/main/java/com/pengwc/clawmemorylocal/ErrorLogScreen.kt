package com.pengwc.clawmemorylocal

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun ErrorLogScreen(state: ChatUiState, viewModel: ChatViewModel) {
    val context = LocalContext.current
    ErrorLogScreenContent(
        state = state,
        onRefresh = viewModel::refreshLogs,
        onCopy = { copyText(context, "ClawMemoryLocal 错误日志", state.logs) },
        onShare = { viewModel.shareLogs(context) },
        onClear = viewModel::clearLogs,
    )
}

@Composable
fun ErrorLogScreenContent(
    state: ChatUiState,
    onRefresh: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onClear: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .statusBarsPadding()
            .padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 8.dp),
    ) {
        Row {
            Button(
                onClick = onRefresh,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) { Text("刷新") }
            OutlinedButton(
                onClick = onCopy,
                modifier = Modifier.padding(start = 8.dp),
            ) { Text("复制当前日志", color = PrimaryPurple) }
            OutlinedButton(
                onClick = onShare,
                modifier = Modifier.padding(start = 8.dp),
            ) { Text("分享日志 TXT", color = PrimaryPurple) }
            OutlinedButton(onClick = onClear, modifier = Modifier.padding(start = 8.dp)) {
                Text("清空", color = PrimaryPurple)
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            item { LogBlock("运行日志", state.logSections.runtimePath, state.logSections.runtime) }
            item { LogBlock("模型日志", state.logSections.modelPath, state.logSections.model) }
            item { LogBlock("崩溃日志", state.logSections.crashPath, state.logSections.crash) }
            item { LogBlock("性能日志", state.logSections.performancePath, state.logSections.performance) }
            item { LogBlock("线上 API 日志", state.logSections.onlineApiPath, state.logSections.onlineApi) }
            item { LogBlock("文件检索日志", state.logSections.fileSearchPath, state.logSections.fileSearch) }
            item { LogBlock("Python 日志", state.logSections.pythonPath, state.logSections.python) }
            item { LogBlock("上次退出 Trace", state.logSections.lastExitTracePath, state.logSections.lastExitTrace) }
        }
    }
}

@Composable
private fun LogBlock(title: String, path: String, content: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, color = AiTextColor)
        Text(path.ifBlank { "路径未生成" }, color = SecondaryTextColor)
        Spacer(Modifier.height(6.dp))
        Text(content.ifBlank { "暂无记录" }, color = AiTextColor)
        Spacer(Modifier.height(8.dp))
        HorizontalDivider(color = DividerSoft)
    }
}
