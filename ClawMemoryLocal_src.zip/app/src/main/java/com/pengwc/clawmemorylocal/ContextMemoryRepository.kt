package com.pengwc.clawmemorylocal

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class WorkspaceState(
    val memoryDirPath: String,
    val workspaceFolderName: String = "",
    val workspaceFolderUri: String = "",
    val workspaceSummary: String = "",
    val workspaceFileCount: Int = 0,
)

class ContextMemoryRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("claw_memory_workspace", Context.MODE_PRIVATE)
    private val resolver: ContentResolver = appContext.contentResolver
    private val memoryDir = AppStorage.memoryDir(appContext)
    private val memoryNoteFile = File(AppStorage.noteDir(appContext), MEMORY_NOTE_NAME)
    private val workspaceCacheFile = File(AppStorage.workspaceDir(appContext), "workspace_cache.md")
    private val profileMarker = "<!-- default_profile:pengweichao -->"
    private val taskMarker = "<!-- task_section:default -->"
    private val memoryHeader = """
        |# memory
        |
        |## 用户手动记忆
        |
        |你可以把自己的名字、偏好、长期事项、项目背景直接写在这里。
        |
        |${profileSection().trimEnd()}
        |
        |${taskSection().trimEnd()}
        |
        |## 自动记忆
        |
    """.trimMargin() + "\n"

    suspend fun initialize(): WorkspaceState = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        snapshotState()
    }

    suspend fun snapshotState(): WorkspaceState = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        val uri = getWorkspaceUri()
        if (uri == null) {
            WorkspaceState(
                memoryDirPath = memoryDir.absolutePath,
                workspaceSummary = "未选择项目文件夹",
            )
        } else {
            val folder = DocumentFile.fromTreeUri(appContext, uri)
            WorkspaceState(
                memoryDirPath = memoryDir.absolutePath,
                workspaceFolderName = folder?.name.orEmpty(),
                workspaceFolderUri = uri.toString(),
                workspaceSummary = workspaceCacheFile.takeIf { it.exists() }?.readText().orEmpty().ifBlank { "项目文件夹已连接，等待扫描。" },
                workspaceFileCount = countWorkspaceFiles(folder),
            )
        }
    }

    suspend fun attachWorkspace(uri: Uri): WorkspaceState = withContext(Dispatchers.IO) {
        val flags = IntentFlags.readWriteFlags
        appContext.contentResolver.takePersistableUriPermission(uri, flags)
        prefs.edit()
            .putString(KEY_WORKSPACE_URI, uri.toString())
            .apply()
        refreshWorkspaceCache()
    }

    suspend fun clearWorkspace(): WorkspaceState = withContext(Dispatchers.IO) {
        getWorkspaceUri()?.let { uri ->
            runCatching {
                resolver.releasePersistableUriPermission(uri, IntentFlags.readWriteFlags)
            }
        }
        prefs.edit().remove(KEY_WORKSPACE_URI).apply()
        workspaceCacheFile.writeText("# 项目文件夹缓存\n\n未选择项目文件夹。\n")
        snapshotState()
    }

    suspend fun refreshWorkspaceCache(): WorkspaceState = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        val uri = getWorkspaceUri()
        if (uri == null) return@withContext snapshotState()
        val folder = DocumentFile.fromTreeUri(appContext, uri)
        val summary = buildWorkspaceSummary(folder)
        workspaceCacheFile.writeText(summary)
        snapshotState()
    }

    suspend fun buildMemoryPromptContext(limitChars: Int = 1400): String = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        buildStructuredMemoryContext(limitChars)
    }

    suspend fun buildIdentityPromptContext(limitChars: Int = 700): String = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        val text = memoryNoteFile.readText()
        val keySection = text.substringAfter("### 关键字段", "").substringBefore("### 核心能力", "").trim()
        val focusSection = text.substringAfter("### 当前聚焦方向", "").substringBefore("### 回答风格偏好", "").trim()
        buildString {
            if (keySection.isNotBlank()) {
                append("### 已知用户关键字段\n")
                append(keySection)
                append("\n\n")
            }
            if (focusSection.isNotBlank()) {
                append("### 已知用户当前聚焦方向\n")
                append(focusSection)
            }
        }.take(limitChars).trim()
    }

    suspend fun buildWorkspacePromptContext(limitChars: Int = 1800): String = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        if (!workspaceCacheFile.exists()) return@withContext ""
        workspaceCacheFile.readText().take(limitChars).trim()
    }

    suspend fun answerIdentityQuestion(query: String): String? = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        val fields = readKeyFields()
        val name = fields["姓名"].orEmpty()
        val identity = fields["身份"].orEmpty()
        val residence = fields["常驻地"].orEmpty()
        val project = fields["当前方向"].orEmpty()
        val preference = fields["回答偏好"].orEmpty()
        val normalized = query.trim().replace(Regex("\\s+"), "")

        when {
            normalized in setOf("我是谁", "你记得我是谁吗", "你知道我是谁吗") ->
                buildList {
                    if (name.isNotBlank()) add("你是$name")
                    if (identity.isNotBlank()) add(identity)
                }.takeIf { it.isNotEmpty() }?.joinToString("，")?.plus("。")

            normalized.contains("我叫什么") || normalized.contains("我的名字") ->
                name.takeIf { it.isNotBlank() }?.let { "你的名字是$it。" }

            normalized.contains("我在哪工作") || normalized.contains("我的公司") || normalized.contains("我现在在哪工作") ->
                identity.takeIf { it.isNotBlank() }?.let { "你目前的身份信息是：$it。" }

            normalized.contains("我住哪") || normalized.contains("我常驻哪") || normalized.contains("我在哪个城市") ->
                residence.takeIf { it.isNotBlank() }?.let { "你目前常驻在$it。" }

            normalized.contains("我的长期项目") || normalized.contains("我现在做什么项目") ->
                project.takeIf { it.isNotBlank() }?.let { "你当前长期聚焦的项目包括：$it。" }

            normalized.contains("我的偏好") || normalized.contains("按我的习惯回答") ->
                preference.takeIf { it.isNotBlank() }?.let { "你的回答偏好是：$it。" }

            else -> null
        }
    }

    suspend fun recordTurn(user: String, assistant: String) = withContext(Dispatchers.IO) {
        ensureMemoryFiles()
        val cleanUser = compactText(user, 220)
        val cleanAssistant = compactText(assistant, 320)
        val sections = automaticMemorySections().toMutableList()
        sections += """
            |## ${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}
            |我：$cleanUser
            |助手：$cleanAssistant
        """.trimMargin()
        val trimmed = sections.takeLast(3)
        writeMemoryNote(trimmed)
        if (looksLikeTask(cleanUser)) {
            appendTaskItem(cleanUser)
        }
    }

    private fun automaticMemorySections(): List<String> {
        if (!memoryNoteFile.exists()) return emptyList()
        val text = memoryNoteFile.readText()
        val automaticPart = text.substringAfter("## 自动记忆", "")
        return automaticPart
            .split("\n\n---\n\n")
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    private fun ensureMemoryFiles() {
        AppStorage.ensure(appContext)
        if (!memoryNoteFile.exists()) {
            memoryNoteFile.writeText(memoryHeader)
        } else {
            ensureProfileSection()
        }
        if (!workspaceCacheFile.exists()) workspaceCacheFile.writeText("# 项目文件夹缓存\n\n未选择项目文件夹。\n")
    }

    private fun ensureProfileSection() {
        val current = memoryNoteFile.readText()
        var updated = current
        if (updated.contains(profileMarker)) {
            val start = updated.indexOf(profileMarker)
            val end = when {
                updated.contains(taskMarker) -> updated.indexOf(taskMarker)
                updated.contains("## 自动记忆") -> updated.indexOf("## 自动记忆")
                else -> updated.length
            }
            updated = updated.replaceRange(start, end, profileSection().trimEnd() + "\n\n" + taskSection().trimEnd() + "\n\n")
        } else {
            updated = if (updated.contains("## 用户手动记忆")) {
                updated.replace(
                    "## 用户手动记忆",
                    """
                    |## 用户手动记忆
                    |
                    |${profileSection().trimIndent()}
                    |
                    |${taskSection().trimIndent()}
                    """.trimMargin()
                )
            } else {
                memoryHeader + "\n" + updated
            }
        }
        if (!updated.contains(taskMarker)) {
            updated = if (updated.contains("## 自动记忆")) {
                updated.replace("## 自动记忆", "${taskSection().trimEnd()}\n\n## 自动记忆")
            } else {
                updated.trimEnd() + "\n\n" + taskSection().trimEnd() + "\n"
            }
        }
        memoryNoteFile.writeText(updated)
    }

    private fun profileSection(): String = """
        |$profileMarker
        |### 关键字段
        |
        || 字段 | 内容 |
        || --- | --- |
        || 姓名 | 彭伟超 |
        || 身份 | 中科院博士；芯视界算法工程师 |
        || 常驻地 | 北京 |
        || 方向 | AI for Science、ML、嵌入式、传感器检测 |
        || 偏好 | 简洁直接、先MVP后迭代、多用表格 |
        |
        |### 当前聚焦
        |- AI for Science
        |- 机器学习算法与工程化
        |- 嵌入式开发和软件
        |- 传感器数据检测
        |- 本地AI工作台(ClawMemoryLocal APK)
    """.trimMargin()

    private fun taskSection(): String = """
        |$taskMarker
        |### 近期任务
        |
        || 状态 | 事项 |
        || --- | --- |
        || 进行中 | 优化本地 AI 工作台 APK |
        || 待办 | 完善展示版功能介绍 |
    """.trimMargin()

    private fun writeMemoryNote(automaticSections: List<String>) {
        val current = if (memoryNoteFile.exists()) memoryNoteFile.readText() else memoryHeader
        val manualPart = current.substringBefore("## 自动记忆", current).trimEnd()
        val rebuilt = buildString {
            append(if (manualPart.isBlank()) "# memory\n\n## 用户手动记忆\n\n" else manualPart)
            append("\n\n## 自动记忆\n\n")
            if (automaticSections.isNotEmpty()) {
                append(automaticSections.joinToString("\n\n---\n\n"))
                append("\n")
            }
        }
        memoryNoteFile.writeText(rebuilt)
    }

    private fun buildStructuredMemoryContext(limitChars: Int): String {
        val text = memoryNoteFile.readText()
        val keySection = text.substringAfter("### 关键字段", "").substringBefore("### 核心能力", "").trim()
        val taskSection = text.substringAfter("### 近期任务 / 待提醒事项", "").substringBefore("## 自动记忆", "").trim()
        val autoSection = text.substringAfter("## 自动记忆", "").takeLast(360).trim()
        return buildString {
            if (keySection.isNotBlank()) {
                append("### 关键字段\n")
                append(keySection)
                append("\n\n")
            }
            if (taskSection.isNotBlank()) {
                append("### 近期任务 / 待提醒事项\n")
                append(taskSection)
                append("\n\n")
            }
            if (autoSection.isNotBlank()) {
                append("### 自动记忆摘要\n")
                append(autoSection)
            }
        }.takeLast(limitChars).trim()
    }

    private fun appendTaskItem(taskText: String) {
        val current = memoryNoteFile.readText()
        val sectionHeader = "### 近期任务 / 待提醒事项"
        if (!current.contains(sectionHeader)) return
        val item = "| 待办 | ${escapeTable(taskText.take(80))} | 记录于 ${LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd HH:mm"))} |"
        val section = current.substringAfter(sectionHeader).substringBefore("## 自动记忆")
        if (section.contains(taskText.take(16))) return
        val placeholder = "| 待办 | 暂无 | 你可以手动填写，系统也会自动追加类似“提醒我…”“待办…”“明天…”的事项 |"
        val updatedSection = if (section.contains(placeholder)) {
            section.replace(placeholder, item)
        } else {
            section.trimEnd() + "\n$item\n"
        }
        memoryNoteFile.writeText(current.replace(section, updatedSection))
    }

    private fun compactText(text: String, limit: Int): String =
        ThinkContentParser.strip(text)
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(limit)

    private fun looksLikeTask(text: String): Boolean {
        val keywords = listOf("提醒", "待办", "任务", "记得", "安排", "计划", "明天", "今天", "后天", "下周", "早上", "下午", "晚上")
        return keywords.any { text.contains(it) }
    }

    private fun escapeTable(text: String): String = text.replace("|", "｜")

    private fun readKeyFields(): Map<String, String> {
        val text = memoryNoteFile.readText()
        val keySection = text.substringAfter("### 关键字段", "").substringBefore("### 个人档案", "")
        val result = linkedMapOf<String, String>()
        keySection.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (!line.contains("|")) return@forEach
            val normalized = line.trim('|').trim()
            if (normalized.isBlank()) return@forEach
            val cells = normalized.split("|").map { it.trim() }.filter { it.isNotEmpty() }
            if (cells.size >= 2 && cells[0] != "字段" && cells[0] != "---") {
                result[cells[0]] = cells[1]
            }
        }
        return result
    }

    private fun getWorkspaceUri(): Uri? =
        prefs.getString(KEY_WORKSPACE_URI, null)?.let(Uri::parse)

    private fun countWorkspaceFiles(folder: DocumentFile?): Int {
        if (folder == null || !folder.isDirectory) return 0
        return collectReadableFiles(folder, mutableListOf(), 20).size
    }

    private fun buildWorkspaceSummary(folder: DocumentFile?): String {
        if (folder == null || !folder.isDirectory) return "# 项目文件夹缓存\n\n项目文件夹不可用。\n"
        val files = collectReadableFiles(folder, mutableListOf(), 12)
        val body = buildString {
            appendLine("# 项目文件夹缓存")
            appendLine()
            appendLine("目录：${folder.name.orEmpty()}")
            appendLine("可读文件数：${files.size}")
            appendLine()
            files.forEach { file ->
                val text = readDocumentText(file, 900).trim()
                if (text.isBlank()) return@forEach
                appendLine("## ${file.name.orEmpty()}")
                appendLine(text)
                appendLine()
            }
        }
        return body.ifBlank { "# 项目文件夹缓存\n\n目录中没有可读取的文本文件。\n" }
    }

    private fun collectReadableFiles(folder: DocumentFile, out: MutableList<DocumentFile>, limit: Int): List<DocumentFile> {
        if (out.size >= limit) return out
        folder.listFiles()
            .sortedBy { it.name.orEmpty() }
            .forEach { file ->
                if (out.size >= limit) return@forEach
                if (file.isDirectory) {
                    collectReadableFiles(file, out, limit)
                } else if (isReadableTextFile(file.name.orEmpty())) {
                    out += file
                }
            }
        return out
    }

    private fun isReadableTextFile(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("md", "txt", "json", "xml", "kt", "kts", "yaml", "yml", "log", "csv")
    }

    private fun readDocumentText(file: DocumentFile, maxChars: Int): String {
        return runCatching {
            resolver.openInputStream(file.uri)?.bufferedReader()?.use { reader ->
                val chars = CharArray(maxChars)
                val count = reader.read(chars, 0, maxChars)
                if (count <= 0) "" else String(chars, 0, count)
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun appendWorkspaceMemory(user: String, assistant: String) {
        val uri = getWorkspaceUri() ?: return
        val folder = DocumentFile.fromTreeUri(appContext, uri) ?: return
        val fileName = "ClawMemory_ProjectMemory.md"
        val file = folder.findFile(fileName)
            ?: folder.createFile("text/plain", fileName)
            ?: return
        val previous = readDocumentText(file, 24000)
        val header = if (previous.isBlank()) "# 项目记忆\n\n" else previous.trimEnd() + "\n\n"
        val entry = """
            |## ${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))}
            |我：$user
            |助手：$assistant
            |
            |---
        """.trimMargin()
        writeDocumentText(file, header + entry + "\n")
    }

    private fun writeDocumentText(file: DocumentFile, text: String) {
        runCatching {
            resolver.openOutputStream(file.uri, "rwt")?.bufferedWriter()?.use { it.write(text) }
        }
    }

    private object IntentFlags {
        private const val IntentFlagRead = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        private const val IntentFlagWrite = android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        const val readWriteFlags = IntentFlagRead or IntentFlagWrite
    }

    companion object {
        private const val KEY_WORKSPACE_URI = "workspace_uri"
        const val MEMORY_NOTE_NAME = "memory.md"
    }
}
