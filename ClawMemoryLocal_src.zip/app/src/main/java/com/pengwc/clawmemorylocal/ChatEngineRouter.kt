package com.pengwc.clawmemorylocal

data class ChatEngineReply(
    val text: String,
    val sourceLabel: String,
)

object ChatEngineRouter {
    suspend fun generate(
        mode: ChatMode,
        prompt: PromptBuildResult,
        maxNewTokens: Int,
        logger: AppLogger,
        onPartial: (String) -> Unit,
        model: String = OnlineApiConfig.QWEN_MODEL,
    ): ChatEngineReply {
        return when (mode) {
            ChatMode.Local -> ChatEngineReply(
                text = LocalLlmEngine.generate(prompt, maxNewTokens, logger, onPartial),
                sourceLabel = "本地千问",
            )
            ChatMode.LocalPlusOnline -> {
                val text = QwenOnlineEngine.generate(prompt, logger, model)
                onPartial(text)
                ChatEngineReply(text = text, sourceLabel = "线上千问")
            }
        }
    }
}
