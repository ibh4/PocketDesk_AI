package com.pengwc.clawmemorylocal

import kotlinx.coroutines.delay

object TypewriterRenderer {

    data class Chunk(val text: String, val delayMs: Long)

    fun chunkify(markdown: String): List<Chunk> {
        val chunks = mutableListOf<Chunk>()
        val lines = markdown.replace("\r\n", "\n").split('\n')
        var index = 0
        val sb = StringBuilder()

        fun flush(ms: Long) {
            if (sb.isNotEmpty()) {
                chunks += Chunk(sb.toString(), ms)
                sb.clear()
            }
        }

        while (index < lines.size) {
            val line = lines[index]
            val trimmed = line.trimEnd()

            if (trimmed.startsWith("```")) {
                flush(16)
                sb.appendLine(line)
                index++
                val codeLines = mutableListOf<String>()
                while (index < lines.size && !lines[index].trimEnd().startsWith("```")) {
                    codeLines += lines[index]
                    index++
                }
                codeLines.forEach { codeLine ->
                    chunks += Chunk("${sb.toString().trimEnd()}\n$codeLine\n", 8)
                    sb.clear()
                    sb.appendLine(codeLine)
                }
                sb.clear()
                if (index < lines.size) {
                    sb.appendLine(lines[index])
                    index++
                }
                chunks += Chunk(sb.toString(), 16)
                sb.clear()
                continue
            }

            if (trimmed.startsWith("|")) {
                flush(16)
                val tableLines = mutableListOf<String>()
                tableLines += trimmed
                index++
                while (index < lines.size) {
                    val next = lines[index].trimEnd()
                    if (next.startsWith("|") || next.matches(Regex("""^[-:| ]+$"""))) {
                        tableLines += next
                        index++
                    } else if (next.contains("|") && !next.startsWith("#") && !next.startsWith(">") && !next.startsWith("- ")) {
                        tableLines += next
                        index++
                    } else {
                        break
                    }
                }
                tableLines.forEach { row ->
                    if (!row.matches(Regex("""^[-:| ]+$"""))) {
                        chunks += Chunk("$row\n", 24)
                    }
                }
                chunks += Chunk("\n", 8)
                continue
            }

            val headingMatch = Regex("^(#{1,4})\\s*(.*)$").matchEntire(trimmed)
            if (headingMatch != null && headingMatch.groupValues[2].isNotBlank()) {
                flush(16)
                chunks += Chunk("$trimmed\n\n", 20)
                index++
                continue
            }

            val listMatch = Regex("""^([-*]|\d+\.)\s+(.*)$""").matchEntire(trimmed)
            if (listMatch != null) {
                flush(16)
                chunks += Chunk("$trimmed\n", 16)
                index++
                continue
            }

            if (trimmed.matches(Regex("""^[-*_]{3,}\s*$"""))) {
                flush(16)
                chunks += Chunk("$trimmed\n\n", 16)
                index++
                continue
            }

            if (trimmed.startsWith("> ")) {
                flush(16)
                val quoteLines = mutableListOf<String>()
                while (index < lines.size) {
                    val next = lines[index].trimEnd()
                    if (next.startsWith("> ")) {
                        quoteLines += next
                        index++
                    } else {
                        break
                    }
                }
                chunks += Chunk("${quoteLines.joinToString("\n")}\n\n", 20)
                continue
            }

            if (trimmed.isBlank()) {
                flush(16)
                sb.appendLine()
                index++
                continue
            }

            sb.appendLine(trimmed)
            index++
        }

        flush(16)

        val merged = mutableListOf<Chunk>()
        val paragraphBuffer = StringBuilder()
        for (chunk in chunks) {
            val isParagraphLine = !chunk.text.trimStart().startsWith("#") &&
                !chunk.text.trimStart().startsWith("|") &&
                !chunk.text.trimStart().startsWith("> ") &&
                !chunk.text.trimStart().startsWith("- ") &&
                !chunk.text.trimStart().startsWith("* ") &&
                !chunk.text.trimStart().startsWith("```") &&
                !chunk.text.trimStart().startsWith("---") &&
                !Regex("""^\d+\.""", RegexOption.MULTILINE).containsMatchIn(chunk.text.trimStart())

            if (isParagraphLine) {
                paragraphBuffer.append(chunk.text)
            } else {
                if (paragraphBuffer.isNotEmpty()) {
                    val text = paragraphBuffer.toString().trim()
                    if (text.isNotBlank()) {
                        merged += splitParagraphToChunks(text)
                    }
                    paragraphBuffer.clear()
                }
                merged += chunk
            }
        }
        if (paragraphBuffer.isNotEmpty()) {
            val text = paragraphBuffer.toString().trim()
            if (text.isNotBlank()) {
                merged += splitParagraphToChunks(text)
            }
        }

        return merged
    }

    private fun splitParagraphToChunks(text: String): List<Chunk> {
        val parts = text.split(Regex("""(?<=[。！？\n.!?])"""))
        if (parts.size <= 1) return listOf(Chunk(text, 30))

        val chunks = mutableListOf<Chunk>()
        val threshold = (30..60).random()
        val delayBase = threshold.toLong()
        parts.forEach { part ->
            if (part.isNotBlank()) {
                chunks += Chunk(part, delayBase)
            }
        }
        return chunks
    }

    suspend fun stream(
        fullText: String,
        onUpdate: (visibleText: String) -> Unit,
        onCancel: () -> Boolean,
        speedMultiplier: Float = 1f,
    ) {
        val chunks = chunkify(fullText)
        val buffer = StringBuilder()
        for (chunk in chunks) {
            if (onCancel()) return
            buffer.append(chunk.text)
            onUpdate(buffer.toString())
            delay((chunk.delayMs / speedMultiplier.coerceAtLeast(0.1f)).toLong().coerceAtLeast(1))
        }
    }
}
