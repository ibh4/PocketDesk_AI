package com.pengwc.clawmemorylocal

import kotlinx.serialization.Serializable

@Serializable
data class FileNameRecord(
    val id: String,
    val name: String,
    val relativePath: String,
    val extension: String,
    val sizeBytes: Long,
    val lastModified: Long,
    val isDirectory: Boolean,
    val depth: Int,
    val indexedAt: Long,
)

@Serializable
data class FileNameIndexPayload(
    val rootUri: String = "",
    val rootName: String = "",
    val scannedAt: Long = 0L,
    val fileCount: Int = 0,
    val folderCount: Int = 0,
    val truncated: Boolean = false,
    val records: List<FileNameRecord> = emptyList(),
)

enum class FileSearchFilter(val label: String) {
    All("全部"),
    Folder("文件夹"),
    Markdown("Markdown"),
    Text("文本"),
    Code("代码"),
    Image("图片"),
    Other("其他"),
}

enum class FileSearchSort(val label: String) {
    Name("文件名"),
    Modified("修改时间"),
    Size("文件大小"),
    Type("类型"),
}

data class FileSearchUiState(
    val folderStatus: String = "未选择",
    val folderName: String = "",
    val folderUri: String = "",
    val hasValidPermission: Boolean = false,
    val fileCount: Int = 0,
    val folderCount: Int = 0,
    val lastScannedAt: String = "",
    val isScanning: Boolean = false,
    val scanProgressText: String = "",
    val scanTruncated: Boolean = false,
    val query: String = "",
    val filter: FileSearchFilter = FileSearchFilter.All,
    val sort: FileSearchSort = FileSearchSort.Name,
    val records: List<FileNameRecord> = emptyList(),
    val displayRecords: List<FileNameRecord> = emptyList(),
    val analysisMarkdown: String = "",
    val isAnalyzing: Boolean = false,
    val showOnlineConfirmDialog: Boolean = false,
    val readWriteEnabled: Boolean = false,
)

