package com.pengwc.clawmemorylocal

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

data class DeepSpaceState(
    var round: Int = 1,
    var o2: Int = 60,
    var san: Int = 80,
    var location: String = "B-3 医疗舱",
    var isGameOver: Boolean = false,
)

data class Scenario(
    val title: String,
    val narrative: String,
    val xaiMessage: String,
    val noiseMessage: String,
    val buttons: List<String>,
    val o2Change: Int,
    val sanChange: Int,
    val hasShake: Boolean,
    val hasRedPulse: Boolean,
)

private fun buildScenario(round: Int, action: String, state: DeepSpaceState): Scenario {
    val r = (round * 7 + action.hashCode()).let { Random(it) }

    val scenarios = listOf(
        Scenario("⚙️ 工程舱通道", "紧急照明闪烁，管道破裂声从四面八方传来。", "建议切断非必要供电，将能源集中到氧气循环系统。", "别听它的！工程舱C区有备用氧气罐！", listOf("切断非必要供电", "前往工程舱C区", "原地固守节约氧气"), -8, -5, false, false),
        Scenario("🔬 生物实验室", "培养皿碎裂一地，空气中有淡淡的化学气味。", "检测到未知生物制剂泄漏。启动净化协议。", "那不是消毒剂…那是某种神经毒素！快戴防毒面具！", listOf("启动净化协议", "戴上防毒面具", "用切割器破墙逃离"), -10, -8, true, true),
        Scenario("🛏️ 船员休息舱", "舱门半开，里面一片狼藉。一张床翻倒形成掩体。", "舱内无生命信号。建议原地休整，恢复氧气供给。", "墙角有个急救包！那个位置是医疗舱的盲区，暂时安全！", listOf("原地休整恢复", "搜寻急救包", "设置路障防御"), -3, +5, false, false),
        Scenario("🔧 主控机房", "服务器阵列仍在运转，屏幕上跳动着异常的数据流。", "我可以接入主机，关闭那扇封死的舱门。需要你手动插线。", "它在骗你！插上线它就能控制整个飞船！用切割器毁掉主机！", listOf("手动插线接入", "用切割器毁掉主机", "绕过机房继续前进"), -5, -10, false, true),
        Scenario("🌌 观景舰桥", "巨大的舷窗外是无尽深空。一道暗影在远处蠕动。", "检测到高速接近的未知物体。建议启动紧急推进。", "看窗外！那是…那不是物体…那是活的！快闭上眼睛！", listOf("启动紧急推进", "闭上双眼背对舷窗", "打开全部照明驱散"), -12, -15, true, true),
        Scenario("🚪 主气闸舱", "气闸控制面板显示外部压力异常。逃生舱就在前方。", "逃生舱已就绪。请验证身份后脱出。这是唯一出路。", "逃生舱的能量只够一个人！它会在半路把你弹射到太空！", listOf("验证身份脱出", "手动检查逃生舱", "折返另寻出路"), -15, -5, false, true),
    )

    val sc = scenarios[r.nextInt(scenarios.size)]
    val sanBonus = if (round <= 3) 0 else -3
    val o2Drain = if (round >= 6) -5 else 0

    return sc.copy(
        o2Change = (sc.o2Change + o2Drain).coerceAtMost(0),
        sanChange = sc.sanChange + sanBonus,
    )
}

private fun buildEnding(state: DeepSpaceState, action: String): Scenario {
    return when {
        state.o2 <= 0 -> Scenario(
            "💀 窒息死亡", "氧气耗尽。肺腑灼烧，视野模糊。最后看到的是天花板上闪烁的红色警示灯。\n\n**结局：无声的终结**", "维生系统离线。彭博士，你的牺牲将被记录。", "*静默*", emptyList(), 0, 0, false, false
        )
        state.san <= 0 -> Scenario(
            "🌀 理智崩溃", "耳边不再有声音。舷窗外的暗影变成了无数张尖叫的脸。你大笑着打开气闸。\n\n**结局：疯狂的深渊**", "检测到脑电波异常。已无法执行保护协议。", "哈哈哈哈…你终于看到了！那些脸…那些真相！", emptyList(), 0, 0, true, true
        )
        state.round == 2 && state.o2 > 30 && state.san > 40 -> Scenario(
            "✨ 逃出生天", "逃生舱弹射的瞬间，整个飞船在你身后爆炸。你独自漂流在深空中，但活着。\n\n**结局：活着就是胜利**", "信号丢失。彭博士，愿人类荣光永存。", "*微弱的信号杂音* …你还活着？…好样的。", emptyList(), 0, 0, false, false
        )
        state.round == 2 && state.o2 > 10 -> Scenario(
            "⚡ 最后一搏", "逃生舱成功脱离，但推进器被碎片击中。你迫降在一颗荒芜星球上。\n\n**结局：流放者**", "定位信号已发送。救援概率：17.3%。", "天啊…你还活着。信号太弱了…但我在找你。", emptyList(), 0, 0, false, true
        )
        else -> Scenario(
            "🕯️ 英雄陨落", "十轮生死抉择，你已精疲力竭。维生系统信号灯全部熄灭。\n\n**结局：最后的抉择**", "系统关机。再见，彭博士。", "对不起…我骗了你那么多次…但你救了我们。", emptyList(), 0, 0, false, false
        )
    }
}

private fun formatScenario(sc: Scenario, state: DeepSpaceState): String {
    val o2Bar = buildBar(state.o2)
    val sanBar = buildBar(state.san)
    val effects = buildString {
        if (sc.hasShake) append("[Effect: Shake]")
        if (sc.hasRedPulse) append("[Effect: RedPulse]")
    }

    return """$effects
# ${sc.title}

> ${sc.narrative}

| 🧬 体征 | 状态条 | 数值 | 评估 |
| :--- | :--- | :---: | :--- |
| 🔴 O₂ | `$o2Bar` | ${state.o2}% | ${o2Status(state.o2)} |
| 🟡 SAN | `$sanBar` | ${state.san}% | ${sanStatus(state.san)} |

> 🔵 **🤖 XAI：** ${sc.xaiMessage}

> 🟡 **👤 杂音：** ${sc.noiseMessage}
""".trim()
}

private fun buildBar(value: Int): String {
    val filled = (value / 20).coerceIn(0, 5)
    return "█".repeat(filled) + "░".repeat(5 - filled)
}

private fun o2Status(v: Int) = when { v > 60 -> "🟢 正常"; v > 30 -> "🟡 偏低"; else -> "🔴 危急" }
private fun sanStatus(v: Int) = when { v > 60 -> "🟢 清醒"; v > 30 -> "🟡 恍惚"; else -> "🔴 崩溃边缘" }

@Composable
fun DeepSpaceScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(DeepSpaceState()) }
    var scenario by remember { mutableStateOf(INITIAL_SCENE) }
    var currentButtons by remember { mutableStateOf(listOf("绝对静默", "搜索医疗柜", "切开通风管")) }
    var isEnding by remember { mutableStateOf(false) }
    var showRedPulse by remember { mutableStateOf(false) }
    var shakeTrigger by remember { mutableIntStateOf(0) }
    val vibrator = remember { getVibrator(context) }

    val redPulseAlpha by animateFloatAsState(
        targetValue = if (showRedPulse) 1f else 0f,
        animationSpec = tween(300),
        label = "pulseAlpha",
    )

    LaunchedEffect(shakeTrigger) {
        if (shakeTrigger > 0) {
            playShake(vibrator)
        }
    }
    LaunchedEffect(scenario) {
        if (scenario.contains("[Effect: Shake]")) {
            shakeTrigger++
        }
        if (scenario.contains("[Effect: RedPulse]")) {
            showRedPulse = true
            delay(600)
            showRedPulse = false
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF1E3A5F))) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = onBack) {
                    Text("← 退出", fontSize = 12.sp, color = Color.White)
                }
                Text("⚙️ 第${state.round}回合", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                if (isEnding) {
                    Button(onClick = {
                        state = DeepSpaceState()
                        scenario = INITIAL_SCENE
                        currentButtons = listOf("绝对静默", "搜索医疗柜", "切开通风管")
                        isEnding = false
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0E0E0), contentColor = Color.Black)) {
                        Text("重新开始", fontSize = 12.sp)
                    }
                }
            }

            val cleaned = scenario
                .replace("[Effect: Shake]", "")
                .replace("[Effect: RedPulse]", "")
                .replace(Regex("""\[小程序按钮:[^\]]+\]"""), "")
                .replace(Regex("""^# .+""", RegexOption.MULTILINE), "")

            Column(
                modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                val title = Regex("""^# (.+)""", RegexOption.MULTILINE).find(scenario)?.groupValues?.get(1)?.trim()
                if (title != null) {
                    Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                MarkdownView(markdown = cleaned, textColorHex = "#FFFFFF", backgroundColorHex = "#1E3A5F")
            }

            if (!isEnding) {
                val rows = if (currentButtons.size <= 3) listOf(currentButtons) else currentButtons.chunked(3)
                rows.forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        row.forEach { label ->
                            Button(
                                onClick = {
                                    state.round++
                                    val sc = buildScenario(state.round, label, state)
                                    state.o2 = (state.o2 + sc.o2Change).coerceIn(0, 100)
                                    state.san = (state.san + sc.sanChange).coerceIn(0, 100)
                                    state.location = sc.title.removePrefix("# ").take(15)
                                    if (state.round >= 10 || state.o2 <= 0 || state.san <= 0) {
                                        val end = buildEnding(state, label)
                                        state.isGameOver = true
                                        isEnding = true
                                        currentButtons = emptyList()
                                        scenario = formatScenario(end, state)
                                    } else {
                                        currentButtons = sc.buttons
                                        scenario = formatScenario(sc, state)
                                    }
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8E8E8), contentColor = Color.Black),
                            ) { Text(label.take(6), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black) }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = showRedPulse, enter = fadeIn(tween(200)), exit = fadeOut(tween(400))) {
            Box(modifier = Modifier.fillMaxSize().background(Color(0x44FF3B30)).alpha(redPulseAlpha))
        }
    }
}

private fun getVibrator(context: Context): Vibrator =
    if (Build.VERSION.SDK_INT >= 31) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        manager.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }

private fun playShake(vibrator: Vibrator) {
    if (Build.VERSION.SDK_INT >= 26) {
        vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(200)
    }
}

private val INITIAL_SCENE = """
# 🚀 B-3 医疗舱 · `SYS_STATUS: OFFLINE // 本地终端接入`

---

> 🔴 **CRITICAL WARNING**
> 气压急剧下降。主门物理锁死。维生系统濒临崩溃。

| 🧬 体征 | 状态条 | 数值 | 评估 |
| :--- | :--- | :---: | :--- |
| 🔴 O₂ | `███░░` | 60% | 仅够行动3次 |
| 🟡 SAN | `████░` | 80% | 精神轻度污染 |

> 🔵 **🤖 XAI：** "彭博士，门外检测到未知畸变体。建议启动「绝对静默」，切断个人维生氧气，将剩余能源供给飞船主核心。"

> 🟡 **👤 杂音：** "别听铁盒子的！用切割机切开右边通风管，快爬过来！"
""".trimIndent()
