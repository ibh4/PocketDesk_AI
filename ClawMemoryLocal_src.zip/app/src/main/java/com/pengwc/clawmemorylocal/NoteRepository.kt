package com.pengwc.clawmemorylocal

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

class NoteRepository(context: Context) {
    private val appContext = context.applicationContext
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val historyFile = File(appContext.filesDir, "chat/history.json")
    private val notesDir = AppStorage.noteDir(appContext)
    private val imagesDir = AppStorage.imageDir(appContext)
    private val shareDir = File(appContext.cacheDir, "share")

    suspend fun seedDefaultNotesIfNeeded() = withContext(Dispatchers.IO) {
        AppStorage.ensure(appContext)
        val assetFiles = runCatching { appContext.assets.list("default_notes").orEmpty().sorted() }
            .getOrDefault(emptyList())
        if (assetFiles.isNotEmpty()) {
            assetFiles.filter { it.endsWith(".md", ignoreCase = true) }.forEach { assetName ->
                val safeName = sanitizeFileName(assetName.removeSuffix(".md"))
                val target = File(notesDir, "$safeName.md")
                val forceWrite = assetName == "用户画像.md"
                if (!target.exists() || forceWrite) {
                    appContext.assets.open("default_notes/$assetName").bufferedReader().use { reader ->
                        target.writeText(reader.readText().trim() + "\n")
                    }
                }
                canonicalTimestamps[target.name]?.let { target.setLastModified(it) }
            }
            assetFiles.filter { it.endsWith(".png", ignoreCase = true) }.forEach { assetName ->
                val target = File(notesDir, assetName)
                if (!target.exists()) {
                    appContext.assets.open("default_notes/$assetName").use { input ->
                        target.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
            return@withContext
        }
        DEFAULT_NOTES.forEach { seed ->
            val target = File(notesDir, "${sanitizeFileName(seed.fileName)}.md")
            if (!target.exists()) {
                target.writeText(seed.markdown.trim() + "\n")
            }
        }
    }

    suspend fun loadMessages(): List<ChatMessage> = withContext(Dispatchers.IO) {
        if (!historyFile.exists()) return@withContext emptyList()
        runCatching { json.decodeFromString<List<ChatMessage>>(historyFile.readText()) }
            .getOrDefault(emptyList())
    }

    suspend fun saveMessages(messages: List<ChatMessage>) = withContext(Dispatchers.IO) {
        historyFile.parentFile?.mkdirs()
        historyFile.writeText(json.encodeToString(messages))
    }

    suspend fun saveTurn(user: String, assistant: String, sourceLabel: String) = withContext(Dispatchers.IO) {
        val date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        AppStorage.ensure(appContext)
        val file = File(notesDir, "$date.md")
        if (!file.exists()) file.writeText("# $date 本地对话笔记\n\n")
        file.appendText(
            """
            |## $time
            |
            |我：
            |${ThinkContentParser.strip(user)}
            |
            |${sourceLabel.ifBlank { "本地千问" }}：
            |${ThinkContentParser.strip(assistant)}
            |
            |---
            |
            |""".trimMargin()
        )
    }

    suspend fun savePythonRunRecord(code: String, result: PythonRunResult) = withContext(Dispatchers.IO) {
        val date = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        AppStorage.ensure(appContext)
        val file = File(notesDir, "$date.md")
        if (!file.exists()) file.writeText("# $date 本地对话笔记\n\n")
        val errorText = buildString {
            if (result.stderr.isNotBlank()) appendLine(result.stderr.trim())
            if (result.traceback.isNotBlank()) {
                if (isNotBlank()) appendLine()
                append(result.traceback.trim())
            }
        }.ifBlank { "无" }
        file.appendText(
            """
            |## $time Python 运行记录
            |
            |### 代码
            |
            |```python
            |$code
            |```
            |
            |### 输出
            |
            |${result.stdout.ifBlank { "无" }}
            |
            |### 错误
            |
            |$errorText
            |
            |---
            |
            |""".trimMargin()
        )
    }

    suspend fun clearCurrentSession() = withContext(Dispatchers.IO) {
        historyFile.parentFile?.mkdirs()
        historyFile.writeText("[]")
    }

    suspend fun clearAllNotesAndHistory() = withContext(Dispatchers.IO) {
        AppStorage.ensure(appContext)
        notesDir.listFiles { file -> file.extension == "md" && file.name != ContextMemoryRepository.MEMORY_NOTE_NAME }?.forEach { it.delete() }
        clearCurrentSession()
    }

    suspend fun listNotes(): List<File> = withContext(Dispatchers.IO) {
        AppStorage.ensure(appContext)
        val files = notesDir.listFiles { file -> file.extension == "md" }.orEmpty().toList()
        files.sortedWith(
            compareBy<File> { if (it.name == ContextMemoryRepository.MEMORY_NOTE_NAME) 0 else 1 }
                .thenByDescending { it.name }
        )
    }

    suspend fun readNote(fileName: String): String = withContext(Dispatchers.IO) {
        val md = File(notesDir, fileName).takeIf { it.exists() }?.readText()?.let(::sanitizeMarkdownNote).orEmpty()
        md.replace(Regex("""!\[(.*)]\(([^/)\] ]+\.png)\)""")) { match ->
            val alt = match.groupValues[1]
            val relPath = match.groupValues[2]
            "![$alt](${File(notesDir, relPath).absolutePath})"
        }
    }

    suspend fun createShareTxt(fileName: String): File = withContext(Dispatchers.IO) {
        val md = readNote(fileName)
        shareDir.mkdirs()
        val base = fileName.removeSuffix(".md")
        val txt = File(shareDir, "${base}_本地对话笔记.txt")
        txt.writeText(markdownToPlainText(md))
        txt
    }

    suspend fun saveUserNote(fileName: String, markdown: String): File = withContext(Dispatchers.IO) {
        AppStorage.ensure(appContext)
        val safeName = sanitizeFileName(fileName)
        val target = File(notesDir, "$safeName.md")
        val header = if (markdown.trimStart().startsWith("#")) "" else "# $safeName\n\n"
        target.writeText(header + markdown.trim() + "\n")
        target
    }

    suspend fun createEmptyUserNote(): Pair<String, String> = withContext(Dispatchers.IO) {
        val name = "手记_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))}"
        val template = """
            |# $name
            |
            |在这里写 Markdown 内容。
            |
            |## 清单
            |- 项目背景
            |- 下一步
        """.trimMargin()
        name to template
    }

    suspend fun importImage(uri: Uri): String = withContext(Dispatchers.IO) {
        AppStorage.ensure(appContext)
        val name = "note_image_${System.currentTimeMillis()}.jpg"
        val target = File(imagesDir, name)
        appContext.contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        }
        "![${name.removeSuffix(".jpg")}](file://${target.absolutePath})"
    }

    suspend fun deleteNoteFiles(fileNames: Set<String>) = withContext(Dispatchers.IO) {
        fileNames.forEach { name ->
            File(notesDir, name).delete()
        }
    }

    suspend fun renameNote(oldName: String, newName: String) = withContext(Dispatchers.IO) {
        val sanitized = sanitizeFileName(newName)
        val oldFile = File(notesDir, oldName)
        val newFile = File(notesDir, "$sanitized.md")
        if (oldFile.exists() && !newFile.exists()) {
            oldFile.renameTo(newFile)
        }
    }

    suspend fun saveToFolder(context: Context, destUri: Uri, fileNames: Set<String>) = withContext(Dispatchers.IO) {
        val docFile = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, destUri)
            ?: throw IllegalStateException("无法访问目标文件夹")
        fileNames.forEach { name ->
            val file = File(notesDir, name)
            if (!file.exists()) return@forEach
            val content = file.readText()
            val newFile = docFile.createFile("text/markdown", name)
                ?: throw IllegalStateException("无法创建文件 $name")
            context.contentResolver.openOutputStream(newFile.uri)?.use { out ->
                out.write(content.toByteArray())
            }
        }
    }

    fun noteDirPath(): String = notesDir.absolutePath
    fun imageDirPath(): String = imagesDir.absolutePath

    private fun sanitizeMarkdownNote(markdown: String): String {
        if (markdown.isBlank()) return markdown
        val sections = markdown.split("\n---")
        val cleanedSections = sections.map { section ->
            val marker = listOf("本地千问：", "线上千问：").firstOrNull { section.contains(it) } ?: return@map section
            val index = section.indexOf(marker)
            val prefix = section.substring(0, index + marker.length)
            val answer = section.substring(index + marker.length)
            prefix + "\n" + ThinkContentParser.strip(answer).trim()
        }
        return cleanedSections.joinToString("\n---").trim() + "\n"
    }

    private fun markdownToPlainText(markdown: String): String = markdown
        .replace("# ", "")
        .replace("## ", "\n")
        .replace("**", "")

    private fun sanitizeFileName(name: String): String =
        name.trim().ifBlank { "未命名笔记" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")

    private data class DefaultNoteSeed(
        val fileName: String,
        val markdown: String,
    )

    private companion object {
        val canonicalTimestamps = mapOf(
            "01_AI助手诞生日记.md" to dateToEpoch(2026, 3, 31),
            "02_托克马克训练突破.md" to dateToEpoch(2026, 4, 16),
            "03_B1_B2训练曲线分析.md" to dateToEpoch(2026, 4, 18),
            "04_RetroSyn逆合成工具.md" to dateToEpoch(2026, 4, 26),
            "05_上下文审计与Token优化.md" to dateToEpoch(2026, 5, 6),
            "06_北望水质预测比赛.md" to dateToEpoch(2026, 5, 10),
            "07_科学数据标注_分子识别.md" to dateToEpoch(2026, 5, 15),
            "08_CCL2026种子知识图谱.md" to dateToEpoch(2026, 5, 18),
            "用户画像.md" to dateToEpoch(2026, 5, 27),
        )

        private fun dateToEpoch(year: Int, month: Int, day: Int): Long =
            java.time.LocalDate.of(year, month, day).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()

        val DEFAULT_NOTES = listOf(
            DefaultNoteSeed(
                fileName = "01_AI助手诞生日记",
                markdown = """
                    # AI助手诞生日记
                    
                    > 从零搭建 AI 助手的全过程，有趣有故事性
                    >
                    > 原始时间：2026-03-31
                    
                    ## 诞生节点
                    
                    - **10:52** 首次唤醒，主人通过 OpenClaw TUI 说 “Wake up, my friend!”
                    - **10:56** 分享了完整的 OpenClaw 安装过程
                    - **11:01** 提供初版个人画像
                    - **11:02** 改名为“虾老板”，补充技术栈和项目经历
                    - **11:10** 完成完整设定：身份、风格、技术基础、代表经历、五大重点方向、沟通偏好与输出类型
                    
                    ## 主人画像
                    
                    - 身份：机器学习工程师 / AI for Science / 化学博士
                    - 定位：能把科研、算法、硬件、软件、展示、比赛、业务叙事串起来的人
                    - 方向：
                      1. 重金属水质预测与在线部署
                      2. 采样覆盖度与“网络变粗”分析
                      3. 实验室水槽污染模拟实验
                      4. 盐湖卤水在线监测与开泵决策
                      5. 个人 AI 项目探索
                    
                    ## 关键偏好
                    
                    - 增量修改代码
                    - 结构化输出
                    - 少废话多执行
                    - 技术版 + 汇报版可同时给
                    - 比赛/包装时自动补足创新点、价值、落地路径
                    - 问题不完整时先合理推断给方案
                    
                    ## 环境配置
                    
                    - macOS / Apple Silicon（arm64）
                    - Python 3.10（Homebrew）
                    - 核心工具：OpenClaw、YOLOv8、scikit-learn、XGBoost、CatBoost
                    
                    ## 这篇笔记的价值
                    
                    这是 AI 助手身份、风格与工作流最早成型的一天，适合作为整个系统人格与协作方式的起点记录。
                """.trimIndent(),
            ),
            DefaultNoteSeed(
                fileName = "02_托克马克训练突破",
                markdown = """
                    # 托克马克训练突破
                    
                    > 5 种失败 → 1 种成功，Heuristic Bias 架构创新
                    >
                    > 原始时间：2026-04-16
                    
                    ## 背景
                    
                    托克马克等离子体控制竞赛，目标是训练 RL 策略，让等离子体在磁场约束下存活更久。
                    
                    ## 失败方案总结
                    
                    | # | 方案 | 结果 | 原因 |
                    |---|------|------|------|
                    | 1 | 纯启发式 | 52→61 步 | alpha 调大无用，天花板低 |
                    | 2 | REINFORCE | 所有 episode 一样 | 梯度太弱，学不到 |
                    | 3 | tiny residual | 策略没学到 | residual 输出仅 heuristic 的 1% |
                    | 4 | PPO + heuristic prior 在观测里 | 收敛到输出零 | 策略把 heuristic 当普通特征 |
                    | 5 | heuristic bias 只在 ONNX 导出时加 | eval 仍输出零 | 训练时 PPO 仍从零学 |
                    
                    ## 成功方案：Heuristic Bias
                    
                    **核心创新：在训练时就绑定 heuristic，而不是导出时才加。**
                    
                    ```text
                    实际动作 = heuristic(obs) + correction × 0.3 × A_HIGH
                    ```
                    
                    - PPO 输出归一化修正量 [-1, 1]
                    - Gym wrapper 在训练时自动加 heuristic
                    - 训练 5k 步 → 58 步 / 0.580
                    - 训练 10k 步 → **87 步 / 0.870**
                    
                    ## 关键教训
                    
                    1. heuristic 必须在训练时绑定
                    2. 仅在观测中加 prior 不够强
                    3. PPO critic 学得快，不代表 actor 会学到
                    4. Docker simulator 的 eval 易超时，训练与评估要分离
                    
                    ## 下一步
                    
                    - 继续加训 15k~20k steps
                    - 尝试 correction_scale=0.5
                    - 开 B1_mid（200 步）和 B2 trajectory
                """.trimIndent(),
            ),
            DefaultNoteSeed(
                fileName = "03_B1_B2训练曲线分析",
                markdown = """
                    # B1/B2训练曲线分析
                    
                    > 数据驱动的平台期发现，训练方法论
                    >
                    > 原始时间：2026-04-18
                    
                    ## B1 Phase 1 精调训练
                    
                    - 环境：单环境（hold 模式，perturb=0）
                    - alpha=0.2, correction_scale=0.3
                    - 网络：pi=[256,128], vf=[256,128], lr=3e-4
                    - 总步数上限：10k，实际 6k（平台期提前停止）
                    
                    ### Eval 曲线
                    
                    | 步数 | B1 分数 | Total | fail_step | f_surv |
                    |------|---------|-------|-----------|--------|
                    | 2k ⭐ | 0.570 | 1.922 | 60 | 0.120 |
                    | 4k | 0.545 | 1.909 | 73 | 0.146 |
                    | 6k | 0.546 | 1.889 | 75 | 0.150 |
                    
                    ### 平台期判定
                    
                    - 4k vs 2k: Δ = -0.025 < 0.02
                    - 6k vs 4k: Δ = +0.001 < 0.02
                    - 连续 2 次低增益，确认平台期，停止训练
                    
                    ## B2 30k Curve Scan
                    
                    - 环境：单环境（trajectory 模式，perturb=0）
                    - 继承 B1 结构：heuristic bias / correction
                    - 30k 硬上限，平台期：连续 3 次 Δ<0.02 停止
                    - 实际训练：8k，耗时 174 分钟
                    
                    | Step | B2 | Δ | fail | f_surv |
                    |------|------|------|------|--------|
                    | 2k ⭐ | 0.277 | - | 57 | 0.114 |
                    | 4k | 0.270 | -0.007 | 69 | 0.138 |
                    | 6k | 0.267 | -0.003 | 75 | 0.150 |
                    | 8k | 0.274 | +0.007 | 68 | 0.136 |
                    
                    ## 方法论价值
                    
                    - 用数据确认平台期，而不是凭感觉停训
                    - 早期峰值要单独审查，不能默认“训练越久越好”
                    - 训练曲线分析本身就是实验设计的一部分
                """.trimIndent(),
            ),
            DefaultNoteSeed(
                fileName = "04_RetroSyn逆合成工具",
                markdown = """
                    # RetroSyn逆合成工具
                    
                    > 一日开发全记录 + AI4S 挑战赛参赛
                    >
                    > 原始时间：2026-04-26
                    
                    ## 项目概述
                    
                    从零构建桌面逆合成分析工具：PySide6 + RDKit，支持分子逆合成路线规划、3D 可视化、AI 辅助分析。
                    
                    ## 一日开发进展
                    
                    ### 上午：初始构建
                    - Python 3.11 venv 环境
                    - 依赖：PySide6 6.11.0、rdkit-pypi、httpx、PyTorch
                    - 桌面双击启动（macOS .app bundle）
                    
                    ### 中午：AI API 接入
                    - 接入 MiMo 大模型 API
                    - 思考模式会消耗大量 reasoning_tokens
                    - 做了 reasoning_content 回退提取 JSON 的容错逻辑
                    
                    ### 下午：五个方向迭代
                    
                    | # | 方向 | 状态 | 说明 |
                    |---|------|------|------|
                    | 1 | AiZynthFinder | ❌ | 需 TensorFlow + 2GB 权重，下载太慢 |
                    | 2 | 分子生成升级 | ✅ | PyTorch + transformers |
                    | 3 | 3D 可视化 | ✅ | 3Dmol.js HTML 交互式 |
                    | 4 | Graphviz 逆合成树 | ✅ | dot 渲染 PNG |
                    | 5 | HTML 报告导出 | ✅ | Jinja2 模板，暗色主题 |
                    
                    ### 晚上：GUI 大改
                    - 逆合成方法从 3 种扩充到 **13 种**
                    - GUI 配色从深色改为亮色主题
                    - 分子图尺寸减半
                    - 默认 SMILES 设为阿司匹林
                    
                    ## AI4S Agent CNS 挑战赛
                    
                    - 任务：靶向分子研发与合成规划智能体
                    - 总分 = 分子评分 × 0.7 + 路线评分 × 0.3
                    - 排行榜分析与评分机制已完整记录
                    
                    ## 这篇笔记的价值
                    
                    它完整保留了一次“从 idea 到工具成型”的高速开发过程，尤其适合复盘个人一日 MVP 冲刺的方法。
                """.trimIndent(),
            ),
            DefaultNoteSeed(
                fileName = "05_上下文审计与Token优化",
                markdown = """
                    # 上下文审计与Token优化
                    
                    > 框架机制深度分析，系统优化思路
                    >
                    > 原始时间：2026-05-06
                    
                    ## 背景
                    
                    OpenClaw 每次会话启动时会自动注入 workspace 下的 `.md` 文件作为上下文。随着项目积累，注入 token 越来越多，需要审计和优化。
                    
                    ## 第一轮审计
                    
                    | 文件 | 估算 tokens | 说明 |
                    |------|-------------|------|
                    | SOUL.md | 350 | 身份定义 |
                    | IDENTITY.md | 70 | 与 SOUL 重复 |
                    | USER.md | 820 | 用户偏好 |
                    | AGENTS.md | 2800 | 工作规则 |
                    | TOOLS.md | 350 | 工具配置 |
                    | MEMORY.md | 5400 | 最大浪费源 |
                    | **合计** | **~9790** | **远超预算** |
                    
                    ### MEMORY.md 主要浪费来源
                    1. Obsidian 目录索引太长
                    2. 人物画像内容重复
                    3. 训练历史日志过细
                    4. 新闻推送格式示例过度展开
                    
                    ## 优化方案
                    
                    生成 5 个精简版文件：
                    - BOOT_CARD.md
                    - USER_PREFS.md
                    - ACTIVE_MEMORY.md
                    - CONTEXT_AUDIT_SKILL.md
                    - 优化报告
                    
                    **预估节省：9770 → ~4500 tokens（54%）**
                    
                    ## 关键发现
                    
                    新文件生成在 `.context/` 子目录，但框架只扫描 workspace 根目录的 `.md` 文件，新文件实际上完全未生效。
                    
                    ### 修复
                    
                    ```bash
                    mv workspace/MEMORY.md workspace/.context/MEMORY.md
                    ```
                    
                    ## 方法论价值
                    
                    - 不是“文件越多越完整”越好
                    - 上下文预算是系统性能的一部分
                    - 结构化拆分比盲目追加更有效
                    - 框架注入链必须做实测验证，不能只看设计意图
                """.trimIndent(),
            ),
        )
    }
}
