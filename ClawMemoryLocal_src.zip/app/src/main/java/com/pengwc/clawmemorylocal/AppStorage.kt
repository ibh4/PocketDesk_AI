package com.pengwc.clawmemorylocal

import android.content.Context
import java.io.File

object AppStorage {
    private const val ROOT_NAME = "ClawMemoryLocal"

    fun rootDir(context: Context): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, ROOT_NAME)

    fun memoryDir(context: Context): File = File(rootDir(context), "memory")
    fun workspaceDir(context: Context): File = File(rootDir(context), "workspace")
    fun noteDir(context: Context): File = File(rootDir(context), "note")
    fun imageDir(context: Context): File = File(rootDir(context), "images")

    fun ensure(context: Context) {
        val root = rootDir(context)
        root.mkdirs()
        memoryDir(context).mkdirs()
        workspaceDir(context).mkdirs()
        noteDir(context).mkdirs()
        imageDir(context).mkdirs()
        migrateLegacyDirectory(File(context.filesDir, "notes"), noteDir(context))
        migrateLegacyDirectory(File(context.filesDir, "memory"), memoryDir(context))
    }

    private fun migrateLegacyDirectory(from: File, to: File) {
        if (!from.exists() || !from.isDirectory) return
        to.mkdirs()
        from.listFiles().orEmpty().forEach { file ->
            val target = File(to, file.name)
            if (!target.exists()) {
                runCatching { file.copyTo(target, overwrite = false) }
            }
        }
    }
}
