package com.pengwc.clawmemorylocal

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatScreen(state: ChatUiState, viewModel: ChatViewModel) {
    val context = LocalContext.current
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            runOcrAndSave(context, bitmap) { ocrText ->
                viewModel.processCameraNote(bitmap, ocrText)
            }
        }
    }
    ChatScreenContent(
        state = state,
        onInputChange = viewModel::updateInput,
        onFillQuickPrompt = viewModel::fillQuickPrompt,
        onSend = viewModel::send,
        onStop = viewModel::stopGenerating,
        onToggleThinking = viewModel::toggleThinking,
        onImportPythonCode = viewModel::importCodeToPythonTool,
        onRunPythonCode = viewModel::runPythonInChat,
        onConfirmArchive = viewModel::confirmArchive,
        onCancelArchive = viewModel::cancelArchive,
        onCameraNote = { cameraLauncher.launch(null) },
    )
}

@Composable
fun ChatScreenContent(
    state: ChatUiState,
    onInputChange: (String) -> Unit,
    onFillQuickPrompt: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onToggleThinking: () -> Unit,
    onImportPythonCode: (String) -> Unit = {},
    onRunPythonCode: (String) -> Unit = {},
    onConfirmArchive: () -> Unit = {},
    onCancelArchive: () -> Unit = {},
    onCameraNote: () -> Unit = {},
) {
    val context = LocalContext.current
    var quickPromptExpanded by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val lastMessageCount = remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val inputEnabled = when (state.chatMode) {
        ChatMode.Local -> state.status == ModelStatus.Ready && !state.isGenerating
        ChatMode.LocalPlusOnline -> !state.isGenerating
    }

    LaunchedEffect(state.tab) {
        if (state.tab == AppTab.Chat && state.messages.isNotEmpty()) {
            listState.animateScrollToItem(state.messages.lastIndex.coerceAtLeast(0))
        }
    }

    LaunchedEffect(state.messages.size) {
        val wasNearBottom = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index?.let {
            it >= state.messages.lastIndex - 1
        } ?: true
        if (state.messages.size != lastMessageCount.intValue && wasNearBottom && !listState.isScrollInProgress) {
            listState.animateScrollToItem(state.messages.lastIndex.coerceAtLeast(0))
        }
        lastMessageCount.intValue = state.messages.size
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppConversationBackground)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(
            text = when (state.chatMode) {
                ChatMode.Local -> "当前：本地模型"
                ChatMode.LocalPlusOnline -> if (OnlineApiConfig.apiKeyReady() && OnlineApiConfig.baseUrlReady()) "当前：线上+本地千问" else "线上千问未配置"
            },
            color = SecondaryTextColor,
            fontSize = 11.sp,
            modifier = Modifier.padding(bottom = 6.dp),
        )
        if (state.isGenerating) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp).padding(end = 4.dp), strokeWidth = 2.dp)
                Text(
                    "正在思考 ${state.progress}%",
                    modifier = Modifier.clickable { onToggleThinking() },
                    fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = onStop,
                    modifier = Modifier.height(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) { Text("停止", fontSize = 12.sp) }
            }
            LinearProgressIndicator(
                progress = { state.progress / 100f },
                modifier = Modifier.fillMaxWidth(),
                color = PrimaryPurple,
                trackColor = UserBubbleBorder,
            )
        }
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(top = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(state.messages, key = { it.timestamp + it.role }) { message ->
                val renderAsPlainText = state.isGenerating && message == state.messages.last() && message.role == "assistant"
                ChatBubble(
                    message = message,
                    thinkingExpanded = state.thinkingExpanded,
                    onToggleThinking = onToggleThinking,
                    renderAsPlainText = renderAsPlainText,
                    onImportPythonCode = onImportPythonCode,
                    onRunPythonCode = onRunPythonCode,
                    onCopy = {
                        copyText(context, if (message.role == "user") "用户消息" else message.sourceLabel.ifBlank { "模型回复" }, ThinkContentParser.strip(message.content))
                        Toast.makeText(context, "已复制内容", Toast.LENGTH_SHORT).show()
                    },
                )
            }
        }
        if (state.showArchiveConfirmDialog) {
            AlertDialog(
                onDismissRequest = onCancelArchive,
                title = { Text("确认归档", color = AiTextColor) },
                text = { Text("检测到笔记归档方案，是否执行？") },
                confirmButton = {
                    Button(
                        onClick = onConfirmArchive,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                    ) { Text("是，开始归档") }
                },
                dismissButton = {
                    TextButton(onClick = onCancelArchive) { Text("否", color = PrimaryPurple) }
                },
            )
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box {
                Button(
                    onClick = { quickPromptExpanded = true },
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .size(42.dp),
                    shape = CircleShape,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryPurple,
                        contentColor = Color.White,
                    ),
                ) {
                    Text("+", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                DropdownMenu(
                    expanded = quickPromptExpanded,
                    onDismissRequest = { quickPromptExpanded = false },
                ) {
                    DropdownMenuItem(
                        text = { Text("📷 拍照笔记", fontWeight = FontWeight.SemiBold, color = PrimaryPurple) },
                        onClick = { quickPromptExpanded = false; onCameraNote() },
                    )
                    QUICK_PROMPT_TEMPLATES.forEach { template ->
                        DropdownMenuItem(
                            text = { Text(template.title, fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                quickPromptExpanded = false
                                val replacing = state.input.isNotBlank()
                                onFillQuickPrompt(template.content)
                                if (replacing) {
                                    Toast.makeText(context, "已填入常用语，可继续编辑", Toast.LENGTH_SHORT).show()
                                }
                            },
                        )
                    }
                }
            }
            OutlinedTextField(
                value = state.input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                enabled = inputEnabled,
                placeholder = { Text("输入本地对话内容") },
                minLines = 1,
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = InputBackground,
                    unfocusedContainerColor = InputBackground,
                    disabledContainerColor = InputBackground,
                    focusedBorderColor = PrimaryPurple,
                    unfocusedBorderColor = InputBorder,
                    disabledBorderColor = InputBorder,
                ),
            )
            Button(
                onClick = onSend,
                enabled = state.input.isNotBlank() && inputEnabled,
                modifier = Modifier
                    .padding(start = 8.dp)
                    .size(48.dp),
                shape = CircleShape,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PrimaryPurple,
                    contentColor = Color.White,
                    disabledContainerColor = UserBubbleBorder,
                    disabledContentColor = SecondaryTextColor,
                ),
            ) {
                SendArrowIcon()
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    thinkingExpanded: Boolean,
    onToggleThinking: () -> Unit,
    renderAsPlainText: Boolean = false,
    onImportPythonCode: (String) -> Unit = {},
    onRunPythonCode: (String) -> Unit = {},
    onCopy: () -> Unit,
) {
    val isUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        if (isUser) {
            val useMarkdown = !renderAsPlainText && looksLikeMarkdownContent(message.content)
            Box(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .background(
                        color = UserBubbleBackground,
                        shape = RoundedCornerShape(14.dp),
                    )
                    .then(Modifier)
                    .clickable(onClick = onCopy)
                    .padding(12.dp),
            ) {
                if (!useMarkdown) {
                    Text(text = message.content, color = UserBubbleTextColor, lineHeight = 21.sp)
                } else {
                    MarkdownView(
                        markdown = message.content,
                        modifier = Modifier.fillMaxWidth(),
                        textColorHex = "#1E3A8A",
                        backgroundColorHex = "#EFF6FF",
                        onImportPythonCode = onImportPythonCode,
                        onRunPythonCode = onRunPythonCode,
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onCopy)
                    .padding(horizontal = 4.dp, vertical = 6.dp),
            ) {
                if (message.sourceLabel.isNotBlank()) {
                    Text(
                        text = message.sourceLabel,
                        color = SecondaryTextColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 6.dp),
                    )
                }
                val useMarkdown = !renderAsPlainText && looksLikeMarkdownContent(message.content)
                if (!useMarkdown) {
                    Text(text = message.content, color = AiTextColor, lineHeight = 24.sp)
                } else {
                    MarkdownView(
                        markdown = message.content,
                        modifier = Modifier.fillMaxWidth(),
                        textColorHex = "#111827",
                        backgroundColorHex = "#F1F5F9",
                        onImportPythonCode = onImportPythonCode,
                        onRunPythonCode = onRunPythonCode,
                    )
                }
            }
        }
    }
}

@Composable
private fun SendArrowIcon() {
    Canvas(modifier = Modifier.size(20.dp)) {
        val stem = Path().apply {
            moveTo(size.width * 0.5f, size.height * 0.78f)
            lineTo(size.width * 0.5f, size.height * 0.26f)
        }
        val head = Path().apply {
            moveTo(size.width * 0.28f, size.height * 0.42f)
            lineTo(size.width * 0.5f, size.height * 0.20f)
            lineTo(size.width * 0.72f, size.height * 0.42f)
        }
        drawPath(
            path = stem,
            color = Color.White,
            style = Stroke(width = 2.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
        drawPath(
            path = head,
            color = Color.White,
            style = Stroke(width = 2.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

private fun runOcrAndSave(context: android.content.Context, bitmap: Bitmap, onResult: (String) -> Unit) {
    val options = com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions.Builder().build()
    val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(options)
    val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
    recognizer.process(image)
        .addOnSuccessListener { text -> onResult(text.text) }
        .addOnFailureListener { onResult("") }
}
