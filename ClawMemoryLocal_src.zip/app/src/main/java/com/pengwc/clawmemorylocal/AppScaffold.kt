package com.pengwc.clawmemorylocal

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun ClawMemoryApp(viewModel: ChatViewModel) {
    val state by viewModel.state.collectAsState()
    var controlsExpanded by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) viewModel.connectWorkspaceFolder(uri)
    }

    LaunchedEffect(state.notice) {
        val notice = state.notice
        if (notice != null) {
            delay(2200)
            viewModel.clearNotice()
        }
    }

    Scaffold(
        topBar = {
            CompactTopPanel(
                state = state,
                expanded = controlsExpanded,
                onToggle = { controlsExpanded = !controlsExpanded },
                onChatMode = viewModel::setChatMode,
                onPerformanceMode = viewModel::setPerformanceMode,
                    onEvidenceMode = viewModel::setEvidenceMode,
                    onAccessPermission = viewModel::setAccessPermission,
                onNewConversation = viewModel::newConversation,
                onClearChat = viewModel::requestClearChat,
                onOpenSettings = { showSettings = true },
            )
        },
        bottomBar = {
            CompactBottomNav(
                selected = state.tab,
                onSelect = viewModel::setTab,
            )
        },
    ) { padding ->
        Surface(color = AppPageBackground, modifier = Modifier.fillMaxSize().padding(padding)) {
            Column(modifier = Modifier.fillMaxSize()) {
                AnimatedVisibility(
                    visible = !state.notice.isNullOrBlank(),
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    TopNoticeBanner(text = state.notice.orEmpty())
                }
                Crossfade(targetState = state.tab, label = "tab") { tab ->
                    when (tab) {
                        AppTab.Chat -> ChatScreen(state, viewModel)
                        AppTab.Notes -> NotesScreen(state, viewModel)
                        AppTab.Logs -> ErrorLogScreen(state, viewModel)
                        AppTab.MiniApps -> MiniAppsScreen(
                            state = state,
                            onRouteChange = viewModel::setMiniAppRoute,
                            onCodeChange = viewModel::updatePythonToolCode,
                            onImportConsumed = viewModel::consumePythonToolImport,
                            onFileFolderPicked = viewModel::handleFileFolderPicked,
                            onFileSearchQueryChange = viewModel::updateFileSearchQuery,
                            onFileSearchFilterChange = viewModel::setFileSearchFilter,
                            onFileSearchSortChange = viewModel::setFileSearchSort,
                            onRefreshFileSearch = viewModel::refreshFileSearchScan,
                            onCancelFileSearchScan = viewModel::cancelFileSearchScan,
                            onDisconnectFileSearchFolder = viewModel::disconnectFileSearchFolder,
                            onClearFileSearchIndex = viewModel::clearFileSearchIndex,
                            onAnalyzeFileNames = viewModel::requestAnalyzeFileNames,
                            onSaveFileSearchReportInternal = viewModel::saveFileSearchReportInternal,
                            onSaveFileSearchReportToFolder = viewModel::saveFileSearchReportToFolder,
                            onConfirmFileSearchAnalyzeLocal = viewModel::confirmAnalyzeFileNamesLocal,
                            onConfirmFileSearchAnalyzeOnline = viewModel::confirmAnalyzeFileNamesOnline,
                            onDismissFileSearchAnalyzeDialog = viewModel::dismissFileSearchAnalyzeDialog,
                            onToggleFileSearchReadWrite = { viewModel.setFileSearchReadWrite(!state.fileSearch.readWriteEnabled) },
                            onOpenBubbleNote = viewModel::openBubbleNote,
                            onRunTodayAnalysis = viewModel::runTodayAnalysis,
                            onSaveTodayAnalysis = viewModel::saveTodayAnalysis,
                            customApp1Name = state.customApp1Name,
                            customApp1Code = state.customApp1Code,
                            customApp2Name = state.customApp2Name,
                            customApp2Code = state.customApp2Code,
                        )
                    }
                }
            }
        }
    }

    if (state.showClearChatDialog) {
        ConfirmDialog(
            title = "清空当前对话",
            text = "确定清空当前对话吗？每日 Markdown 笔记不会删除。",
            onConfirm = viewModel::confirmClearChat,
            onDismiss = viewModel::dismissDialogs,
        )
    }
    if (state.showClearNotesDialog) {
        ConfirmDialog(
            title = "清空全部历史笔记",
            text = "将删除 notes 目录下全部 Markdown，并清空 JSON 聊天历史。",
            onConfirm = viewModel::confirmClearNotes,
            onDismiss = viewModel::dismissDialogs,
        )
    }
    if (showSettings) {
        SettingsDialog(
            state = state,
            onDismiss = { showSettings = false },
            onPickWorkspaceFolder = { folderPicker.launch(null) },
            onRefreshWorkspace = viewModel::refreshWorkspace,
        onClearWorkspace = viewModel::clearWorkspaceFolder,
    )
}
}

@Composable
private fun TopNoticeBanner(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .background(Color(0xFFEFF6FF), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            text = text,
            color = Color(0xFF1E3A8A),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
fun PreviewClawMemoryApp(state: ChatUiState, controlsExpanded: Boolean = false) {
    Scaffold(
        topBar = {
            CompactTopPanel(
                state = state,
                expanded = controlsExpanded,
                onToggle = {},
                onChatMode = {},
                onPerformanceMode = {},
                onEvidenceMode = {},
                onAccessPermission = {},
                onNewConversation = {},
                onClearChat = {},
                onOpenSettings = {},
            )
        },
        bottomBar = {
            CompactBottomNav(selected = state.tab, onSelect = {})
        },
    ) { padding ->
        Surface(color = AppPageBackground, modifier = Modifier.fillMaxSize().padding(padding)) {
            when (state.tab) {
                AppTab.Chat -> ChatScreenContent(
                    state = state,
                    onInputChange = {},
                    onFillQuickPrompt = {},
                    onSend = {},
                    onStop = {},
                    onToggleThinking = {},
                     onImportPythonCode = {},
                     onRunPythonCode = {},
                 )
                AppTab.Notes -> NotesScreenContent(
                    state = state,
                    onRefresh = {},
                    onClearNotes = {},
                    onSelectNote = {},
                    onBack = {},
                    onCopy = {},
                    onShare = {},
                    onCreate = {},
                    onEdit = {},
                    onUpdateTitle = {},
                    onUpdateContent = {},
                    onSave = {},
                    onCancelEdit = {},
                    onInsertImage = {},
                    onToggleSelect = {},
                    onClearSelection = {},
                    onDeleteSelected = {},
                    onConfirmDelete = {},
                    onCancelDelete = {},
                    onRenameNote = {},
                    onUpdateRename = {},
                    onConfirmRename = {},
                    onCancelRename = {},
                    onPinNote = {},
                    onExportFolder = {},
                    isPinned = { false },
                )
                AppTab.Logs -> ErrorLogScreenContent(
                    state = state,
                    onRefresh = {},
                    onCopy = {},
                    onShare = {},
                    onClear = {},
                )
                AppTab.MiniApps -> MiniAppsScreen(
                    state = state,
                    onRouteChange = {},
                    onCodeChange = {},
                    onImportConsumed = {},
                    onFileFolderPicked = {},
                    onFileSearchQueryChange = {},
                    onFileSearchFilterChange = {},
                    onFileSearchSortChange = {},
                    onRefreshFileSearch = {},
                    onCancelFileSearchScan = {},
                    onDisconnectFileSearchFolder = {},
                    onClearFileSearchIndex = {},
                    onAnalyzeFileNames = {},
                    onSaveFileSearchReportInternal = {},
                    onSaveFileSearchReportToFolder = {},
                    onConfirmFileSearchAnalyzeLocal = {},
                    onConfirmFileSearchAnalyzeOnline = {},
                    onDismissFileSearchAnalyzeDialog = {},
                    onToggleFileSearchReadWrite = {},
                    onOpenBubbleNote = {},
                    onRunTodayAnalysis = {},
                    onSaveTodayAnalysis = {},
                    customApp1Name = "自定义小程序 1",
                    customApp1Code = "",
                    customApp2Name = "自定义小程序 2",
                    customApp2Code = "",
                )
            }
        }
    }
}

@Composable
private fun CompactTopPanel(
    state: ChatUiState,
    expanded: Boolean,
    onToggle: () -> Unit,
    onChatMode: (ChatMode) -> Unit,
    onPerformanceMode: (PerformanceMode) -> Unit,
    onEvidenceMode: (Boolean) -> Unit,
    onAccessPermission: (Boolean) -> Unit,
    onNewConversation: () -> Unit,
    onClearChat: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(PrimaryPurple)
            .statusBarsPadding()
            .padding(top = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clickable(onClick = onToggle)
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("本地智能助手", fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text("本地优先 · 可切线上", fontSize = 13.sp, color = Color(0xFFEFF6FF))
            }
            TextButton(onClick = onOpenSettings, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                Text("⋯", fontSize = 24.sp, color = Color(0xFFEFF6FF))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            color = when (state.status) {
                                ModelStatus.Ready -> Color(0xFF34C759)
                                ModelStatus.Inferring -> Color(0xFFFFC857)
                                ModelStatus.Failed -> Color(0xFFFF6B6B)
                                else -> Color(0xFFF0EEFD).copy(alpha = 0.75f)
                            },
                            shape = RoundedCornerShape(99.dp),
                        ),
                )
                Text(
                    text = statusText(state),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFEFF6FF),
                    modifier = Modifier.padding(start = 6.dp),
                )
            }
            ExpandArrowIcon(
                expanded = expanded,
                modifier = Modifier
                    .padding(start = 12.dp)
                    .size(26.dp),
            )
        }
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF60A5FA).copy(alpha = 0.28f),
                                    Color(0xFFDBEAFE).copy(alpha = 0.18f),
                                    Color.Transparent,
                                ),
                            ),
                        ),
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AppPageBackground)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("模式", fontSize = 12.sp, color = AiTextColor)
                        ChatMode.entries.forEach { mode ->
                            SegmentedChoiceButton(
                                selected = state.chatMode == mode,
                                onClick = { onChatMode(mode) },
                                enabled = !state.isGenerating,
                                text = mode.label,
                                modifier = Modifier.height(30.dp),
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("性能", fontSize = 12.sp, color = AiTextColor)
                        PerformanceMode.entries.forEach { mode ->
                            SegmentedChoiceButton(
                                selected = state.performanceMode == mode,
                                onClick = { onPerformanceMode(mode) },
                                enabled = !state.isGenerating,
                                text = mode.label,
                                modifier = Modifier.height(30.dp),
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Text("访问权限", fontSize = 12.sp, color = AiTextColor)
                        Switch(
                            checked = state.accessPermissionEnabled,
                            onCheckedChange = onAccessPermission,
                            enabled = !state.isGenerating,
                            modifier = Modifier.scale(0.72f),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PrimaryPurple,
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color(0xFFE5E7EB),
                            ),
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(modeBanner(state), fontSize = 11.sp, color = SecondaryTextColor, modifier = Modifier.weight(1f))
                        TextButton(onClick = onNewConversation, enabled = !state.isGenerating) { Text("新对话", fontSize = 12.sp, color = PrimaryPurple) }
                        TextButton(onClick = onClearChat) { Text("清空", fontSize = 12.sp, color = PrimaryPurple) }
                    }
                }
            }
        }
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF60A5FA)))
    }
}

@Composable
private fun ExpandArrowIcon(expanded: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        if (expanded) {
            rotate(degrees = 180f) {
                drawArrowPath(this)
            }
        } else {
            drawArrowPath(this)
        }
    }
}

private fun drawArrowPath(scope: androidx.compose.ui.graphics.drawscope.DrawScope) = with(scope) {
    val path = Path().apply {
        moveTo(size.width * 0.22f, size.height * 0.38f)
        lineTo(size.width * 0.5f, size.height * 0.68f)
        lineTo(size.width * 0.78f, size.height * 0.38f)
    }
    drawPath(
        path = path,
        color = Color(0xFFEFF6FF),
        style = Stroke(width = 2.8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
    )
}

@Composable
private fun CompactBottomNav(selected: AppTab, onSelect: (AppTab) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .navigationBarsPadding()
            .padding(bottom = 8.dp),
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(DividerSoft))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 2.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BottomNavItem(AppTab.Chat, "对话", selected == AppTab.Chat, onSelect)
            BottomNavItem(AppTab.Notes, "笔记", selected == AppTab.Notes, onSelect)
            BottomNavItem(AppTab.Logs, "日志", selected == AppTab.Logs, onSelect)
            BottomNavItem(AppTab.MiniApps, "小程序", selected == AppTab.MiniApps, onSelect)
        }
    }
}

@Composable
private fun BottomNavItem(tab: AppTab, label: String, selected: Boolean, onSelect: (AppTab) -> Unit) {
    val color = if (selected) PrimaryPurple else Color(0xFF9CA3AF)
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.85f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "nav-press",
    )
    Column(
        modifier = Modifier
            .pointerInput(tab) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                        onSelect(tab)
                    }
                )
            }
            .scale(scale)
            .padding(horizontal = 18.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(width = 34.dp, height = 24.dp)
                .shadow(if (selected) 3.dp else 0.dp, RoundedCornerShape(12.dp))
                .background(if (selected) Color(0xFFBFDBFE) else Color.Transparent, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            LineIcon(tab, color)
        }
        Text(label, fontSize = 12.sp, color = color)
    }
}

@Composable
private fun SegmentedChoiceButton(
    selected: Boolean,
    enabled: Boolean,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val borderColor = Color(0xFF60A5FA)
    val backgroundColor = if (selected) PrimaryPurple else Color.White
    val textColor = if (selected) Color.White else AiTextColor
    Box(
        modifier = modifier
            .background(backgroundColor, RoundedCornerShape(10.dp))
            .border(0.8.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
        )
    }
}

@Composable
private fun LineIcon(tab: AppTab, color: Color) {
    Canvas(modifier = Modifier.size(18.dp)) {
        val stroke = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (tab) {
            AppTab.Chat -> {
                val bubble = Path().apply {
                    moveTo(size.width * 0.18f, size.height * 0.2f)
                    lineTo(size.width * 0.82f, size.height * 0.2f)
                    quadraticTo(size.width * 0.92f, size.height * 0.2f, size.width * 0.92f, size.height * 0.32f)
                    lineTo(size.width * 0.92f, size.height * 0.66f)
                    quadraticTo(size.width * 0.92f, size.height * 0.78f, size.width * 0.78f, size.height * 0.78f)
                    lineTo(size.width * 0.44f, size.height * 0.78f)
                    lineTo(size.width * 0.24f, size.height * 0.92f)
                    lineTo(size.width * 0.28f, size.height * 0.78f)
                    lineTo(size.width * 0.18f, size.height * 0.78f)
                    quadraticTo(size.width * 0.08f, size.height * 0.78f, size.width * 0.08f, size.height * 0.66f)
                    lineTo(size.width * 0.08f, size.height * 0.32f)
                    quadraticTo(size.width * 0.08f, size.height * 0.2f, size.width * 0.18f, size.height * 0.2f)
                }
                drawPath(bubble, color = color, style = stroke)
            }
            AppTab.Notes -> {
                drawRoundRect(color = color, style = stroke, cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()))
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.28f, size.height * 0.35f), end = androidx.compose.ui.geometry.Offset(size.width * 0.72f, size.height * 0.35f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.28f, size.height * 0.52f), end = androidx.compose.ui.geometry.Offset(size.width * 0.72f, size.height * 0.52f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.28f, size.height * 0.69f), end = androidx.compose.ui.geometry.Offset(size.width * 0.58f, size.height * 0.69f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            }
            AppTab.Logs -> {
                drawCircle(color = color, style = stroke, radius = size.minDimension * 0.42f)
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.26f), end = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.58f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(color = color, radius = 1.2.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.72f))
            }
            AppTab.MiniApps -> {
                drawCircle(color = color, style = stroke, radius = size.minDimension * 0.4f)
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.14f), end = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.86f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(color, start = androidx.compose.ui.geometry.Offset(size.width * 0.14f, size.height * 0.5f), end = androidx.compose.ui.geometry.Offset(size.width * 0.86f, size.height * 0.5f), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            }
        }
    }
}

private fun statusText(state: ChatUiState): String = when {
    state.isGenerating -> "正在生成"
    state.status == ModelStatus.Ready -> "模型已就绪"
    state.status == ModelStatus.Loading || state.status == ModelStatus.Unpacking -> "模型加载中"
    state.status == ModelStatus.Failed -> "生成失败"
    else -> state.status.label
}

private fun modeBanner(state: ChatUiState): String = when (state.chatMode) {
    ChatMode.Local -> "当前：本地模型"
    ChatMode.LocalPlusOnline -> if (OnlineApiConfig.apiKeyReady() && OnlineApiConfig.baseUrlReady()) {
        "当前：线上+本地千问"
    } else {
        "线上千问未配置"
    }
}

@Composable
private fun ConfirmDialog(title: String, text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) { Text("确定") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消", color = PrimaryPurple) } },
    )
}

@Composable
private fun SettingsDialog(
    state: ChatUiState,
    onDismiss: () -> Unit,
    onPickWorkspaceFolder: () -> Unit,
    onRefreshWorkspace: () -> Unit,
    onClearWorkspace: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("设置", color = AiTextColor) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("记忆目录：${state.memoryDirPath.ifBlank { "初始化中" }}", fontSize = 12.sp, color = AiTextColor)
                Text(
                    if (state.workspaceFolderName.isBlank()) "项目文件夹：未选择" else "项目文件夹：${state.workspaceFolderName}（${state.workspaceFileCount} 个文本文件）",
                    fontSize = 12.sp,
                    color = AiTextColor,
                )
                Text("默认根目录：${state.rootDirPath}", fontSize = 11.sp, color = SecondaryTextColor)
                Text("笔记目录：${state.noteDirPath}", fontSize = 11.sp, color = SecondaryTextColor)
                Text("图片目录：${state.imageDirPath}", fontSize = 11.sp, color = SecondaryTextColor)
                Text(
                    state.workspaceSummary.ifBlank { "选择一个文件夹后，应用会读取其中一小部分文本文件作为项目上下文，并把项目记忆写回授权目录。" },
                    fontSize = 11.sp,
                    color = SecondaryTextColor,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onPickWorkspaceFolder) { Text("选择文件夹", color = PrimaryPurple) }
                    TextButton(onClick = onRefreshWorkspace) { Text("刷新项目", color = PrimaryPurple) }
                    if (state.workspaceFolderUri.isNotBlank()) {
                        TextButton(onClick = onClearWorkspace) { Text("断开", color = PrimaryPurple) }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) { Text("关闭") }
        },
    )
}
