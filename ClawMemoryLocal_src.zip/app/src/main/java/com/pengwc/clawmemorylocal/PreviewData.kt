package com.pengwc.clawmemorylocal

import java.io.File

object PreviewData {
    fun chatState(expanded: Boolean = false): ChatUiState = ChatUiState(
        tab = AppTab.Chat,
        status = ModelStatus.Ready,
        messages = listOf(
            ChatMessage("user", "你好，请介绍一下你自己", "preview-1"),
            ChatMessage(
                "assistant",
                "我是一个运行在本地的中文智能助手，可以帮助你整理对话和记录每日笔记。",
                "preview-2",
            ),
            ChatMessage("user", "把快递破损这件事整理一下", "preview-3"),
            ChatMessage(
                "assistant",
                "当然可以，下面是整理结果：\n\n事件摘要：收到快递后发现外包装破损，怀疑内部物品受损。\n\n下一步行动：拍照留存、联系商家和快递客服、保留包装。",
                "preview-4",
            ),
        ),
        input = "继续补充处理建议",
        evidenceMode = expanded,
        performanceMode = PerformanceMode.Balanced,
    )

    fun notesState(): ChatUiState = ChatUiState(
        tab = AppTab.Notes,
        status = ModelStatus.Ready,
        noteFiles = listOf(
            File("2026-05-23.md"),
            File("2026-05-22.md"),
            File("2026-05-21.md"),
        ),
    )

    fun logsState(): ChatUiState = ChatUiState(
        tab = AppTab.Logs,
        status = ModelStatus.Ready,
        logs = "运行日志：App 启动成功\n模型日志：模型已加载\n崩溃日志：未发现异常\n性能日志：首 token 时间 1.8s",
        logSections = LogSections(
            runtime = "[2026-05-21 09:00] App 启动成功\n[2026-05-21 09:01] 页面切换：本地对话",
            model = "[2026-05-21 09:01] 模型已加载\n线程数=2，max_new_tokens=256，模式=平衡",
            crash = "[2026-05-21 09:02] 未发现异常\n上次退出原因：NORMAL",
            performance = "[2026-05-21 09:03] 首 token 时间 1.8s\n总生成耗时 6.2s",
            lastExitTrace = "暂无 native tombstone",
            runtimePath = "files/logs/runtime_log.txt",
            modelPath = "files/logs/model_log.txt",
            crashPath = "files/logs/crash_log.txt",
            performancePath = "files/logs/performance_log.txt",
            lastExitTracePath = "files/logs/last_exit_trace.txt",
        ),
    )

    fun noteDetailState(): ChatUiState = notesState().copy(
        selectedNote = "2026-05-21.md",
        selectedNoteContent = """
            |# 2026-05-21 本地对话笔记
            |
            |## 09:30
            |
            |我：
            |优化本地千问 APK 的界面。
            |
            |本地千问：
            |已整理为简洁的本地对话工具界面，并保留历史笔记功能。
            |
            |---
        """.trimMargin(),
    )
}
