package com.pengwc.clawmemorylocal

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class WebSearchResult(
    val title: String,
    val url: String,
    val snippet: String,
    val pageContent: String = "",
)

class WebSearchRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(8, TimeUnit.SECONDS)
        .build()

    private val contentClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String, limit: Int = 6, fetchPages: Int = 2): List<WebSearchResult> = withContext(Dispatchers.IO) {
        val normalized = query.trim()
        if (normalized.isBlank()) return@withContext emptyList()

        val bingUrl = "https://cn.bing.com/search?q=" + URLEncoder.encode(normalized, "UTF-8") + "&setlang=zh-cn"
        var results = runCatching {
            fetchAndParse("Bing", bingUrl, ::parseBingHtml, limit)
        }.getOrElse { emptyList() }

        if (results.isEmpty()) {
            val ddgUrl = "https://duckduckgo.com/html/?q=" + URLEncoder.encode(normalized, "UTF-8")
            results = runCatching {
                fetchAndParse("DDG", ddgUrl, ::parseDdgHtml, limit)
            }.getOrDefault(emptyList())
        }

        results.take(fetchPages).map { result ->
            val content = fetchPageContent(result.url)
            result.copy(pageContent = content)
        } + results.drop(fetchPages)
    }

    private suspend fun fetchPageContent(url: String): String {
        if (url.isBlank()) return ""
        return runCatching {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36")
                .header("Accept-Language", "zh-CN,zh;q=0.9")
                .build()
            contentClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful || response.body == null) return ""
                val html = response.body!!.string()
                extractText(html, 1200)
            }
        }.getOrDefault("")
    }

    private fun extractText(html: String, maxChars: Int): String {
        var cleaned = html
            .replace(Regex("""<script[^>]*>.*?</script>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("""<style[^>]*>.*?</style>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("""<nav[^>]*>.*?</nav>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("""<header[^>]*>.*?</header>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("""<footer[^>]*>.*?</footer>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("""<noscript[^>]*>.*?</noscript>""", RegexOption.DOT_MATCHES_ALL), "\n")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#x27;", "'")
            .replace("&middot;", "·")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .take(maxChars)
        return cleaned.ifBlank { "" }
    }

    private suspend fun fetchAndParse(
        engine: String,
        url: String,
        parser: (String, Int) -> List<WebSearchResult>,
        limit: Int,
    ): List<WebSearchResult> {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36")
            .header("Accept-Language", "zh-CN,zh;q=0.9")
            .build()
        return runCatching {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val html = response.body?.string().orEmpty()
                parser(html, limit)
            }
        }.getOrDefault(emptyList())
    }

    fun isWebSearchIntent(input: String): Boolean {
        val text = input.lowercase()
        return listOf(
            "搜索", "网上", "联网", "网页", "查一下", "查查", "查找",
            "什么是", "是什么意思", "最新", "今天", "新闻", "当前",
            "怎么样", "如何", "怎么", "为什么", "介绍",
            "创业板", "股票", "财经", "走势", "行情", "指数", "a股",
            "上证", "深证", "沪深", "大盘", "涨", "跌", "收盘",
            "经济", "汇率", "利率", "板块", "基金", "期货",
        ).any { text.contains(it) }
    }

    fun shouldSaveAsNote(input: String): Boolean {
        val text = input.lowercase()
        return listOf("整理成笔记", "保存成笔记", "保存到笔记", "生成笔记", "整理为笔记").any { text.contains(it) }
    }

    fun extractSearchQuery(input: String): String {
        val cleaned = input
            .replace("请", "")
            .replace("帮我", "")
            .replace("搜索一下网页", "")
            .replace("搜索网页", "")
            .replace("搜索一下网络", "")
            .replace("搜索网络", "")
            .replace("网上查一下", "")
            .replace("网上查", "")
            .replace("联网查一下", "")
            .replace("联网查", "")
            .replace("查一下网页", "")
            .replace("查网页", "")
            .replace("搜索资料", "")
            .replace("整理成笔记", "")
            .replace("保存成笔记", "")
            .replace("保存到笔记", "")
            .replace("生成笔记", "")
            .replace("整理为笔记", "")
            .trim('：', ':', '，', ',', '。', ' ', '\n', '\t')
        return cleaned.ifBlank { input.trim() }
    }

    fun buildSearchContext(query: String, results: List<WebSearchResult>): String {
        if (results.isEmpty()) return ""
        return buildString {
            appendLine("以下是网页搜索结果，包含搜索摘要和页面前1200字正文：")
            appendLine("搜索词：$query")
            appendLine()
            results.forEachIndexed { index, item ->
                appendLine("${index + 1}. 标题：${item.title}")
                appendLine("链接：${item.url}")
                if (item.snippet.isNotBlank()) appendLine("摘要：${item.snippet}")
                if (item.pageContent.isNotBlank()) {
                    appendLine("正文摘要：${item.pageContent.take(600)}")
                }
                appendLine()
            }
            append("请基于以上搜索结果进行整理和分析。")
        }.trim()
    }

    suspend fun fetchFinanceData(query: String): String = withContext(Dispatchers.IO) {
        val codes = mapOf(
            "创业板" to "sz399006", "创业板指" to "sz399006",
            "上证" to "sh000001", "上证指数" to "sh000001", "大盘" to "sh000001",
            "深证" to "sz399001", "沪深300" to "sh000300",
            "科创50" to "sh000688", "中证1000" to "sh000852",
        )
        val code = codes.entries.firstOrNull { query.contains(it.key) }?.value ?: return@withContext ""
        runCatching {
            val request = Request.Builder()
                .url("https://hq.sinajs.cn/list=$code")
                .header("Referer", "https://finance.sina.com.cn")
                .header("User-Agent", "Mozilla/5.0")
                .build()
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (raw.isBlank()) return@use ""
                parseSinaQuote(code, raw)
            }
        }.getOrDefault("")
    }

    private fun parseSinaQuote(code: String, raw: String): String {
        val data = raw.substringAfter("\"", "").substringBefore("\"")
        if (data.isBlank()) return ""
        val fields = data.split(",")
        if (fields.size < 5) return ""
        return buildString {
            val isIndex = code.startsWith("sz39") || code.startsWith("sh00")
            val name = fields[0]
            val current = fields[1].toDoubleOrNull() ?: fields[3].toDoubleOrNull() ?: return@buildString
            val prevClose = if (isIndex) fields[2].toDoubleOrNull() ?: current else fields[2].toDoubleOrNull() ?: current
            val change = current - prevClose
            val changePct = if (prevClose != 0.0) (change / prevClose * 100) else 0.0
            val sign = if (change >= 0) "+" else ""
            appendLine("$name 最新价：${current} ${sign}${"%.2f".format(change)} (${sign}${"%.2f".format(changePct)}%)")
            if (fields.size > 5) {
                val high = fields[4].toDoubleOrNull()
                val low = fields[5].toDoubleOrNull()
                if (high != null && low != null) appendLine("最高：$high 最低：$low")
            }
            if (fields.size > 8) {
                val volume = fields[8].toDoubleOrNull()?.div(10000)?.let { "${"%.0f".format(it)}万手" } ?: ""
                if (volume.isNotBlank()) appendLine("成交量：$volume")
            }
            appendLine("数据来源：新浪财经实时行情")
        }.trim()
    }

    private fun parseBingHtml(html: String, limit: Int): List<WebSearchResult> {
        if (html.isBlank()) return emptyList()
        val results = mutableListOf<WebSearchResult>()
        val liRegex = Regex("""<li class="b_algo"[^>]*>(.*?)</li>""", RegexOption.DOT_MATCHES_ALL)
        val titleRegex = Regex("""<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>(.*?)</a></h2>""", RegexOption.DOT_MATCHES_ALL)
        val snippetRegex = Regex("""<p[^>]*class="b_lineclamp[^"]*"[^>]*>(.*?)</p>|<div[^>]*class="b_caption"[^>]*>\s*<p[^>]*>(.*?)</p>""", RegexOption.DOT_MATCHES_ALL)
        for (li in liRegex.findAll(html)) {
            val block = li.groupValues[1]
            val titleMatch = titleRegex.find(block) ?: continue
            val url = htmlDecode(titleMatch.groupValues[1]).trim()
            val title = stripHtml(titleMatch.groupValues[2])
            val snippetMatch = snippetRegex.find(block)
            val snippet = stripHtml(snippetMatch?.groupValues?.getOrNull(1).orEmpty().ifBlank {
                snippetMatch?.groupValues?.getOrNull(2).orEmpty()
            })
            if (title.isNotBlank() && url.isNotBlank()) {
                results += WebSearchResult(title = title, url = url, snippet = snippet)
            }
            if (results.size >= limit) break
        }
        return results
    }

    private fun parseDdgHtml(html: String, limit: Int): List<WebSearchResult> {
        if (html.isBlank()) return emptyList()
        val blockRegex = Regex("""<div[^>]*class="result results_links[^"]*"[^>]*>(.*?)</div>\s*</div>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val titleRegex = Regex("""<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val snippetRegex = Regex("""<a[^>]*class="result__snippet"[^>]*>(.*?)</a>|<div[^>]*class="result__snippet"[^>]*>(.*?)</div>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val results = mutableListOf<WebSearchResult>()
        for (block in blockRegex.findAll(html)) {
            val content = block.groupValues[1]
            val titleMatch = titleRegex.find(content) ?: continue
            val url = htmlDecode(titleMatch.groupValues[1]).trim()
            val title = stripHtml(titleMatch.groupValues[2])
            val snippetMatch = snippetRegex.find(content)
            val snippet = stripHtml(snippetMatch?.groupValues?.getOrNull(1).orEmpty().ifBlank {
                snippetMatch?.groupValues?.getOrNull(2).orEmpty()
            })
            if (title.isNotBlank() && url.isNotBlank()) {
                results += WebSearchResult(title = title, url = url, snippet = snippet)
            }
            if (results.size >= limit) break
        }
        return results
    }

    private fun stripHtml(text: String): String =
        htmlDecode(text.replace(Regex("<[^>]+>"), " "))
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun htmlDecode(text: String): String = text
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&#x27;", "'")
        .replace("&middot;", "·")
}
