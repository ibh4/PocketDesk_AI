package com.pengwc.clawmemorylocal

object ThinkContentParser {
    private val thinkRegex = Regex(
        "<think>(.*?)</think>",
        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE),
    )
    private val danglingCloseTagRegex = Regex("</think>", RegexOption.IGNORE_CASE)
    private val englishThinkingHeaderRegex = Regex(
        "(?is)^\\s*thinking\\s*process\\s*:\\s*.*?(?:\\n\\s*\\n|$)(.*)$"
    )

    fun parse(raw: String, maxNewTokens: Int): GenerationText {
        val thinking = thinkRegex.find(raw)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        val visible = strip(raw)
        val reachedLimit = raw.contains("MAX_TOKENS_FINISHED", ignoreCase = true) ||
            raw.length >= maxNewTokens * 12
        return GenerationText(
            visibleAnswer = if (visible.isNotBlank()) visible else if (thinking.isBlank()) raw.trim() else "",
            thinking = thinking,
            reachedLimit = reachedLimit,
        )
    }

    fun strip(text: String): String {
        if (text.isBlank()) return ""
        var cleaned = text.replace(thinkRegex, "").replace(danglingCloseTagRegex, "").trim()
        cleaned = extractAfterThinkingHeader(cleaned)
        return cleaned.trim()
    }

    private fun extractAfterThinkingHeader(text: String): String {
        val match = englishThinkingHeaderRegex.find(text) ?: return text
        val tail = match.groupValues.getOrNull(1).orEmpty().trim()
        if (tail.isNotBlank()) return tail
        return text
    }
}
