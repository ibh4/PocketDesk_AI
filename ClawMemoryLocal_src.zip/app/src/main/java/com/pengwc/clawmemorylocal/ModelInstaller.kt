package com.pengwc.clawmemorylocal

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

object ModelInstaller {
    private const val MODEL_NAME = "Qwen3.5-0.8B-MNN"
    private const val ASSET_ROOT = "models/$MODEL_NAME"
    private val requiredFiles = listOf(
        "config.json",
        "llm.mnn",
        "llm.mnn.weight",
        "llm_config.json",
        "tokenizer.txt",
        "visual.mnn",
        "visual.mnn.weight",
    )

    suspend fun ensureInstalled(
        context: Context,
        threadCount: Int,
        maxNewTokens: Int,
        onStatus: (ModelStatus) -> Unit,
    ): File =
        withContext(Dispatchers.IO) {
            onStatus(ModelStatus.Unpacking)
            val targetDir = File(context.filesDir, "models/$MODEL_NAME")
            targetDir.mkdirs()
            copyAssetTree(context, ASSET_ROOT, targetDir)
            val missing = requiredFiles.filter { !File(targetDir, it).exists() }
            check(missing.isEmpty()) { "Missing model files: ${missing.joinToString()}" }
            writeRuntimeConfig(targetDir, threadCount.coerceIn(1, 4), maxNewTokens.coerceIn(128, 512))
        }

    private fun writeRuntimeConfig(targetDir: File, threadCount: Int, maxNewTokens: Int): File {
        val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
        val sourceConfig = json.parseToJsonElement(File(targetDir, "config.json").readText()).jsonObject
        val sourceLlmConfig = json.parseToJsonElement(File(targetDir, "llm_config.json").readText()).jsonObject
        val textLlmConfig = mergeObject(sourceLlmConfig) {
            put("is_visual", false)
            put("is_audio", false)
            put("has_talker", false)
        }
        File(targetDir, "llm_text_config.json").writeText(json.encodeToString(JsonObject.serializer(), textLlmConfig))
        val runtimeConfig = mergeObject(sourceConfig) {
            put("llm_config", "llm_text_config.json")
            put("backend_type", "cpu")
            put("thread_num", threadCount)
            put("max_new_tokens", maxNewTokens)
            put("async", false)
            put("use_mmap", true)
            put("reuse_kv", false)
            put("prompt_cache", false)
            put("is_visual", false)
            put("is_audio", false)
            put("has_talker", false)
            put("mllm", buildJsonObject {
                put("backend_type", "cpu")
                put("thread_num", threadCount)
                put("precision", "low")
                put("memory", "low")
            })
            put("jinja", buildJsonObject {
                put("context", buildJsonObject {
                    put("enable_thinking", false)
                })
            })
        }
        return File(targetDir, "runtime_text_config.json").also {
            it.writeText(json.encodeToString(JsonObject.serializer(), runtimeConfig))
        }
    }

    private inline fun mergeObject(source: JsonObject, block: MutableMapBuilder.() -> Unit): JsonObject {
        val map = source.toMutableMap()
        MutableMapBuilder(map).block()
        return JsonObject(map)
    }

    private class MutableMapBuilder(private val map: MutableMap<String, kotlinx.serialization.json.JsonElement>) {
        fun put(key: String, value: String) { map[key] = kotlinx.serialization.json.JsonPrimitive(value) }
        fun put(key: String, value: Int) { map[key] = kotlinx.serialization.json.JsonPrimitive(value) }
        fun put(key: String, value: Boolean) { map[key] = kotlinx.serialization.json.JsonPrimitive(value) }
        fun put(key: String, value: kotlinx.serialization.json.JsonElement) { map[key] = value }
    }

    private fun copyAssetTree(context: Context, assetPath: String, targetDir: File) {
        val assets = context.assets
        val children = assets.list(assetPath).orEmpty()
        if (children.isEmpty()) {
            if (targetDir.exists() && targetDir.length() > 0L) return
            targetDir.parentFile?.mkdirs()
            assets.open(assetPath).use { input ->
                targetDir.outputStream().use { output -> input.copyTo(output) }
            }
            return
        }
        targetDir.mkdirs()
        children.forEach { child ->
            copyAssetTree(context, "$assetPath/$child", File(targetDir, child))
        }
    }
}
