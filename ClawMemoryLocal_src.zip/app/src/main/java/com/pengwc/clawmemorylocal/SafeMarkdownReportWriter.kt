package com.pengwc.clawmemorylocal

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class SafeMarkdownReportWriter(context: Context) {
    private val appContext = context.applicationContext
    private val formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
    private val internalDir = File(appContext.filesDir, "PocketDeskAI/note/file_summary")

    suspend fun saveInternal(markdown: String): File = withContext(Dispatchers.IO) {
        internalDir.mkdirs()
        val base = "FileNameReport_${LocalDateTime.now().format(formatter)}"
        var target = File(internalDir, "$base.md")
        var index = 1
        while (target.exists()) {
            target = File(internalDir, "${base}_$index.md")
            index++
        }
        target.writeText(markdown.trim() + "\n")
        target
    }

    suspend fun saveToAuthorizedFolder(folderUri: String, markdown: String): String = withContext(Dispatchers.IO) {
        val uri = Uri.parse(folderUri)
        val root = DocumentFile.fromTreeUri(appContext, uri) ?: error("授权文件夹不可用")
        val base = "PocketDeskAI_FileNameReport_${LocalDateTime.now().format(formatter)}"
        var candidate = "$base.md"
        var index = 1
        while (root.findFile(candidate) != null) {
            candidate = "${base}_$index.md"
            index++
        }
        val file = root.createFile("text/markdown", candidate)
            ?: error("无法在授权文件夹创建文件")
        appContext.contentResolver.openOutputStream(file.uri)?.use { out ->
            out.write((markdown.trim() + "\n").toByteArray())
        } ?: error("无法写入授权文件夹")
        candidate
    }
}
