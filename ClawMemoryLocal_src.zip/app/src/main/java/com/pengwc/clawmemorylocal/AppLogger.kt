package com.pengwc.clawmemorylocal

import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime

class AppLogger(context: Context) {
    private val appContext = context.applicationContext
    private val logsDir = File(appContext.filesDir, "logs")
    private val shareDir = File(appContext.cacheDir, "share")
    val runtimeLogFile = File(logsDir, "runtime_log.txt")
    val modelLogFile = File(logsDir, "model_log.txt")
    val crashLogFile = File(logsDir, "crash_log.txt")
    val performanceLogFile = File(logsDir, "performance_log.txt")
    val onlineApiLogFile = File(logsDir, "online_api_log.txt")
    val fileSearchLogFile = File(logsDir, "file_search_log.txt")
    val pythonLogFile = File(logsDir, "python_log.txt")
    val exitTraceFile = File(logsDir, "last_exit_trace.txt")

    suspend fun runtime(message: String, throwable: Throwable? = null) = write(runtimeLogFile, message, throwable)
    suspend fun model(message: String, throwable: Throwable? = null) = write(modelLogFile, message, throwable)
    suspend fun crash(message: String, throwable: Throwable? = null) = write(crashLogFile, message, throwable)
    suspend fun performance(message: String, throwable: Throwable? = null) = write(performanceLogFile, message, throwable)
    suspend fun onlineApi(message: String) = write(onlineApiLogFile, sanitizeSecrets(message), null)
    suspend fun fileSearch(message: String, throwable: Throwable? = null) = write(fileSearchLogFile, sanitizeSecrets(message), throwable)
    suspend fun python(message: String, throwable: Throwable? = null) = write(pythonLogFile, sanitizeSecrets(message), throwable)

    suspend fun log(message: String, throwable: Throwable? = null) = runtime(message, throwable)

    suspend fun writeStartupInfo(modelConfig: File?, mode: PerformanceMode) {
        val dir = modelConfig?.parentFile
        runtime(
            """
            App 启动：
            设备型号：${Build.MANUFACTURER} ${Build.MODEL}
            Android 版本：${Build.VERSION.RELEASE} / SDK ${Build.VERSION.SDK_INT}
            ABI：${Build.SUPPORTED_ABIS.joinToString()}
            App 版本：0.1.0
            当前模式：${mode.label}
            """.trimIndent()
        )
        model(
            """
            模型启动信息：
            MNN 模型路径：${dir?.absolutePath.orEmpty()}
            config.json：${fileState(File(dir ?: appContext.filesDir, "config.json"))}
            llm.mnn：${fileState(File(dir ?: appContext.filesDir, "llm.mnn"))}
            llm.mnn.weight：${fileState(File(dir ?: appContext.filesDir, "llm.mnn.weight"))}
            当前线程数：${mode.threadCount}
            max_new_tokens：${mode.maxNewTokens}
            历史轮数限制：${mode.historyTurns}
            prompt 字符限制：${mode.promptCharLimit}
            """.trimIndent()
        )
    }

    suspend fun readSections(): LogSections = withContext(Dispatchers.IO) {
        LogSections(
            runtime = read(runtimeLogFile),
            model = read(modelLogFile),
            crash = read(crashLogFile),
            performance = read(performanceLogFile),
            onlineApi = read(onlineApiLogFile),
            fileSearch = read(fileSearchLogFile),
            python = read(pythonLogFile),
            lastExitTrace = read(exitTraceFile),
            runtimePath = runtimeLogFile.absolutePath,
            modelPath = modelLogFile.absolutePath,
            crashPath = crashLogFile.absolutePath,
            performancePath = performanceLogFile.absolutePath,
            onlineApiPath = onlineApiLogFile.absolutePath,
            fileSearchPath = fileSearchLogFile.absolutePath,
            pythonPath = pythonLogFile.absolutePath,
            lastExitTracePath = exitTraceFile.absolutePath,
        )
    }

    suspend fun readAllLogs(): String = withContext(Dispatchers.IO) {
        val sections = readSections()
        buildString {
            appendLine("## 运行日志")
            appendLine(sections.runtime.ifBlank { "暂无运行日志" })
            appendLine("## 模型日志")
            appendLine(sections.model.ifBlank { "暂无模型日志" })
            appendLine("## 崩溃日志")
            appendLine(sections.crash.ifBlank { "暂无崩溃日志" })
            appendLine("## 性能日志")
            appendLine(sections.performance.ifBlank { "暂无性能日志" })
            appendLine("## 线上 API 日志")
            appendLine(sections.onlineApi.ifBlank { "暂无线上 API 日志" })
            appendLine("## 文件检索日志")
            appendLine(sections.fileSearch.ifBlank { "暂无文件检索日志" })
            appendLine("## Python 日志")
            appendLine(sections.python.ifBlank { "暂无 Python 日志" })
            appendLine("## last_exit_trace")
            appendLine(sections.lastExitTrace.ifBlank { "暂无上次退出 trace" })
        }
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        logsDir.mkdirs()
        logsDir.listFiles()?.forEach { it.delete() }
        runtimeLogFile.appendText("[${LocalDateTime.now()}] 日志已清空\n")
    }

    suspend fun createShareTxt(): File = withContext(Dispatchers.IO) {
        shareDir.mkdirs()
        File(shareDir, "ClawMemoryLocal_错误日志.txt").also {
            it.writeText(readAllLogs())
        }
    }

    private suspend fun write(file: File, message: String, throwable: Throwable? = null) = withContext(Dispatchers.IO) {
        logsDir.mkdirs()
        file.appendText(buildString {
            append("[")
            append(LocalDateTime.now())
            append("] ")
            append(message)
            throwable?.let {
                append("\n")
                append(it.stackTraceToString())
            }
            append("\n")
        })
    }

    private fun read(file: File): String = file.takeIf { it.exists() }?.readText().orEmpty()

    private fun fileState(file: File): String =
        if (file.exists()) "存在 / ${file.length()} bytes" else "不存在 / 0 bytes"

    private fun sanitizeSecrets(message: String): String =
        message.replace(Regex("Bearer\\s+[A-Za-z0-9._\\-]+", RegexOption.IGNORE_CASE), "Bearer ***")
}
