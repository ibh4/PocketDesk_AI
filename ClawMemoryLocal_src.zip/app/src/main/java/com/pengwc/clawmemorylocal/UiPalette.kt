package com.pengwc.clawmemorylocal

import androidx.compose.ui.graphics.Color

val AppPageBackground = Color(0xFFF8FAFC)
val AppConversationBackground = Color(0xFFF1F5F9)
val AiTextColor = Color(0xFF111827)
val SecondaryTextColor = Color(0xFF6B7280)
val UserBubbleBackground = Color(0xFFEFF6FF)
val UserBubbleTextColor = Color(0xFF1E3A8A)
val UserBubbleBorder = Color(0xFFDBEAFE)
val PrimaryPurple = Color(0xFF2563EB)
val PrimaryPurplePressed = Color(0xFF0A48C5)
val InputBackground = Color(0xFFFFFFFF)
val InputBorder = Color(0xFFDBEAFE)
val DividerSoft = Color(0xFFE5E7EB)
