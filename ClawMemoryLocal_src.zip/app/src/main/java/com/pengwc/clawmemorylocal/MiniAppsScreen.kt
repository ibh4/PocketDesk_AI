package com.pengwc.clawmemorylocal

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private val wheelFoods = listOf("火锅", "拌面", "炒饭", "麻辣烫", "寿司", "汉堡", "黄焖鸡", "米线")
private val wheelColors = listOf(
    Color(0xFFFDE68A),
    Color(0xFFBFDBFE),
    Color(0xFFFBCFE8),
    Color(0xFFBBF7D0),
    Color(0xFFFED7AA),
    Color(0xFFDDD6FE),
    Color(0xFFA7F3D0),
    Color(0xFFFCA5A5),
)

@Composable
fun MiniAppsScreen(
    state: ChatUiState,
    onRouteChange: (MiniAppRouteState) -> Unit,
    onCodeChange: (String) -> Unit,
    onImportConsumed: () -> Unit,
    onFileFolderPicked: (Intent?) -> Unit,
    onFileSearchQueryChange: (String) -> Unit,
    onFileSearchFilterChange: (FileSearchFilter) -> Unit,
    onFileSearchSortChange: (FileSearchSort) -> Unit,
    onRefreshFileSearch: () -> Unit,
    onCancelFileSearchScan: () -> Unit,
    onDisconnectFileSearchFolder: () -> Unit,
    onClearFileSearchIndex: () -> Unit,
    onAnalyzeFileNames: () -> Unit,
    onSaveFileSearchReportInternal: () -> Unit,
    onSaveFileSearchReportToFolder: () -> Unit,
    onConfirmFileSearchAnalyzeLocal: () -> Unit,
    onConfirmFileSearchAnalyzeOnline: () -> Unit,
    onDismissFileSearchAnalyzeDialog: () -> Unit,
    onToggleFileSearchReadWrite: () -> Unit,
    onOpenBubbleNote: () -> Unit = {},
    onRunTodayAnalysis: (String) -> Unit = {},
    onSaveTodayAnalysis: () -> Unit = {},
    customApp1Name: String = "自定义小程序 1",
    customApp1Code: String = "",
    customApp2Name: String = "自定义小程序 2",
    customApp2Code: String = "",
) {
    val context = LocalContext.current
    val noteRepository = remember { NoteRepository(context) }
    val logger = remember { AppLogger(context) }
    val pythonEngine = remember { PythonEngine(context, logger) }
    val scope = rememberCoroutineScope()
    var pythonResult by remember { mutableStateOf<PythonRunResult?>(null) }
    var runningPython by rememberSaveable { mutableStateOf(false) }
    var lastHandledImportToken by rememberSaveable { mutableIntStateOf(0) }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            onFileFolderPicked(result.data)
        }
    }

    LaunchedEffect(state.miniAppRoute) {
        when (state.miniAppRoute) {
            MiniAppRouteState.Menu -> logger.python("Python 小工具菜单可见")
            MiniAppRouteState.Wheel -> logger.runtime("打开小程序：吃什么大转盘")
            MiniAppRouteState.Python -> logger.python("Python 小工具打开")
            MiniAppRouteState.FileSearch -> logger.fileSearch("文件检索页面打开")
            MiniAppRouteState.BubbleNote -> logger.runtime("随机冒泡笔记打开")
            MiniAppRouteState.TodayAnalysis -> logger.runtime("今日分析打开")
            MiniAppRouteState.DeepSpace -> logger.runtime("深空死寂打开")
            MiniAppRouteState.CustomApp1 -> logger.runtime("自定义小程序1打开")
            MiniAppRouteState.CustomApp2 -> logger.runtime("自定义小程序2打开")
        }
    }

    LaunchedEffect(state.pythonToolImportToken) {
        if (
            state.pythonToolImportToken > 0 &&
            state.pythonToolImportToken != lastHandledImportToken &&
            state.miniAppRoute == MiniAppRouteState.Python &&
            !runningPython
        ) {
            lastHandledImportToken = state.pythonToolImportToken
            runningPython = true
            val result = pythonEngine.run(state.pythonToolCode)
            pythonResult = result
            runningPython = false
            onImportConsumed()
        }
    }

    AnimatedContent(targetState = state.miniAppRoute, label = "mini-app-route") { current ->
        when (current) {
            MiniAppRouteState.Menu -> MiniAppsMenu(
                onWheelClick = { onRouteChange(MiniAppRouteState.Wheel) },
                onPythonClick = { onRouteChange(MiniAppRouteState.Python) },
                onFileSearchClick = { onRouteChange(MiniAppRouteState.FileSearch) },
                onBubbleNoteClick = { onOpenBubbleNote(); onRouteChange(MiniAppRouteState.BubbleNote) },
                onTodayAnalysisClick = { onRouteChange(MiniAppRouteState.TodayAnalysis) },
                onDeepSpaceClick = { onRouteChange(MiniAppRouteState.DeepSpace) },
                onCustomApp1Click = { onRouteChange(MiniAppRouteState.CustomApp1) },
                onCustomApp2Click = { onRouteChange(MiniAppRouteState.CustomApp2) },
                customApp1Name = state.customApp1Name,
                customApp1Code = state.customApp1Code,
                customApp2Name = state.customApp2Name,
                customApp2Code = state.customApp2Code,
            )
            MiniAppRouteState.Wheel -> WheelMiniApp(onBack = { onRouteChange(MiniAppRouteState.Menu) })
            MiniAppRouteState.Python -> PythonToolScreen(
                code = state.pythonToolCode,
                result = pythonResult,
                running = runningPython,
                onCodeChange = onCodeChange,
                onRun = {
                    if (runningPython) return@PythonToolScreen
                    runningPython = true
                    scope.launch {
                        val result = pythonEngine.run(state.pythonToolCode)
                        pythonResult = result
                        runningPython = false
                    }
                },
                onClear = {
                    onCodeChange(DEFAULT_PYTHON_TOOL_CODE.trimIndent())
                    pythonResult = null
                },
                onSave = {
                    val result = pythonResult
                    if (result == null) {
                        Toast.makeText(context, "请先运行代码", Toast.LENGTH_SHORT).show()
                        return@PythonToolScreen
                    }
                    scope.launch(Dispatchers.IO) {
                        runCatching {
                            noteRepository.savePythonRunRecord(state.pythonToolCode, result)
                            logger.python("保存结果到笔记成功：date=${LocalDateTime.now().toLocalDate()}")
                        }.onSuccess {
                            launch(Dispatchers.Main) {
                                Toast.makeText(context, "已保存到今日笔记", Toast.LENGTH_SHORT).show()
                            }
                        }.onFailure {
                            logger.python("保存结果到笔记失败", it)
                            launch(Dispatchers.Main) {
                                Toast.makeText(context, "保存失败，请查看错误日志", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
            )
            MiniAppRouteState.FileSearch -> FileSearchScreen(
                state = state.fileSearch,
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
                onPickFolder = {
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                        )
                    }
                    folderPicker.launch(intent)
                },
                onRefreshScan = onRefreshFileSearch,
                onCancelScan = onCancelFileSearchScan,
                onDisconnectFolder = onDisconnectFileSearchFolder,
                onClearIndex = onClearFileSearchIndex,
                onQueryChange = onFileSearchQueryChange,
                onFilterChange = onFileSearchFilterChange,
                onSortChange = onFileSearchSortChange,
                onAnalyze = onAnalyzeFileNames,
                onSaveReportInternal = onSaveFileSearchReportInternal,
                onSaveReportToFolder = onSaveFileSearchReportToFolder,
                onConfirmAnalyzeLocal = onConfirmFileSearchAnalyzeLocal,
                onConfirmAnalyzeOnline = onConfirmFileSearchAnalyzeOnline,
                onDismissAnalyzeDialog = onDismissFileSearchAnalyzeDialog,
                onToggleReadWrite = onToggleFileSearchReadWrite,
            )
            MiniAppRouteState.BubbleNote -> BubbleNoteScreen(
                state = state,
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
                onRefresh = onOpenBubbleNote,
            )
            MiniAppRouteState.TodayAnalysis -> TodayAnalysisScreen(
                state = state,
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
                onRunAnalysis = onRunTodayAnalysis,
                onSaveAnalysis = onSaveTodayAnalysis,
            )
            MiniAppRouteState.DeepSpace -> DeepSpaceScreen(onBack = { onRouteChange(MiniAppRouteState.Menu) })
            MiniAppRouteState.CustomApp1 -> CustomAppScreen(
                appName = state.customApp1Name,
                code = state.customApp1Code,
                buttons = state.customApp1Buttons,
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
            )
            MiniAppRouteState.CustomApp2 -> CustomAppScreen(
                appName = state.customApp2Name,
                code = state.customApp2Code,
                buttons = state.customApp2Buttons,
                onBack = { onRouteChange(MiniAppRouteState.Menu) },
            )
        }
    }
}

@Composable
private fun MiniAppsMenu(
    onWheelClick: () -> Unit,
    onPythonClick: () -> Unit,
    onFileSearchClick: () -> Unit,
    onBubbleNoteClick: () -> Unit,
    onTodayAnalysisClick: () -> Unit,
    onDeepSpaceClick: () -> Unit,
    onCustomApp1Click: () -> Unit,
    onCustomApp2Click: () -> Unit,
    customApp1Name: String,
    customApp1Code: String,
    customApp2Name: String,
    customApp2Code: String,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("小程序", color = AiTextColor)
        MiniAppMenuCard(
            title = "吃什么大转盘",
            subtitle = "随机选择今天吃什么",
            icon = { WheelIconCanvas() },
            onClick = onWheelClick,
        )
        MiniAppMenuCard(
            title = "Python 小工具",
            subtitle = "本地运行简单 Python 代码",
            icon = { PythonIconCanvas() },
            onClick = onPythonClick,
        )
        MiniAppMenuCard(
            title = "文件检索",
            subtitle = "选择文件夹，仅扫描文件名，快速搜索和整理",
            icon = { FileSearchIconCanvas() },
            onClick = onFileSearchClick,
        )
        MiniAppMenuCard(
            title = "随机冒泡笔记",
            subtitle = "随机回顾一篇历史笔记，防止遗忘",
            icon = { BubbleIconCanvas() },
            onClick = onBubbleNoteClick,
        )
        MiniAppMenuCard(
            title = "今日任务分析",
            subtitle = "AI 分析今日对话/笔记/Python 代码",
            icon = { AnalysisIconCanvas() },
            onClick = onTodayAnalysisClick,
        )
        MiniAppMenuCard(
            title = "🛸 深空死寂",
            subtitle = "Markdown 文字生存冒险 · 10回合",
            icon = { DeepSpaceIconCanvas() },
            onClick = onDeepSpaceClick,
        )
        val hasCustom1 = customApp1Code.isNotBlank()
        val hasCustom2 = customApp2Code.isNotBlank()
        MiniAppMenuCard(
            title = if (hasCustom1) customApp1Name else "自定义小程序 ①",
            subtitle = if (hasCustom1) "AI 定制 · 点击运行" else "待 AI 定制，点击无反应",
            icon = { CustomAppIconCanvas(1) },
            onClick = if (hasCustom1) onCustomApp1Click else ({ }),
        )
        MiniAppMenuCard(
            title = if (hasCustom2) customApp2Name else "自定义小程序 ②",
            subtitle = if (hasCustom2) "AI 定制 · 点击运行" else "待 AI 定制，点击无反应",
            icon = { CustomAppIconCanvas(2) },
            onClick = if (hasCustom2) onCustomApp2Click else ({ }),
        )
    }
}

@Composable
private fun WheelMiniApp(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }
    var currentFood by remember { mutableStateOf("今天吃什么？") }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var spinning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
        ) {
            Text("返回小程序")
        }
        Spacer(Modifier.height(18.dp))
        Text("吃什么随机大转盘", color = AiTextColor)
        Spacer(Modifier.height(18.dp))
        Canvas(modifier = Modifier.size(280.dp)) {
            val sweep = 360f / wheelFoods.size
            val wheelCenter = Offset(size.width / 2f, size.height / 2f)
            rotate(rotation.value) {
                wheelFoods.forEachIndexed { index, label ->
                    drawArc(
                        color = wheelColors[index % wheelColors.size],
                        startAngle = index * sweep - 90f,
                        sweepAngle = sweep,
                        useCenter = true,
                        topLeft = Offset.Zero,
                        size = Size(size.width, size.height),
                    )
                    val angle = Math.toRadians((index * sweep + sweep / 2f - 90f).toDouble())
                    val radius = size.minDimension * 0.34f
                    val x = wheelCenter.x + cos(angle).toFloat() * radius
                    val y = wheelCenter.y + sin(angle).toFloat() * radius
                    drawContext.canvas.nativeCanvas.drawText(
                        label,
                        x,
                        y,
                        android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            textAlign = android.graphics.Paint.Align.CENTER
                            textSize = 38f
                            isFakeBoldText = true
                        },
                    )
                }
            }
            drawCircle(color = Color.White, radius = size.minDimension * 0.18f, center = wheelCenter)
            drawCircle(color = PrimaryPurple, radius = size.minDimension * 0.05f, center = wheelCenter)
            drawLine(
                color = Color(0xFFEF4444),
                start = Offset(wheelCenter.x, 0f),
                end = Offset(wheelCenter.x, size.minDimension * 0.12f),
                strokeWidth = 10f,
            )
        }
        Spacer(Modifier.height(18.dp))
        Text("结果：$currentFood", color = AiTextColor)
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (spinning) return@Button
                spinning = true
                val winner = Random.nextInt(wheelFoods.size)
                selectedIndex = winner
                val sweep = 360f / wheelFoods.size
                val target = rotation.value + 1440f + (360f - (winner * sweep + sweep / 2f))
                scope.launch {
                    rotation.animateTo(
                        targetValue = target,
                        animationSpec = tween(durationMillis = 3200, easing = FastOutSlowInEasing),
                    )
                    currentFood = wheelFoods[selectedIndex]
                    spinning = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
        ) {
            Text(if (spinning) "转动中..." else "开始转盘")
        }
    }
}

@Composable
private fun BubbleNoteScreen(
    state: ChatUiState,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize().background(AppPageBackground).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = onBack) { Text("← 返回", color = PrimaryPurple, fontSize = 12.sp) }
            OutlinedButton(onClick = onRefresh) { Text("再换一篇", color = PrimaryPurple, fontSize = 12.sp) }
            OutlinedButton(onClick = {
                copyText(context, state.bubbleNoteName, state.bubbleNoteContent)
                Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
            }) { Text("复制", color = PrimaryPurple, fontSize = 12.sp) }
        }
        if (state.bubbleNoteName.isNotBlank()) {
            Text(state.bubbleNoteName.removeSuffix(".md"), color = AiTextColor, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        if (state.bubbleNoteContent.isNotBlank()) {
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(12.dp)).border(1.dp, DividerSoft, RoundedCornerShape(12.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
            ) {
                MarkdownView(markdown = state.bubbleNoteContent)
            }
        } else {
            Text("暂无笔记内容", color = SecondaryTextColor)
        }
    }
}

@Composable
private fun TodayAnalysisScreen(
    state: ChatUiState,
    onBack: () -> Unit,
    onRunAnalysis: (String) -> Unit,
    onSaveAnalysis: () -> Unit,
) {
    val context = LocalContext.current
    val types = listOf("chat" to "对话分析", "notes" to "笔记分析", "python" to "Python分析")
    Column(
        modifier = Modifier.fillMaxSize().background(AppPageBackground).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(onClick = onBack) { Text("← 返回", color = PrimaryPurple, fontSize = 12.sp) }
            types.forEach { (key, label) ->
                val isActive = state.todayAnalysisType == key
                Button(
                    onClick = { onRunAnalysis(key) },
                    enabled = !state.isAnalyzingToday,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isActive) PrimaryPurple else Color(0xFFE5E7EB),
                        contentColor = if (isActive) Color.White else AiTextColor,
                    ),
                ) { Text(label, fontSize = 12.sp) }
            }
            if (state.todayAnalysisMarkdown.isNotBlank()) {
                OutlinedButton(onClick = {
                    copyText(context, "今日分析", state.todayAnalysisMarkdown)
                    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
                }) { Text("复制", color = PrimaryPurple, fontSize = 12.sp) }
                OutlinedButton(onClick = onSaveAnalysis) { Text("保存", color = PrimaryPurple, fontSize = 12.sp) }
            }
        }
        if (state.isAnalyzingToday) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp).padding(end = 8.dp), strokeWidth = 2.dp)
                Text("AI 正在分析...", color = SecondaryTextColor, fontSize = 13.sp)
            }
        }
        if (state.todayAnalysisMarkdown.isNotBlank()) {
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(12.dp)).border(1.dp, DividerSoft, RoundedCornerShape(12.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
            ) {
                MarkdownView(markdown = state.todayAnalysisMarkdown)
            }
        }
    }
}

@Composable
private fun BubbleIconCanvas() {
    Canvas(modifier = Modifier.size(24.dp)) {
        drawCircle(color = PrimaryPurple, radius = size.minDimension * 0.35f, center = androidx.compose.ui.geometry.Offset(size.width * 0.4f, size.height * 0.4f))
        drawCircle(color = PrimaryPurple, radius = size.minDimension * 0.25f, center = androidx.compose.ui.geometry.Offset(size.width * 0.65f, size.height * 0.3f))
        drawCircle(color = PrimaryPurple, radius = size.minDimension * 0.2f, center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.65f))
    }
}

@Composable
private fun AnalysisIconCanvas() {
    Canvas(modifier = Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        drawRect(color = PrimaryPurple, topLeft = Offset(w * 0.1f, h * 0.4f), size = Size(w * 0.25f, h * 0.5f))
        drawRect(color = PrimaryPurple, topLeft = Offset(w * 0.4f, h * 0.2f), size = Size(w * 0.25f, h * 0.7f))
        drawRect(color = PrimaryPurple, topLeft = Offset(w * 0.7f, h * 0.1f), size = Size(w * 0.2f, h * 0.8f))
    }
}

@Composable
private fun CustomAppScreen(appName: String, code: String, buttons: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val logger = remember { AppLogger(context) }
    val pythonEngine = remember { PythonEngine(context, logger) }
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<PythonRunResult?>(null) }
    var running by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val btnRows = if (buttons.isNotBlank()) buttons.split("|").map { it.split(",").map { b -> b.trim() } } else emptyList()

    Column(
        modifier = Modifier.fillMaxSize().background(AppPageBackground).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row {
            OutlinedButton(onClick = onBack) { Text("← 返回", color = PrimaryPurple, fontSize = 12.sp) }
        }
        if (code.isBlank()) {
            Text("此小程序尚未定制。请在对话中说「帮我创建自定义小程序」", color = SecondaryTextColor, fontSize = 14.sp)
        } else {
            Text(appName, color = AiTextColor, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            if (btnRows.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    OutlinedButton(onClick = {
                        scope.launch {
                            running = true
                            val safeInput = input.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
                            result = pythonEngine.run("user_input = \"$safeInput\"\n" + code, timeoutMs = 5000)
                            running = false
                        }
                    }, enabled = !running) { Text(if (running) "..." else "运行", color = PrimaryPurple, fontSize = 12.sp) }
                    OutlinedButton(onClick = { input = ""; result = null }) { Text("清空", fontSize = 12.sp, color = SecondaryTextColor) }
                }
                if (input.isNotBlank()) {
                    Text("输入: $input", color = AiTextColor, fontSize = 13.sp)
                }
                btnRows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        row.forEach { label ->
                            Button(
                                onClick = { input += label },
                                modifier = Modifier.weight(1f).height(44.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                                shape = RoundedCornerShape(10.dp),
                            ) { Text(label, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            } else {
                OutlinedButton(
                    onClick = {
                        if (running) return@OutlinedButton
                        running = true
                        result = null
                        scope.launch {
                            result = pythonEngine.run(code)
                            running = false
                        }
                    },
                    enabled = !running,
                ) { Text(if (running) "运行中..." else "▶ 运行", color = PrimaryPurple) }
            }
            if (running) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("运行中...", color = SecondaryTextColor, fontSize = 13.sp)
                }
            }
            result?.let { r ->
                Column(
                    modifier = Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(12.dp)).border(1.dp, DividerSoft, RoundedCornerShape(12.dp)).verticalScroll(rememberScrollState()).padding(12.dp),
                ) {
                    Text("输出", color = AiTextColor, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(r.stdout.ifBlank { "（无输出）" }, color = AiTextColor, fontSize = 13.sp, lineHeight = 20.sp)
                    if (r.stderr.isNotBlank() || r.traceback.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text("错误", color = Color(0xFFDC2626), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(r.traceback.ifBlank { r.stderr }, color = Color(0xFFDC2626), fontSize = 12.sp)
                    }
                    Text("耗时 ${r.durationMs}ms", color = SecondaryTextColor, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun CustomAppIconCanvas(slot: Int) {
    Canvas(modifier = Modifier.size(24.dp)) {
        val color = if (slot == 1) PrimaryPurple else Color(0xFF7C3AED)
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.4f
        drawCircle(color = color, radius = r, center = Offset(cx, cy))
        drawCircle(color = Color.White, radius = r * 0.5f, center = Offset(cx, cy))
        drawLine(color = color, start = Offset(cx, cy - r * 0.3f), end = Offset(cx, cy + r * 0.3f), strokeWidth = 3f)
        drawLine(color = color, start = Offset(cx - r * 0.3f, cy), end = Offset(cx + r * 0.3f, cy), strokeWidth = 3f)
    }
}

@Composable
private fun DeepSpaceIconCanvas() {
    Canvas(modifier = Modifier.size(24.dp)) {
        drawCircle(color = Color.Black, radius = size.minDimension * 0.45f, center = Offset(size.width / 2f, size.height / 2f))
        drawCircle(color = Color(0xFF00FFAA), radius = size.minDimension * 0.12f, center = Offset(size.width * 0.5f, size.height * 0.35f))
        drawCircle(color = Color(0xFFFF3B30), radius = size.minDimension * 0.08f, center = Offset(size.width * 0.7f, size.height * 0.55f))
        drawCircle(color = Color(0xFFFFCC00), radius = size.minDimension * 0.1f, center = Offset(size.width * 0.3f, size.height * 0.65f))
    }
}
