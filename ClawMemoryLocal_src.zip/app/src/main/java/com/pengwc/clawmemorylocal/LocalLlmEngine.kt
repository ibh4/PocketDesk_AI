package com.pengwc.clawmemorylocal

import android.content.Context
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

object LocalLlmEngine {
    private const val LOAD_TIMEOUT_MS = 45_000L
    private val dispatcher: CoroutineDispatcher =
        Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "local-mnn-llm") }
            .asCoroutineDispatcher()
    private val generateMutex = Mutex()
    private val loadingMutex = Mutex()
    private val native = NativeMnnLlm()
    private val isGeneratingAtomic = AtomicBoolean(false)
    private var loadedConfig: File? = null
    private var loadedThreadCount: Int = 0
    private var loadedMaxNewTokens: Int = 0

    val isGenerating: Boolean get() = isGeneratingAtomic.get()

    suspend fun ensureLoaded(
        context: Context,
        logger: AppLogger,
        threadCount: Int,
        maxNewTokens: Int,
        forceReload: Boolean = false,
        onStatus: (ModelStatus) -> Unit,
    ): File = loadingMutex.withLock {
        val config = ModelInstaller.ensureInstalled(context, threadCount, maxNewTokens, onStatus)
        if (!forceReload && native.isLoaded && loadedConfig?.absolutePath == config.absolutePath &&
            loadedThreadCount == threadCount && loadedMaxNewTokens == maxNewTokens
        ) {
            return@withLock config
        }
        if (!native.isLoaded) {
            loadedConfig = null
            loadedThreadCount = 0
            loadedMaxNewTokens = 0
        }
        if (isGenerating) error("模型正在生成中，不能重新加载")
        onStatus(ModelStatus.Loading)
        try {
            withTimeout(LOAD_TIMEOUT_MS) {
                withContext(dispatcher) {
                    native.close()
                    native.load(config.absolutePath, CHINESE_SYSTEM_PROMPT.trim(), threadCount, maxNewTokens)
                }
            }
        } catch (t: Throwable) {
            withContext(dispatcher) { native.close() }
            loadedConfig = null
            loadedThreadCount = 0
            loadedMaxNewTokens = 0
            logger.model("模型加载失败，已清理旧会话", t)
            throw t
        }
        loadedConfig = config
        loadedThreadCount = threadCount
        loadedMaxNewTokens = maxNewTokens
        logger.model("模型已加载：thread_num=$threadCount, max_new_tokens=$maxNewTokens, config=${config.absolutePath}")
        config
    }

    suspend fun generate(
        prompt: PromptBuildResult,
        maxNewTokens: Int,
        logger: AppLogger,
        onPartial: (String) -> Unit,
    ): String {
        if (!generateMutex.tryLock()) return "模型正在生成中，请稍候"
        if (!isGeneratingAtomic.compareAndSet(false, true)) {
            generateMutex.unlock()
            return "模型正在生成中，请稍候"
        }
        return try {
            val start = System.currentTimeMillis()
            logger.model(
                "开始推理：promptChars=${prompt.promptChars}, estimatedTokens=${prompt.estimatedTokens}, " +
                    "historyTurns=${prompt.historyTurns}, memoryChars=${prompt.memoryChars}, workspaceChars=${prompt.workspaceChars}, " +
                    "max_new_tokens=$maxNewTokens, thread_num=$loadedThreadCount, mode=${prompt.performanceMode.label}"
            )
            withContext(dispatcher) {
                val buffer = StringBuilder()
                var lastEmit = 0L
                var firstTokenAt = 0L
                val result = native.generate(prompt.messages, maxNewTokens) { token ->
                    if (firstTokenAt == 0L) firstTokenAt = System.currentTimeMillis()
                    buffer.append(token)
                    val now = System.currentTimeMillis()
                    if (now - lastEmit >= 150L) {
                        lastEmit = now
                        onPartial(buffer.toString())
                    }
                    false
                }
                val finalText = result.ifBlank { buffer.toString() }
                onPartial(finalText)
                val end = System.currentTimeMillis()
                logger.performance(
                    "生成完成：首 token=${if (firstTokenAt == 0L) -1 else firstTokenAt - start}ms, " +
                        "总耗时=${end - start}ms, 回复字符数=${finalText.length}, UI刷新间隔=150ms"
                )
                logger.model("推理结束：status=success")
                finalText
            }
        } catch (t: Throwable) {
            logger.model("推理失败", t)
            throw t
        } finally {
            isGeneratingAtomic.set(false)
            generateMutex.unlock()
        }
    }

    suspend fun reset() = withContext(dispatcher) { native.reset() }

    suspend fun release() = withContext(dispatcher) {
        native.close()
        loadedConfig = null
        loadedThreadCount = 0
        loadedMaxNewTokens = 0
        isGeneratingAtomic.set(false)
    }
}
