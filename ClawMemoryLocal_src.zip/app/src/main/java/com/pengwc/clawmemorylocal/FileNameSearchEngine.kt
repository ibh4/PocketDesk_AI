package com.pengwc.clawmemorylocal

import java.text.DecimalFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object FileNameSearchEngine {
    private val codeExtensions = setOf(
        "py", "kt", "kts", "java", "js", "ts", "tsx", "jsx", "cpp", "c", "h", "hpp",
        "go", "rs", "swift", "sh", "sql", "gradle", "xml", "html", "css", "json", "yaml", "yml"
    )
    private val textExtensions = setOf("txt", "log", "csv", "md", "markdown", "json", "yaml", "yml")
    private val imageExtensions = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "heic")
    private val fileIntentKeywords = listOf("找一下文件", "搜索文件", "这个文件夹里有什么", "总结文件名", "整理文件夹", "有没有", "文件名")
    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm", Locale.CHINA)

    fun search(
        records: List<FileNameRecord>,
        query: String,
        filter: FileSearchFilter,
        sort: FileSearchSort,
    ): List<FileNameRecord> {
        val normalized = query.trim().lowercase(Locale.getDefault())
        return records
            .asSequence()
            .filter { matchesFilter(it, filter) }
            .filter {
                normalized.isBlank() ||
                    it.name.lowercase(Locale.getDefault()).contains(normalized) ||
                    it.relativePath.lowercase(Locale.getDefault()).contains(normalized)
            }
            .sortedWith(sortComparator(sort))
            .toList()
    }

    fun isFileSearchIntent(query: String): Boolean {
        val normalized = query.trim()
        return fileIntentKeywords.any { normalized.contains(it, ignoreCase = true) }
    }

    fun buildChatContext(query: String, records: List<FileNameRecord>): String {
        if (records.isEmpty()) return ""
        val sample = records.take(20)
        return buildString {
            appendLine("当前只检索了文件名和基础元数据，没有读取文件内容。")
            appendLine("用户问题：$query")
            appendLine("已匹配到以下文件/文件夹（最多 20 条）：")
            sample.forEachIndexed { index, record ->
                append(index + 1)
                append(". ")
                append(record.name)
                append(" | path=")
                append(record.relativePath)
                append(" | ext=")
                append(if (record.isDirectory) "folder" else record.extension.ifBlank { "none" })
                append(" | size=")
                append(readableSize(record.sizeBytes))
                append(" | modified=")
                append(formatTime(record.lastModified))
                appendLine()
            }
            appendLine("请明确说明：你的分析仅基于文件名和元数据，不代表真实文件内容。")
        }.trim()
    }

    fun buildAnalysisContext(records: List<FileNameRecord>, folderName: String, sourceHint: String): String {
        val sample = records.take(300)
        return buildString {
            appendLine("你是手机端本地文件整理助手。以下是用户授权文件夹内的文件名和元数据。请只基于文件名进行分析，不要假设文件内容。")
            appendLine("目标文件夹：${folderName.ifBlank { "未命名文件夹" }}")
            appendLine("数据来源：$sourceHint")
            appendLine()
            appendLine("请输出：")
            appendLine("1. 文件夹概览")
            appendLine("2. 文件类型分布")
            appendLine("3. 可能的项目结构")
            appendLine("4. 疑似重复或相似文件名")
            appendLine("5. 建议新建的分类目录")
            appendLine("6. 建议优先查看的文件")
            appendLine("7. Markdown 格式整理报告")
            appendLine()
            appendLine("文件名列表（最多 300 条）：")
            sample.forEach { record ->
                append("- name=")
                append(record.name)
                append(" | path=")
                append(record.relativePath)
                append(" | ext=")
                append(if (record.isDirectory) "folder" else record.extension.ifBlank { "none" })
                append(" | size=")
                append(readableSize(record.sizeBytes))
                append(" | modified=")
                append(formatTime(record.lastModified))
                appendLine()
            }
        }.trim()
    }

    fun formatTime(timestamp: Long): String {
        if (timestamp <= 0L) return "未知"
        return runCatching {
            dateFormatter.format(Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDateTime())
        }.getOrDefault("未知")
    }

    fun readableSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val unit = 1024.0
        val df = DecimalFormat("#.##")
        return when {
            bytes < unit -> "$bytes B"
            bytes < unit * unit -> "${df.format(bytes / unit)} KB"
            bytes < unit * unit * unit -> "${df.format(bytes / unit / unit)} MB"
            else -> "${df.format(bytes / unit / unit / unit)} GB"
        }
    }

    private fun matchesFilter(record: FileNameRecord, filter: FileSearchFilter): Boolean =
        when (filter) {
            FileSearchFilter.All -> true
            FileSearchFilter.Folder -> record.isDirectory
            FileSearchFilter.Markdown -> !record.isDirectory && record.extension in setOf("md", "markdown")
            FileSearchFilter.Text -> !record.isDirectory && record.extension in textExtensions
            FileSearchFilter.Code -> !record.isDirectory && record.extension in codeExtensions
            FileSearchFilter.Image -> !record.isDirectory && record.extension in imageExtensions
            FileSearchFilter.Other -> !record.isDirectory &&
                record.extension !in textExtensions &&
                record.extension !in codeExtensions &&
                record.extension !in imageExtensions
        }

    private fun sortComparator(sort: FileSearchSort): Comparator<FileNameRecord> =
        when (sort) {
            FileSearchSort.Name -> compareBy<FileNameRecord>({ !it.isDirectory }, { it.name.lowercase(Locale.getDefault()) })
            FileSearchSort.Modified -> compareByDescending<FileNameRecord> { it.lastModified }
                .thenBy { it.name.lowercase(Locale.getDefault()) }
            FileSearchSort.Size -> compareByDescending<FileNameRecord> { it.sizeBytes }
                .thenBy { it.name.lowercase(Locale.getDefault()) }
            FileSearchSort.Type -> compareBy<FileNameRecord>({ if (it.isDirectory) "folder" else it.extension }, { it.name.lowercase(Locale.getDefault()) })
        }
}

