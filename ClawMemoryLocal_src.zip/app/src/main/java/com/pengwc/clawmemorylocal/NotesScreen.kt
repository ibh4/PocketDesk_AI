package com.pengwc.clawmemorylocal

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesScreen(state: ChatUiState, viewModel: ChatViewModel) {
    val context = LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) viewModel.importNoteImage(uri)
    }
    val folderExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        viewModel.saveNotesToFolder(uri)
    }
    NotesScreenContent(
        state = state,
        onRefresh = viewModel::refreshNotes,
        onClearNotes = viewModel::requestClearNotes,
        onSelectNote = viewModel::selectNote,
        onBack = { viewModel.selectNote(null) },
        onCopy = { copyText(context, state.selectedNote.orEmpty(), state.selectedNoteContent) },
        onShare = { viewModel.shareSelectedNote(context) },
        onCreate = viewModel::startNewNote,
        onEdit = viewModel::editSelectedNote,
        onUpdateTitle = viewModel::updateEditingNoteName,
        onUpdateContent = viewModel::updateEditingNoteContent,
        onSave = viewModel::saveEditingNote,
        onCancelEdit = viewModel::cancelEditNote,
        onInsertImage = { imagePicker.launch(arrayOf("image/*")) },
        onToggleSelect = viewModel::toggleNoteSelection,
        onClearSelection = viewModel::clearNoteSelection,
        onDeleteSelected = viewModel::deleteSelectedNotes,
        onConfirmDelete = viewModel::confirmDeleteNotes,
        onCancelDelete = viewModel::cancelDeleteNotes,
        onRenameNote = viewModel::startRenameNote,
        onUpdateRename = viewModel::updateRenamingNewName,
        onConfirmRename = viewModel::confirmRenameNote,
        onCancelRename = viewModel::cancelRenameNote,
        onPinNote = viewModel::pinNote,
        onExportFolder = { folderExportPicker.launch(null) },
        isPinned = viewModel::isNotePinned,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NotesScreenContent(
    state: ChatUiState,
    onRefresh: () -> Unit,
    onClearNotes: () -> Unit,
    onSelectNote: (String) -> Unit,
    onBack: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onCreate: () -> Unit,
    onEdit: () -> Unit,
    onUpdateTitle: (String) -> Unit,
    onUpdateContent: (String) -> Unit,
    onSave: () -> Unit,
    onCancelEdit: () -> Unit,
    onInsertImage: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onClearSelection: () -> Unit,
    onDeleteSelected: () -> Unit,
    onConfirmDelete: () -> Unit,
    onCancelDelete: () -> Unit,
    onRenameNote: (String) -> Unit,
    onUpdateRename: (String) -> Unit,
    onConfirmRename: () -> Unit,
    onCancelRename: () -> Unit,
    onPinNote: (String) -> Unit,
    onExportFolder: () -> Unit,
    isPinned: (String) -> Boolean,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .padding(12.dp)
    ) {
        if (state.isEditingNote) {
            NoteEditor(
                state = state,
                onUpdateTitle = onUpdateTitle,
                onUpdateContent = onUpdateContent,
                onSave = onSave,
                onCancel = onCancelEdit,
                onInsertImage = onInsertImage,
            )
            return
        }

        if (state.selectedNote == null) {
            var searchQuery by remember { mutableStateOf("") }
            var showSearchDialog by remember { mutableStateOf(false) }
            val dateFormatter = remember { SimpleDateFormat("yyyy/M/d", Locale.CHINA) }

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onRefresh,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                ) { Text("刷新", fontSize = 12.sp) }
                OutlinedButton(onClick = onCreate, modifier = Modifier.padding(start = 6.dp)) { Text("新建", color = PrimaryPurple, fontSize = 12.sp) }
                OutlinedButton(onClick = onClearNotes, modifier = Modifier.padding(start = 6.dp)) {
                    Text("清空", color = PrimaryPurple, fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                TextButton(
                    onClick = {
                        val files = state.noteFiles
                        if (files.isNotEmpty()) onSelectNote(files.random().name)
                    },
                    modifier = Modifier.padding(start = 4.dp),
                ) {
                    Text("🎲", fontSize = 18.sp)
                }
                TextButton(
                    onClick = { showSearchDialog = true },
                    modifier = Modifier.padding(start = 4.dp),
                ) {
                    Text("🔍", fontSize = 18.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            val filteredFiles = if (searchQuery.isBlank()) state.noteFiles
            else state.noteFiles.filter { it.name.contains(searchQuery, ignoreCase = true) }
            val hasSelection = state.selectedNoteFiles.isNotEmpty()
            if (hasSelection) {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("已选 ${state.selectedNoteFiles.size}", color = PrimaryPurple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    OutlinedButton(onClick = onExportFolder) { Text("保存到文件夹", color = PrimaryPurple, fontSize = 12.sp) }
                    OutlinedButton(onClick = onDeleteSelected) { Text("删除", color = Color(0xFFDC2626), fontSize = 12.sp) }
                    OutlinedButton(onClick = onClearSelection) { Text("取消", color = SecondaryTextColor, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(4.dp))
            }
            val ctx = LocalContext.current
            val fPrefs = remember { ctx.getSharedPreferences("claw_note_folders", Context.MODE_PRIVATE) }
            val fNames = remember(state.noteFiles) {
                fPrefs.all.filterKeys { it.startsWith("_display_folder_") }.values.mapNotNull { it as? String }.sorted()
            }

            LazyColumn {
                if (!hasSelection) {
                    fNames.forEach { folder ->
                        item(key = "hdr_$folder") {
                            var expanded by remember { mutableStateOf(false) }
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }
                                        .background(Color(0xFFF0F4FF), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(if (expanded) "📂" else "📁", fontSize = 16.sp)
                                    Text(" $folder", color = PrimaryPurple, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f))
                                    val count = state.noteFiles.count { !isPinned(it.name) && fPrefs.getString(it.name, "") == folder }
                                    Text("${count}篇", color = SecondaryTextColor, fontSize = 12.sp)
                                }
                                AnimatedVisibility(visible = expanded, enter = expandVertically(), exit = shrinkVertically()) {
                                    val notesInFolder = state.noteFiles.filter { !isPinned(it.name) && fPrefs.getString(it.name, "") == folder }
                                    Column {
                                        if (notesInFolder.isEmpty()) {
                                            Text("  空文件夹 — 归档完成后笔记自动归入", color = SecondaryTextColor, fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp))
                                        }
                                        notesInFolder.forEach { file ->
                                            Box(
                                                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp).padding(start = 16.dp)
                                                    .background(Color.White, RoundedCornerShape(8.dp)).border(0.5.dp, DividerSoft, RoundedCornerShape(8.dp))
                                                    .combinedClickable(onClick = { onSelectNote(file.name) }, onLongClick = {})
                                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                            ) {
                                                Text(file.name.removeSuffix(".md"), color = AiTextColor, fontSize = 13.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                items(filteredFiles, key = { it.name }) { file ->
                    if (hasSelection && (file.name == "memory.md" || file.name == "用户画像.md")) return@items
                    val selected = state.selectedNoteFiles.contains(file.name)
                    var showMenu by remember { mutableStateOf(false) }
                    val pinned = isPinned(file.name)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(if (selected) Color(0xFFEFF6FF) else Color.White, RoundedCornerShape(10.dp))
                            .border(1.dp, if (selected) PrimaryPurple else DividerSoft, RoundedCornerShape(10.dp))
                            .combinedClickable(
                                onClick = {
                                    if (hasSelection) onToggleSelect(file.name)
                                    else onSelectNote(file.name)
                                },
                                onLongClick = { showMenu = true },
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            if (hasSelection) {
                                Checkbox(
                                    checked = selected,
                                    onCheckedChange = { onToggleSelect(file.name) },
                                    modifier = Modifier.size(20.dp).padding(end = 8.dp),
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row {
                                    if (pinned) Text("📌 ", fontSize = 13.sp)
                                    Text(
                                        text = file.name.removeSuffix(".md"),
                                        color = AiTextColor,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Medium,
                                    )
                                }
                            }
                            Text(
                                text = dateFormatter.format(Date(file.lastModified())),
                                color = SecondaryTextColor,
                                fontSize = 11.sp,
                            )
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                        ) {
                            val isMemory = file.name == "memory.md" || file.name == "用户画像.md"
                            if (!isMemory) {
                                DropdownMenuItem(
                                    text = { Text("多选笔记") },
                                    onClick = { showMenu = false; onToggleSelect(file.name) },
                                )
                                DropdownMenuItem(
                                    text = { Text(if (pinned) "取消置顶" else "置顶") },
                                    onClick = { showMenu = false; onPinNote(file.name) },
                                )
                                DropdownMenuItem(
                                    text = { Text("重命名") },
                                    onClick = { showMenu = false; onRenameNote(file.name) },
                                )
                                DropdownMenuItem(
                                    text = { Text("删除", color = Color(0xFFDC2626)) },
                                    onClick = { showMenu = false; onToggleSelect(file.name); onDeleteSelected() },
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("保存到文件夹") },
                                onClick = { showMenu = false; onToggleSelect(file.name); onExportFolder() },
                            )
                        }
                    }
                }
            }

            if (showSearchDialog) {
                AlertDialog(
                    onDismissRequest = { showSearchDialog = false },
                    title = { Text("搜索笔记", color = AiTextColor, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) },
                    text = {
                        Column {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("输入标题关键词") },
                                singleLine = true,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Search),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = InputBackground,
                                    unfocusedContainerColor = InputBackground,
                                    focusedBorderColor = PrimaryPurple,
                                    unfocusedBorderColor = InputBorder,
                                ),
                            )
                            if (searchQuery.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "匹配 ${filteredFiles.size} 条",
                                    color = SecondaryTextColor,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showSearchDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                        ) { Text("关闭", fontSize = 13.sp) }
                    },
                )
            }

            if (state.showRenameDialog) {
                AlertDialog(
                    onDismissRequest = onCancelRename,
                    title = { Text("重命名", color = AiTextColor) },
                    text = {
                        OutlinedTextField(
                            value = state.renamingNewName,
                            onValueChange = onUpdateRename,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("新文件名") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = InputBackground,
                                unfocusedContainerColor = InputBackground,
                                focusedBorderColor = PrimaryPurple,
                                unfocusedBorderColor = InputBorder,
                            ),
                        )
                    },
                    confirmButton = {
                        Button(onClick = onConfirmRename, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White)) {
                            Text("确定")
                        }
                    },
                    dismissButton = { TextButton(onClick = onCancelRename) { Text("取消", color = PrimaryPurple) } },
                )
            }

            if (state.showDeleteConfirmDialog) {
                AlertDialog(
                    onDismissRequest = onCancelDelete,
                    title = { Text("删除笔记", color = AiTextColor) },
                    text = { Text("确定删除已选的 ${state.selectedNoteFiles.size} 篇笔记？此操作不可撤销。") },
                    confirmButton = {
                        Button(onClick = onConfirmDelete, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626), contentColor = Color.White)) {
                            Text("删除")
                        }
                    },
                    dismissButton = { TextButton(onClick = onCancelDelete) { Text("取消", color = PrimaryPurple) } },
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                OutlinedButton(onClick = onBack) { Text("← 返回", color = PrimaryPurple, fontSize = 12.sp) }
                Button(
                    onClick = onCopy,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                ) { Text("复制", fontSize = 12.sp) }
                Button(
                    onClick = onShare,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                ) { Text("分享", fontSize = 12.sp) }
                OutlinedButton(onClick = onEdit) { Text("编辑", color = PrimaryPurple, fontSize = 12.sp) }
            }
            Spacer(Modifier.height(8.dp))
            if (state.selectedNoteContent.isBlank()) {
                Text("正在读取笔记内容，或该笔记为空。", color = SecondaryTextColor)
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 420.dp)
                        .background(InputBackground, RoundedCornerShape(12.dp))
                        .border(1.dp, InputBorder, RoundedCornerShape(12.dp))
                        .verticalScroll(rememberScrollState())
                        .padding(12.dp),
                ) {
                    MarkdownView(markdown = state.selectedNoteContent)
                }
            }
        }
    }
}

@Composable
private fun NoteEditor(
    state: ChatUiState,
    onUpdateTitle: (String) -> Unit,
    onUpdateContent: (String) -> Unit,
    onSave: () -> Unit,
    onCancel: () -> Unit,
    onInsertImage: () -> Unit,
) {
    Column(modifier = Modifier.fillMaxSize().background(AppPageBackground)) {
        Row {
            OutlinedButton(onClick = onCancel) { Text("取消", color = PrimaryPurple) }
            Button(
                onClick = onSave,
                modifier = Modifier.padding(start = 8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = androidx.compose.ui.graphics.Color.White),
            ) { Text("保存笔记") }
            OutlinedButton(onClick = onInsertImage, modifier = Modifier.padding(start = 8.dp)) { Text("插入图片", color = PrimaryPurple) }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = state.editingNoteName,
            onValueChange = onUpdateTitle,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("笔记标题 / 文件名") },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = InputBackground,
                unfocusedContainerColor = InputBackground,
                focusedBorderColor = PrimaryPurple,
                unfocusedBorderColor = InputBorder,
            ),
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = state.editingNoteContent,
            onValueChange = onUpdateContent,
            modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp),
            label = { Text("Markdown 内容") },
            minLines = 14,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = InputBackground,
                unfocusedContainerColor = InputBackground,
                focusedBorderColor = PrimaryPurple,
                unfocusedBorderColor = InputBorder,
            ),
        )
    }
}
