package com.pengwc.clawmemorylocal

data class PythonRunResult(
    val success: Boolean,
    val stdout: String,
    val stderr: String,
    val traceback: String,
    val durationMs: Long,
)
