package com.pengwc.clawmemorylocal

object OnlineApiConfig {
    const val QWEN_API_KEY = "请在这里填写你的千问 API Key"
    const val QWEN_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    const val QWEN_MODEL = "qwen-turbo"
    const val QWEN_FILE_SEARCH_MODEL = "qwen-turbo"

    fun apiKeyReady(): Boolean = QWEN_API_KEY.isNotBlank() && !QWEN_API_KEY.contains("在这里填写")
    fun baseUrlReady(): Boolean = QWEN_BASE_URL.isNotBlank() && !QWEN_BASE_URL.contains("在这里填写")
}
