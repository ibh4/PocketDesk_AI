package com.pengwc.clawmemorylocal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PythonToolScreen(
    code: String,
    result: PythonRunResult?,
    running: Boolean,
    onCodeChange: (String) -> Unit,
    onRun: () -> Unit,
    onClear: () -> Unit,
    onSave: () -> Unit,
    onBack: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        OutlinedButton(onClick = onBack) { Text("返回小程序", color = PrimaryPurple) }
        Text("Python 小工具", fontSize = 20.sp, color = AiTextColor)
        Text(
            "本工具用于本地运行简单 Python 代码，不联网，不适合运行不可信代码。",
            fontSize = 13.sp,
            color = SecondaryTextColor,
        )
        Text("请不要运行来源不明的代码。", fontSize = 12.sp, color = Color(0xFFF59E0B))
        OutlinedTextField(
            value = code,
            onValueChange = onCodeChange,
            modifier = Modifier.fillMaxWidth().height(220.dp),
            label = { Text("Python 代码") },
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = InputBackground,
                unfocusedContainerColor = InputBackground,
                focusedBorderColor = PrimaryPurple,
                unfocusedBorderColor = InputBorder,
            ),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onRun,
                enabled = !running,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) { Text(if (running) "运行中..." else "运行") }
            OutlinedButton(onClick = onClear, enabled = !running) { Text("清空", color = PrimaryPurple) }
            OutlinedButton(onClick = onSave, enabled = !running) { Text("保存结果到笔记", color = PrimaryPurple) }
        }
        ResultBlock("输出", result?.stdout.orEmpty().ifBlank { "暂无输出" })
        ResultBlock(
            title = "错误",
            content = buildString {
                if (!result?.stderr.isNullOrBlank()) appendLine(result?.stderr?.trim())
                if (!result?.traceback.isNullOrBlank()) append(result?.traceback?.trim())
            }.ifBlank { "暂无错误" },
        )
        if (result != null) {
            Text("运行耗时：${result.durationMs} ms", fontSize = 12.sp, color = SecondaryTextColor)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ResultBlock(title: String, content: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, DividerSoft, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, fontSize = 14.sp, color = AiTextColor)
        Text(content, fontSize = 13.sp, color = AiTextColor)
    }
}
