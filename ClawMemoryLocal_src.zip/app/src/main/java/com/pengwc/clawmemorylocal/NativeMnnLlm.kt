package com.pengwc.clawmemorylocal

class NativeMnnLlm {
    private var nativePtr: Long = 0
    val isLoaded: Boolean get() = nativePtr != 0L

    fun load(configPath: String, systemPrompt: String, threadCount: Int, maxNewTokens: Int) {
        if (nativePtr != 0L) return
        nativePtr = nativeInit(configPath, systemPrompt, threadCount, maxNewTokens)
        check(nativePtr != 0L) { "MNN-LLM nativeInit returned 0" }
    }

    fun generate(history: List<ChatMessage>, maxNewTokens: Int, onToken: (String) -> Boolean): String {
        check(nativePtr != 0L) { "Model is not loaded" }
        val roles = history.map { it.role }.toTypedArray()
        val contents = history.map { it.content }.toTypedArray()
        return nativeGenerate(nativePtr, roles, contents, maxNewTokens, object : TokenCallback {
            override fun onToken(token: String): Boolean = onToken(token)
        })
    }

    fun reset() {
        if (nativePtr != 0L) nativeReset(nativePtr)
    }

    fun close() {
        if (nativePtr != 0L) {
            nativeRelease(nativePtr)
            nativePtr = 0
        }
    }

    private external fun nativeInit(
        configPath: String,
        systemPrompt: String,
        threadCount: Int,
        maxNewTokens: Int,
    ): Long
    private external fun nativeGenerate(
        ptr: Long,
        roles: Array<String>,
        contents: Array<String>,
        maxNewTokens: Int,
        callback: TokenCallback
    ): String
    private external fun nativeReset(ptr: Long)
    private external fun nativeRelease(ptr: Long)

    interface TokenCallback {
        fun onToken(token: String): Boolean
    }

    companion object {
        init {
            System.loadLibrary("MNN")
            System.loadLibrary("clawmemory_mnn")
        }
    }
}
