package com.pengwc.clawmemorylocal

import android.content.Context
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

class PythonEngine(context: Context, private val logger: AppLogger) {
    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()

    suspend fun run(code: String, timeoutMs: Long = 5000): PythonRunResult = withContext(Dispatchers.IO) {
        val trimmed = code.trim()
        if (trimmed.isBlank()) {
            return@withContext PythonRunResult(false, "", "", "请先输入 Python 代码。", 0)
        }
        ensureStarted()
        logger.python("Python 运行开始：chars=${trimmed.length} timeoutMs=$timeoutMs")
        val started = System.nanoTime()
        val future = executor.submit<String> {
            Python.getInstance().getModule("runner").callAttr("run_user_code", trimmed).toString()
        }
        try {
            val json = future.get(timeoutMs, TimeUnit.MILLISECONDS)
            val result = parse(json, elapsedMs(started))
            if (result.success) {
                logger.python("Python 运行成功：durationMs=${result.durationMs} stdoutChars=${result.stdout.length}")
            } else {
                logger.python("Python 运行失败：durationMs=${result.durationMs} error=${result.traceback.take(120)}")
            }
            result
        } catch (_: TimeoutException) {
            future.cancel(true)
            val durationMs = elapsedMs(started)
            logger.python("Python 运行超时：durationMs=$durationMs")
            PythonRunResult(false, "", "", "Python 运行超时，请简化代码后重试。", durationMs)
        } catch (t: Throwable) {
            future.cancel(true)
            val durationMs = elapsedMs(started)
            logger.python("Python 运行异常：durationMs=$durationMs message=${t.message ?: t::class.java.simpleName}")
            PythonRunResult(false, "", "", t.message ?: "Python 运行失败", durationMs)
        }
    }

    private fun ensureStarted() {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(appContext))
        }
    }

    private fun parse(json: String, durationMs: Long): PythonRunResult {
        val obj = JSONObject(json)
        return PythonRunResult(
            success = obj.optBoolean("success"),
            stdout = obj.optString("stdout"),
            stderr = obj.optString("stderr"),
            traceback = obj.optString("traceback"),
            durationMs = durationMs,
        )
    }

    private fun elapsedMs(startedNs: Long): Long = (System.nanoTime() - startedNs) / 1_000_000
}
