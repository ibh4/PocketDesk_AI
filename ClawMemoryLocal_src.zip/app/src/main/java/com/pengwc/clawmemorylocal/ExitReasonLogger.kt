package com.pengwc.clawmemorylocal

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.Instant

object ExitReasonLogger {
    suspend fun capture(context: Context, logger: AppLogger) = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            logger.crash("ApplicationExitInfo 不可用：当前 Android SDK ${Build.VERSION.SDK_INT}")
            return@withContext
        }
        val manager = context.getSystemService(ActivityManager::class.java)
        val reasons = manager.getHistoricalProcessExitReasons(context.packageName, 0, 1)
        val info = reasons.firstOrNull() ?: return@withContext
        val summary = buildString {
            appendLine("上次进程退出原因：")
            appendLine("reason=${reasonName(info.reason)}(${info.reason})")
            appendLine("description=${info.description.orEmpty()}")
            appendLine("timestamp=${Instant.ofEpochMilli(info.timestamp)}")
            appendLine("importance=${info.importance}")
            appendLine("pid=${info.pid}")
        }
        logger.crash(summary + "\n疑似 native crash：${info.reason == ApplicationExitInfo.REASON_CRASH_NATIVE}")
        logger.exitTraceFile.parentFile?.mkdirs()
        logger.exitTraceFile.writeText(summary + "\n疑似 native crash：${info.reason == ApplicationExitInfo.REASON_CRASH_NATIVE}\n\n")
        runCatching {
            info.traceInputStream?.use { input ->
                logger.exitTraceFile.outputStream().use { output ->
                    output.write((summary + "\n\n").toByteArray())
                    input.copyTo(output)
                }
            }
        }.onFailure {
            logger.crash("读取 last_exit_trace 失败", it)
        }
    }

    private fun reasonName(reason: Int): String = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        when (reason) {
            ApplicationExitInfo.REASON_CRASH -> "CRASH"
            ApplicationExitInfo.REASON_CRASH_NATIVE -> "CRASH_NATIVE"
            ApplicationExitInfo.REASON_ANR -> "ANR"
            ApplicationExitInfo.REASON_LOW_MEMORY -> "LOW_MEMORY"
            ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "EXCESSIVE_RESOURCE_USAGE"
            ApplicationExitInfo.REASON_USER_REQUESTED -> "USER_REQUESTED"
            ApplicationExitInfo.REASON_EXIT_SELF -> "EXIT_SELF"
            else -> "OTHER"
        }
    } else {
        "UNSUPPORTED"
    }
}
