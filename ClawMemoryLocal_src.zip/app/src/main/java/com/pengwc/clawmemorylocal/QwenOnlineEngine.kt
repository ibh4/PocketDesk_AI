package com.pengwc.clawmemorylocal

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

object QwenOnlineEngine {
    private val json = Json { ignoreUnknownKeys = true }
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generate(
        prompt: PromptBuildResult,
        logger: AppLogger,
        model: String = OnlineApiConfig.QWEN_MODEL,
    ): String = withContext(Dispatchers.IO) {
        if (!OnlineApiConfig.apiKeyReady()) return@withContext "请先在 OnlineApiConfig.kt 中填写千问 API Key"
        if (!OnlineApiConfig.baseUrlReady()) return@withContext "请先在 OnlineApiConfig.kt 中填写千问 Base URL"

        val requestBody = ChatCompletionRequest(
            model = model,
            messages = prompt.messages.map { ApiMessage(role = it.role, content = ThinkContentParser.strip(it.content)) },
        )
        val bodyText = json.encodeToString(ChatCompletionRequest.serializer(), requestBody)
        val request = Request.Builder()
            .url(normalizeEndpoint(OnlineApiConfig.QWEN_BASE_URL))
            .addHeader("Authorization", "Bearer ${OnlineApiConfig.QWEN_API_KEY}")
            .addHeader("Content-Type", "application/json")
            .post(bodyText.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        val start = System.currentTimeMillis()
        logger.onlineApi("线上请求开始：baseUrl=${OnlineApiConfig.QWEN_BASE_URL}, model=${OnlineApiConfig.QWEN_MODEL}, promptChars=${prompt.promptChars}")
        try {
            client.newCall(request).execute().use { response ->
                val cost = System.currentTimeMillis() - start
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val msg = when (response.code) {
                        401, 403 -> "千问 API 鉴权失败，请检查 API Key"
                        404 -> "千问 API 地址或模型名可能不正确"
                        else -> "线上千问请求失败（HTTP ${response.code}）"
                    }
                    logger.onlineApi("线上请求失败：code=${response.code}, cost=${cost}ms, message=$msg")
                    return@withContext msg
                }
                val parsed = runCatching {
                    json.decodeFromString(ChatCompletionResponse.serializer(), raw)
                }.getOrElse {
                    logger.onlineApi("线上请求失败：code=${response.code}, cost=${cost}ms, message=线上千问返回格式解析失败")
                    return@withContext "线上千问返回格式解析失败"
                }
                val content = parsed.choices.firstOrNull()?.message?.content?.trim().orEmpty()
                if (content.isBlank()) {
                    logger.onlineApi("线上请求失败：code=${response.code}, cost=${cost}ms, message=线上千问返回格式解析失败")
                    return@withContext "线上千问返回格式解析失败"
                }
                logger.onlineApi("线上请求成功：code=${response.code}, cost=${cost}ms, model=${OnlineApiConfig.QWEN_MODEL}")
                return@withContext content
            }
        } catch (_: SocketTimeoutException) {
            logger.onlineApi("线上请求失败：code=timeout, cost=${System.currentTimeMillis() - start}ms, message=千问 API 请求超时")
            "千问 API 请求超时"
        } catch (_: IOException) {
            logger.onlineApi("线上请求失败：code=network_error, cost=${System.currentTimeMillis() - start}ms, message=网络不可用或请求失败")
            "网络不可用或请求失败"
        } catch (t: Throwable) {
            logger.onlineApi("线上请求失败：code=unknown, cost=${System.currentTimeMillis() - start}ms, message=${t.message ?: t::class.java.simpleName}")
            "网络不可用或请求失败"
        }
    }

    private fun normalizeEndpoint(baseUrl: String): String {
        val clean = baseUrl.trim().removeSuffix("/")
        return if (clean.endsWith("/chat/completions")) clean else "$clean/chat/completions"
    }
}

@Serializable
private data class ChatCompletionRequest(
    val model: String,
    val messages: List<ApiMessage>,
)

@Serializable
private data class ApiMessage(
    val role: String,
    val content: String,
)

@Serializable
private data class ChatCompletionResponse(
    val choices: List<Choice> = emptyList(),
)

@Serializable
private data class Choice(
    val message: ChoiceMessage = ChoiceMessage(),
)

@Serializable
private data class ChoiceMessage(
    val role: String = "",
    val content: String = "",
    @SerialName("reasoning_content")
    val reasoningContent: String? = null,
)
