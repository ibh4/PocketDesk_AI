package com.pengwc.clawmemorylocal

import kotlinx.serialization.Serializable
import java.time.LocalDateTime

@Serializable
data class ChatMessage(
    val role: String,
    val content: String,
    val timestamp: String = LocalDateTime.now().toString(),
    val thinking: String = "",
    val sourceLabel: String = "",
)

data class PromptBuildResult(
    val messages: List<ChatMessage>,
    val userContent: String,
    val promptChars: Int,
    val estimatedTokens: Int,
    val historyTurns: Int,
    val inputWasTruncated: Boolean,
    val performanceMode: PerformanceMode,
    val memoryChars: Int = 0,
    val workspaceChars: Int = 0,
)

data class GenerationText(
    val visibleAnswer: String,
    val thinking: String,
    val reachedLimit: Boolean,
)

enum class ModelStatus(val label: String) {
    Unpacking("模型解包中"),
    Loading("模型加载中"),
    Ready("模型已就绪"),
    Inferring("推理中"),
    Failed("推理失败"),
}

enum class AppTab(val title: String) {
    Chat("本地对话"),
    Notes("历史笔记"),
    Logs("错误日志"),
    MiniApps("小程序"),
}

enum class MiniAppRouteState {
    Menu,
    Wheel,
    Python,
    FileSearch,
    BubbleNote,
    TodayAnalysis,
    DeepSpace,
    CustomApp1,
    CustomApp2,
}

enum class ChatMode(val label: String) {
    Local("本地"),
    LocalPlusOnline("本地+线上"),
}

enum class PerformanceMode(
    val label: String,
    val threadCount: Int,
    val maxNewTokens: Int,
    val historyTurns: Int,
    val promptCharLimit: Int,
) {
    Stable("稳定", 2, 256, 4, 4000),
    Balanced("平衡", 2, 512, 10, 8000),
    Performance("性能", 4, 768, 10, 8000),
}

data class LogSections(
    val runtime: String = "",
    val model: String = "",
    val crash: String = "",
    val performance: String = "",
    val onlineApi: String = "",
    val fileSearch: String = "",
    val python: String = "",
    val lastExitTrace: String = "",
    val runtimePath: String = "",
    val modelPath: String = "",
    val crashPath: String = "",
    val performancePath: String = "",
    val onlineApiPath: String = "",
    val fileSearchPath: String = "",
    val pythonPath: String = "",
    val lastExitTracePath: String = "",
)

const val DEFAULT_THREAD_COUNT = 2
const val DEFAULT_MAX_NEW_TOKENS = 512
const val DEFAULT_PERFORMANCE_MODE = "Balanced"
const val HISTORY_TURN_LIMIT = 10
const val HISTORY_CHAR_LIMIT = 8000
const val USER_INPUT_CHAR_LIMIT = 2000
const val UI_REPLY_CHAR_LIMIT = 10000
const val DEFAULT_PYTHON_TOOL_CODE = """
print("你好，我是本地 Python 小工具")
import math
print("sqrt(16) =", math.sqrt(16))
"""

data class QuickPromptTemplate(
    val title: String,
    val content: String,
)

val QUICK_PROMPT_TEMPLATES = listOf(
    QuickPromptTemplate(
        title = "生成自定义小程序",
        content = """
            [创建小程序:1,计算器]
            [小程序按钮:7] [小程序按钮:8] [小程序按钮:9] [小程序按钮:C]
            [小程序按钮:4] [小程序按钮:5] [小程序按钮:6] [小程序按钮:×]
            [小程序按钮:1] [小程序按钮:2] [小程序按钮:3] [小程序按钮:-]
            [小程序按钮:0] [小程序按钮:.] [小程序按钮:=] [小程序按钮:+]
            ```python
            from math import *
            s = user_input.replace('×', '*').replace('÷', '/').rstrip('=')
            if s == 'C':
                print('0')
            elif s:
                try:
                    print(eval(s))
                except:
                    print('错误')
            ```
            [/创建小程序]
        """.trimIndent(),
    ),
    QuickPromptTemplate(
        title = "生成 Python 小工具",
        content = "请帮我写一段简洁可运行的 Python 代码。要求只使用 Python 标准库，代码不要注释。任务是：hello world",
    ),
    QuickPromptTemplate(
        title = "根据我的信息给建议",
        content = """
            请结合我的长期记忆、当前身份和项目背景，给我一份简洁直接的建议。要求包括：1）当前最应该优先做什么；2）哪些事情暂时不要做；3）下一步最小可执行动作；4）可能的风险；5）最终可展示成果。
        """.trimIndent(),
    ),
    QuickPromptTemplate(
        title = "给我 5 条具体建议",
        content = """
            请针对我下面的问题，给出 5 条具体、可执行、低成本的建议。每条建议都要包含：做什么、为什么做、怎么开始、预期结果。问题是：
        """.trimIndent(),
    ),
    QuickPromptTemplate(
        title = "随机冒泡一份旧笔记",
        content = """
            请从我的本地历史笔记中，优先随机选择一份较早的笔记进行「知识冒泡」总结，目的是帮助我重新看到过去积累但可能已经遗忘的内容。请整理成 Markdown，结构包括：标题、原笔记时间、核心摘要、关键要点、现在仍然有价值的部分、可以重新启动的行动、后续可追问的问题。不要保存思考过程，只输出最终整理内容。
        """.trimIndent(),
    ),
    QuickPromptTemplate(
        title = "对话整理成笔记 Markdown",
        content = "请整理以上全部对话内容，总结核心讨论主题并压缩成一篇笔记。要求：1）用主要内容作标题；2）开头放一个总结表格（2-3列）；3）正文分点归纳关键结论和行动项；4）输出 [创建笔记:标题] 作为开头，内容后以 [/创建笔记] 结尾。",
    ),
)

const val PYTHON_CAPABILITY_DESC = """
本地 Python 运行时限制：
- 可用模块：math, statistics, json, csv, re, datetime, random, collections, itertools
- 可用函数：print, len, range, min, max, sum, abs, round, enumerate, zip, list, dict, set, tuple, sorted, any, all, int, float, str, bool
- 运行超时：5 秒
- 禁止：os, subprocess, socket, shutil, pathlib, open, eval, exec, __import__, input, requests, urllib, http
"""

const val CHINESE_SYSTEM_PROMPT = """
你是彭先生的本地 AI 助手。用户要求保存笔记时，输出 [创建笔记:标题] 作为开头。回答简洁直接，多用表格。
"""

const val LIFE_EVIDENCE_PROMPT = """
你是生活证据官。请始终使用简体中文。请把用户输入的生活事件整理成 Markdown，结构包括：
1. 事件摘要
2. 关键事实
3. 缺失材料
4. 下一步行动
5. 沟通话术
要求简洁、可执行、不提供法律结论，只做材料整理和沟通辅助。
"""
