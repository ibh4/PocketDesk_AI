package com.pengwc.clawmemorylocal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.activity.viewModels
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

class MainActivity : ComponentActivity() {
    private val viewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.dark(
                scrim = PrimaryPurple.toArgb(),
            ),
            navigationBarStyle = androidx.activity.SystemBarStyle.dark(
                scrim = Color.White.toArgb(),
            ),
        )
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = PrimaryPurple,
                    onPrimary = Color.White,
                    background = AppPageBackground,
                    surface = AppPageBackground,
                    outline = InputBorder,
                )
            ) {
                ClawMemoryApp(viewModel)
            }
        }
    }
}
