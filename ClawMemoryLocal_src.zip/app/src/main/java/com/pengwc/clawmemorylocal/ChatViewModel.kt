package com.pengwc.clawmemorylocal

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class ChatUiState(
    val tab: AppTab = AppTab.Chat,
    val status: ModelStatus = ModelStatus.Unpacking,
    val chatMode: ChatMode = ChatMode.Local,
    val messages: List<ChatMessage> = emptyList(),
    val evidenceMode: Boolean = false,
    val accessPermissionEnabled: Boolean = true,
    val input: String = "",
    val performanceMode: PerformanceMode = PerformanceMode.Balanced,
    val progress: Int = 0,
    val isGenerating: Boolean = false,
    val thinkingExpanded: Boolean = false,
    val notice: String? = null,
    val showClearChatDialog: Boolean = false,
    val showClearNotesDialog: Boolean = false,
    val showGeneratingClearDialog: Boolean = false,
    val noteFiles: List<File> = emptyList(),
    val noteFolders: Map<String, List<File>> = emptyMap(),
    val selectedNote: String? = null,
    val selectedNoteContent: String = "",
    val isEditingNote: Boolean = false,
    val editingNoteName: String = "",
    val editingNoteContent: String = "",
    val logs: String = "",
    val logSections: LogSections = LogSections(),
    val rootDirPath: String = "",
    val noteDirPath: String = "",
    val imageDirPath: String = "",
    val memoryDirPath: String = "",
    val workspaceFolderName: String = "",
    val workspaceFolderUri: String = "",
    val workspaceSummary: String = "",
    val workspaceFileCount: Int = 0,
    val fileSearch: FileSearchUiState = FileSearchUiState(),
    val miniAppRoute: MiniAppRouteState = MiniAppRouteState.Menu,
    val pythonToolCode: String = DEFAULT_PYTHON_TOOL_CODE.trimIndent(),
    val pythonToolImportToken: Int = 0,
    val bubbleNoteName: String = "",
    val bubbleNoteContent: String = "",
    val todayAnalysisMarkdown: String = "",
    val isAnalyzingToday: Boolean = false,
    val todayAnalysisType: String = "",
    val selectedNoteFiles: Set<String> = emptySet(),
    val showRenameDialog: Boolean = false,
    val renamingNote: String = "",
    val renamingNewName: String = "",
    val showDeleteConfirmDialog: Boolean = false,
    val showArchiveConfirmDialog: Boolean = false,
    val archiveAnswer: String = "",
    val customApp1Name: String = "自定义小程序 1",
    val customApp1Code: String = "",
    val customApp1Buttons: String = "",
    val customApp2Name: String = "自定义小程序 2",
    val customApp2Code: String = "",
    val customApp2Buttons: String = "",
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application.applicationContext
    private val prefs = app.getSharedPreferences("claw_settings", Context.MODE_PRIVATE)
    private val notePinPrefs = app.getSharedPreferences("claw_note_pins", Context.MODE_PRIVATE)
    private val noteFolderPrefs = app.getSharedPreferences("claw_note_folders", Context.MODE_PRIVATE)
    private val notes = NoteRepository(app)
    private val memory = ContextMemoryRepository(app)
    private val logger = AppLogger(app)
    private val fileScanRepo = FileNameScanRepository(app, logger)
    private val reportWriter = SafeMarkdownReportWriter(app)
    private val webSearch = WebSearchRepository()
    private val pythonEngine = PythonEngine(app, logger)
    private var progressJob: Job? = null
    private var fileSearchScanJob: Job? = null
    private var typewriterJob: Job? = null
    @Volatile private var cancelRequested: Boolean = false
    private val _state = MutableStateFlow(
        ChatUiState(
            chatMode = runCatching {
                ChatMode.valueOf(prefs.getString("chat_mode", ChatMode.Local.name) ?: ChatMode.Local.name)
            }.getOrDefault(ChatMode.Local),
            performanceMode = runCatching {
                PerformanceMode.valueOf(prefs.getString("performance_mode", DEFAULT_PERFORMANCE_MODE) ?: DEFAULT_PERFORMANCE_MODE)
            }.getOrDefault(PerformanceMode.Balanced),
            accessPermissionEnabled = prefs.getBoolean("access_permission", true),
            customApp1Name = prefs.getString("custom_app_1_name", "自定义小程序 1") ?: "自定义小程序 1",
            customApp1Code = prefs.getString("custom_app_1_code", "") ?: "",
            customApp1Buttons = prefs.getString("custom_app_1_buttons", "") ?: "",
            customApp2Name = prefs.getString("custom_app_2_name", "自定义小程序 2") ?: "自定义小程序 2",
            customApp2Code = prefs.getString("custom_app_2_code", "") ?: "",
            customApp2Buttons = prefs.getString("custom_app_2_buttons", "") ?: "",
        )
    )
    val state: StateFlow<ChatUiState> = _state

    init {
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            viewModelScope.launch { logger.crash("未捕获 Java/Kotlin 异常", throwable) }
        }
        viewModelScope.launch {
            logger.runtime("App 启动")
            ExitReasonLogger.capture(app, logger)
            notes.clearCurrentSession()
            notes.seedDefaultNotesIfNeeded()
            val workspace = memory.initialize()
            val fileSearchState = fileScanRepo.loadUiState()
            val welcomeMsg = defaultWelcomeMessage()
            val placeholder = ChatMessage("assistant", "", sourceLabel = welcomeMsg.sourceLabel)
            _state.update {
                it.copy(
                    messages = listOf(placeholder),
                    rootDirPath = AppStorage.rootDir(app).absolutePath,
                    noteDirPath = notes.noteDirPath(),
                    imageDirPath = notes.imageDirPath(),
                    memoryDirPath = workspace.memoryDirPath,
                    workspaceFolderName = workspace.workspaceFolderName,
                    workspaceFolderUri = workspace.workspaceFolderUri,
                    workspaceSummary = workspace.workspaceSummary,
                    workspaceFileCount = workspace.workspaceFileCount,
                    fileSearch = fileSearchState,
                    notice = "已默认清空当前对话，历史请在笔记中查看",
                )
            }
            refreshNotes()
            refreshLogs()
            typewriterJob?.cancel()
            typewriterJob = viewModelScope.launch {
                delay(500L)
                TypewriterRenderer.stream(
                    fullText = welcomeMsg.content,
                    onUpdate = { visible ->
                        _state.update {
                            val msgs = it.messages.toMutableList()
                            if (msgs.isNotEmpty()) msgs[msgs.lastIndex] = welcomeMsg.copy(content = visible)
                            it.copy(messages = msgs)
                        }
                    },
                    onCancel = { false },
                    speedMultiplier = 0.5f,
                )
            }
            reloadModel(force = false)
        }
    }

    fun setTab(tab: AppTab) {
        _state.update { it.copy(tab = tab, notice = null) }
        viewModelScope.launch { logger.runtime("页面切换：${tab.title}") }
        when (tab) {
            AppTab.Notes -> refreshNotes()
            AppTab.Logs -> refreshLogs()
            AppTab.Chat, AppTab.MiniApps -> Unit
        }
    }

    fun updateInput(value: String) {
        _state.update { it.copy(input = value) }
    }

    fun fillQuickPrompt(content: String) {
        val hadContent = state.value.input.isNotBlank()
        _state.update {
            it.copy(
                input = content,
                notice = if (hadContent) "已填入常用语，可继续编辑" else "已填入常用语",
            )
        }
    }

    fun setMiniAppRoute(route: MiniAppRouteState) {
        _state.update { it.copy(miniAppRoute = route) }
        if (route == MiniAppRouteState.BubbleNote) {
            openBubbleNote()
        }
    }

    fun openBubbleNote() {
        viewModelScope.launch {
            val files = noteFiles()
            if (files.isEmpty()) {
                _state.update { it.copy(notice = "暂无笔记") }
                return@launch
            }
            val random = files.random()
            val content = notes.readNote(random.name)
            _state.update {
                it.copy(
                    bubbleNoteName = random.name,
                    bubbleNoteContent = content,
                )
            }
            logger.runtime("随机冒泡笔记：${random.name}")
        }
    }

    fun runTodayAnalysis(type: String) {
        if (state.value.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请稍后再分析") }
            return
        }
        if (state.value.chatMode == ChatMode.LocalPlusOnline && !OnlineApiConfig.apiKeyReady()) {
            _state.update { it.copy(notice = "请先配置千问 API Key") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(isAnalyzingToday = true, todayAnalysisType = type, todayAnalysisMarkdown = "") }
            val content = when (type) {
                "chat" -> buildTodayChatContext()
                "notes" -> buildTodayNotesContext()
                "python" -> buildTodayPythonContext()
                else -> ""
            }
            if (content.isBlank()) {
                _state.update { it.copy(isAnalyzingToday = false, notice = "暂无今日数据") }
                return@launch
            }
            val prompt = PromptBuildResult(
                messages = listOf(
                    ChatMessage("system", "你是数据分析助手。请用简体中文输出结构化的 Markdown 报告。包含：摘要、关键发现、建议行动。"),
                    ChatMessage("user", content),
                ),
                userContent = content,
                promptChars = content.length,
                estimatedTokens = (content.length / 1.7f).toInt(),
                historyTurns = 0,
                inputWasTruncated = false,
                performanceMode = state.value.performanceMode,
            )
            val reply = runCatching {
                ChatEngineRouter.generate(ChatMode.LocalPlusOnline, prompt, 256, logger, onPartial = {})
            }.onFailure {
                if (state.value.chatMode == ChatMode.Local) logger.model("今日分析失败", it)
                else logger.onlineApi("今日分析失败：${it.message}")
            }.getOrElse {
                ChatEngineReply(text = "分析失败：${it.message}", sourceLabel = "分析引擎")
            }
            _state.update {
                it.copy(
                    isAnalyzingToday = false,
                    todayAnalysisMarkdown = ThinkContentParser.strip(reply.text),
                )
            }
        }
    }

    fun saveTodayAnalysis() {
        val md = state.value.todayAnalysisMarkdown.trim()
        if (md.isBlank()) {
            _state.update { it.copy(notice = "请先生成分析报告") }
            return
        }
        viewModelScope.launch {
            val name = "今日分析_${state.value.todayAnalysisType}_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMdd_HHmm"))}"
            notes.saveUserNote(name, md)
            refreshNotes()
            _state.update { it.copy(notice = "分析报告已保存到笔记") }
            logger.runtime("今日分析已保存：$name")
        }
    }

    fun updateTodayAnalysisType(type: String) {
        _state.update { it.copy(todayAnalysisType = type, todayAnalysisMarkdown = "") }
    }

    fun saveCustomApp(slot: Int, name: String, code: String, buttons: String = "") {
        prefs.edit().putString("custom_app_${slot}_name", name)
            .putString("custom_app_${slot}_code", code)
            .putString("custom_app_${slot}_buttons", buttons).apply()
        if (slot == 1) _state.update { it.copy(customApp1Name = name, customApp1Code = code, customApp1Buttons = buttons) }
        else _state.update { it.copy(customApp2Name = name, customApp2Code = code, customApp2Buttons = buttons) }
        viewModelScope.launch { logger.runtime("自定义小程序已保存：slot=$slot name=$name") }
    }

    private suspend fun buildTodayChatContext(): String = withContext(Dispatchers.IO) {
        val today = java.time.LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val content = notes.readNote("$today.md")
        if (content.isBlank()) return@withContext ""
        buildString {
            appendLine("以下是今日对话记录，请分析并给出报告：")
            appendLine()
            appendLine(content.take(1500))
        }.trim()
    }

    private suspend fun buildTodayNotesContext(): String = withContext(Dispatchers.IO) {
        val files = noteFiles()
        if (files.isEmpty()) return@withContext ""
        val sample = files.shuffled().take(10)
        buildString {
            appendLine("以下是随机抽取的10篇笔记概要（共${files.size}篇）：")
            appendLine()
            sample.forEach { file ->
                val firstLine = notes.readNote(file.name).lines().firstOrNull { it.isNotBlank() && !it.startsWith("#") }?.take(80) ?: ""
                appendLine("- ${file.name.removeSuffix(".md")}：${firstLine}")
            }
        }.trim()
    }

    private suspend fun buildTodayPythonContext(): String = withContext(Dispatchers.IO) {
        val today = java.time.LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val content = notes.readNote("$today.md")
        if (content.isBlank()) return@withContext ""
        val pythonSection = content.substringAfter("### 输出", "").take(2000)
        if (pythonSection.isBlank()) return@withContext ""
        buildString {
            appendLine("以下是今日 Python 运行记录，请分析代码和输出：")
            appendLine()
            appendLine(pythonSection)
        }.trim()
    }

    private fun noteFiles(): List<File> = state.value.noteFiles

    fun updatePythonToolCode(code: String) {
        _state.update { it.copy(pythonToolCode = code) }
    }

    fun consumePythonToolImport() {
        _state.update { it.copy(pythonToolImportToken = 0) }
    }

    fun runPythonInChat(code: String) {
        if (state.value.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请稍后再运行") }
            return
        }
        viewModelScope.launch {
            val result = pythonEngine.run(code, timeoutMs = 5000)
            val resultText = buildString {
                appendLine("```text")
                if (result.stdout.isNotBlank()) append(result.stdout.trim())
                if (result.stderr.isNotBlank()) {
                    if (isNotEmpty()) appendLine()
                    append("stderr: ").append(result.stderr.trim())
                }
                if (!result.success && result.traceback.isNotBlank()) {
                    if (isNotEmpty()) appendLine()
                    append(result.traceback.trim())
                }
                if (isEmpty()) append("（无输出）")
                appendLine()
                append("耗时: ").append(result.durationMs).append("ms")
                appendLine()
                appendLine("```")
            }
            val runMessage = ChatMessage("assistant", resultText, sourceLabel = "Python")
            _state.update {
                val updated = it.messages + runMessage
                it.copy(messages = updated, notice = if (result.success) "Python 运行成功" else "Python 运行出错")
            }
            logger.python("对话中运行 Python：success=${result.success} durationMs=${result.durationMs}")
        }
    }

    fun importCodeToPythonTool(code: String) {
        val trimmed = code.trim()
        if (trimmed.isBlank()) {
            _state.update { it.copy(notice = "代码块为空，无法导入 Python 小工具") }
            return
        }
        _state.update {
            it.copy(
                tab = AppTab.MiniApps,
                miniAppRoute = MiniAppRouteState.Python,
                pythonToolCode = trimmed,
                pythonToolImportToken = it.pythonToolImportToken + 1,
                notice = "已导入 Python 小工具，正在准备运行",
            )
        }
        viewModelScope.launch { logger.runtime("代码块导入 Python 小工具：chars=${trimmed.length}") }
    }

    fun setEvidenceMode(enabled: Boolean) {
        _state.update { it.copy(evidenceMode = enabled) }
    }

    fun setAccessPermission(enabled: Boolean) {
        prefs.edit().putBoolean("access_permission", enabled).apply()
        _state.update {
            it.copy(
                accessPermissionEnabled = enabled,
                notice = if (enabled) "访问权限已开启，大模型可读取笔记、小程序和日志内容" else "访问权限已关闭，大模型仅使用基础记忆",
            )
        }
    }

    fun setChatMode(mode: ChatMode) {
        val current = state.value
        if (current.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请稍后切换模式") }
            return
        }
        if (current.chatMode == mode) return
        when (mode) {
            ChatMode.LocalPlusOnline -> {
                if (!OnlineApiConfig.apiKeyReady()) {
                    _state.update { it.copy(notice = "请先在 OnlineApiConfig.kt 中填写千问 API Key") }
                    return
                }
                if (!OnlineApiConfig.baseUrlReady()) {
                    _state.update { it.copy(notice = "请先在 OnlineApiConfig.kt 中填写千问 Base URL") }
                    return
                }
            }
            ChatMode.Local -> Unit
        }
        prefs.edit().putString("chat_mode", mode.name).apply()
        viewModelScope.launch {
            // Local/native and online sessions should not share the same in-memory conversation
            // window. Start a fresh chat on mode switch to keep prompts smaller and avoid
            // carrying online turns back into the local MNN session.
            if (mode == ChatMode.Local || current.chatMode == ChatMode.Local) {
                runCatching { LocalLlmEngine.reset() }
                    .onFailure { logger.model("切换模式时重置本地会话失败", it) }
            }
            notes.clearCurrentSession()
            _state.update {
                it.copy(
                    chatMode = mode,
                    messages = listOf(defaultWelcomeMessage()),
                    input = "",
                    thinkingExpanded = false,
                    progress = 0,
                    isGenerating = false,
                    status = if (mode == ChatMode.Local) ModelStatus.Ready else it.status,
                    notice = "已切换到${mode.label}模式，并已开始新对话",
                )
            }
            logger.runtime("切换对话模式：${mode.label}")
            logger.onlineApi("模式切换：${mode.label}")
            if (mode == ChatMode.Local) {
                logger.model("切回本地模式时已清空当前会话并重置本地会话")
            }
        }
    }

    fun connectWorkspaceFolder(uri: Uri) {
        viewModelScope.launch {
            val workspace = memory.attachWorkspace(uri)
            logger.runtime("已连接项目文件夹：${workspace.workspaceFolderName.ifBlank { uri.toString() }}")
            _state.update {
                it.copy(
                    memoryDirPath = workspace.memoryDirPath,
                    workspaceFolderName = workspace.workspaceFolderName,
                    workspaceFolderUri = workspace.workspaceFolderUri,
                    workspaceSummary = workspace.workspaceSummary,
                    workspaceFileCount = workspace.workspaceFileCount,
                    notice = "项目文件夹已连接，可参与上下文记忆",
                )
            }
        }
    }

    fun connectFileSearchAsWorkspace() {
        val uriStr = state.value.fileSearch.folderUri
        if (uriStr.isBlank()) {
            _state.update { it.copy(notice = "请先在文件检索中选择文件夹") }
            return
        }
        connectWorkspaceFolder(Uri.parse(uriStr))
    }

    fun clearWorkspaceFolder() {
        viewModelScope.launch {
            val workspace = memory.clearWorkspace()
            logger.runtime("已清除项目文件夹授权")
            _state.update {
                it.copy(
                    memoryDirPath = workspace.memoryDirPath,
                    workspaceFolderName = workspace.workspaceFolderName,
                    workspaceFolderUri = workspace.workspaceFolderUri,
                    workspaceSummary = workspace.workspaceSummary,
                    workspaceFileCount = workspace.workspaceFileCount,
                    notice = "项目文件夹已断开",
                )
            }
        }
    }

    fun refreshWorkspace(silent: Boolean = false) {
        viewModelScope.launch {
            val workspace = memory.refreshWorkspaceCache()
            _state.update {
                it.copy(
                    memoryDirPath = workspace.memoryDirPath,
                    workspaceFolderName = workspace.workspaceFolderName,
                    workspaceFolderUri = workspace.workspaceFolderUri,
                    workspaceSummary = workspace.workspaceSummary,
                    workspaceFileCount = workspace.workspaceFileCount,
                    notice = when {
                        silent -> it.notice
                        workspace.workspaceFolderUri.isBlank() -> "尚未选择项目文件夹"
                        else -> "项目文件夹摘要已刷新"
                    },
                )
            }
        }
    }

    fun handleFileFolderPicked(resultIntent: Intent?) {
        val uri = resultIntent?.data
        if (uri == null) {
            _state.update { it.copy(notice = "未选择文件夹") }
            return
        }
        val flags = resultIntent.flags
        viewModelScope.launch {
            runCatching {
                val uiState = fileScanRepo.attachFolder(uri, flags)
                _state.update { it.copy(fileSearch = uiState, notice = "文件夹授权成功，正在扫描文件名") }
                refreshFileSearchScan()
            }.onFailure {
                logger.fileSearch("授权文件夹失败", it)
                _state.update { it.copy(notice = "文件夹授权失败，请重试") }
            }
        }
    }

    fun refreshFileSearchScan() {
        val currentUi = state.value.fileSearch
        fileSearchScanJob?.cancel()
        fileSearchScanJob = viewModelScope.launch {
            _state.update {
                it.copy(
                    fileSearch = it.fileSearch.copy(
                        isScanning = true,
                        scanProgressText = "准备扫描...",
                    ),
                )
            }
            val scanned = runCatching {
                fileScanRepo.scan { processed, files, folders ->
                    _state.update {
                        it.copy(
                            fileSearch = it.fileSearch.copy(
                                isScanning = true,
                                scanProgressText = "已扫描 $processed 项，文件 $files 个，文件夹 $folders 个",
                            ),
                        )
                    }
                }
            }.onFailure {
                logger.fileSearch("扫描失败", it)
            }.getOrElse {
                state.value.fileSearch.copy(
                    isScanning = false,
                    scanProgressText = "扫描失败",
                )
            }
            val merged = scanned.copy(
                query = currentUi.query,
                filter = currentUi.filter,
                sort = currentUi.sort,
                analysisMarkdown = currentUi.analysisMarkdown,
            )
            _state.update {
                it.copy(
                    fileSearch = applyFileSearchDisplay(
                        merged.copy(
                            isScanning = false,
                            scanProgressText = when {
                                scanned.scanTruncated -> "文件较多，已扫描前 1000 个文件。"
                                scanned.folderStatus == "授权失效" -> "授权失效，请重新选择文件夹"
                                else -> "扫描完成"
                            },
                        ),
                    ),
                    notice = when {
                        scanned.folderStatus == "授权失效" -> "文件夹授权已失效"
                        scanned.scanTruncated -> "文件较多，已扫描前 1000 个文件。"
                        else -> "文件名索引已更新"
                    },
                )
            }
        }
    }

    fun cancelFileSearchScan() {
        fileScanRepo.requestCancelScan()
        fileSearchScanJob?.cancel()
        _state.update {
            it.copy(
                fileSearch = it.fileSearch.copy(
                    isScanning = false,
                    scanProgressText = "已取消扫描",
                ),
                notice = "已取消扫描",
            )
        }
        viewModelScope.launch { logger.fileSearch("用户取消文件扫描") }
    }

    fun disconnectFileSearchFolder() {
        viewModelScope.launch {
            val updated = fileScanRepo.disconnectFolder()
            _state.update { it.copy(fileSearch = applyFileSearchDisplay(updated), notice = "已断开文件夹授权") }
        }
    }

    fun clearFileSearchIndex() {
        viewModelScope.launch {
            val updated = fileScanRepo.clearIndex()
            _state.update { it.copy(fileSearch = applyFileSearchDisplay(updated), notice = "文件名索引已清空") }
        }
    }

    fun updateFileSearchQuery(query: String) {
        _state.update {
            val updated = it.fileSearch.copy(query = query)
            it.copy(fileSearch = applyFileSearchDisplay(updated))
        }
        viewModelScope.launch {
            logger.fileSearch("搜索关键词：${query.take(48)}")
        }
    }

    fun setFileSearchFilter(filter: FileSearchFilter) {
        _state.update {
            val updated = it.fileSearch.copy(filter = filter)
            it.copy(fileSearch = applyFileSearchDisplay(updated))
        }
    }

    fun setFileSearchReadWrite(enabled: Boolean) {
        _state.update { it.copy(fileSearch = it.fileSearch.copy(readWriteEnabled = enabled)) }
    }

    private fun quickReply(input: String): String? = when (input.trim()) {
        "你好", "你好啊", "hi", "hello", "嗨", "在吗", "在不在" ->
            "你好，彭先生！我是您的本地 AI 助手，请问有什么可以帮您？"
        "谢谢", "感谢", "多谢" -> "不客气，随时为您服务。"
        "你是谁", "你是什么", "介绍下自己" ->
            "我是彭先生的本地 AI 助手（千问），专门为彭先生服务。"
        "我是谁", "我叫什么", "我的名字" ->
            "您是彭伟超，中科院博士，芯视界算法工程师，常驻北京。"
        else -> null
    }

    private val ARCHIVE_DEMO_RESPONSE = """
已根据你的60篇笔记分布与知识体系，规划5个归档文件夹。结构如下：

| 文件夹名称 | 覆盖领域 | 预估笔记数 | 核心关键词 |
|---|---|---|---|
| `01_AI与算法工程` | 机器学习、AI4S、嵌入式、开发工具 | ~18篇 | 集成学习/MNN, 端侧部署, Python工具, ClawMemory |
| `02_科学与材料生化` | 化学信息学、分子诊断、传感器、材料 | ~15篇 | SMILES, 蛋白结构, IVD, 光谱/水质分析 |
| `03_产业与经济洞察` | 宏观经济、量化、半导体、行业研报 | ~10篇 | IVD企业, 大宗商品, 产业链, AI政策 |
| `04_人文历史与哲学` | 历史人物、哲学思想、教育观察 | ~9篇 | 三国, 叔本华, 权力逻辑, 认知框架 |
| `05_职场与个人成长` | 职业规划、知识管理、复盘、记忆系统 | ~8篇 | 人才观, 笔记化, MVP迭代, 决策模型 |
""".trimIndent()

    fun setFileSearchSort(sort: FileSearchSort) {
        _state.update {
            val updated = it.fileSearch.copy(sort = sort)
            it.copy(fileSearch = applyFileSearchDisplay(updated))
        }
    }

    fun requestAnalyzeFileNames() {
        val snapshot = state.value
        if (snapshot.fileSearch.records.isEmpty()) {
            _state.update { it.copy(notice = "请先选择文件夹并扫描文件名") }
            return
        }
        if (snapshot.status != ModelStatus.Ready) {
            _state.update { it.copy(notice = "请先等待本地模型加载完成") }
            return
        }
        if (snapshot.fileSearch.isScanning || snapshot.isGenerating || snapshot.fileSearch.isAnalyzing) {
            _state.update { it.copy(notice = "当前有任务进行中，请稍候") }
            return
        }
        if (snapshot.chatMode == ChatMode.LocalPlusOnline) {
            _state.update {
                it.copy(fileSearch = it.fileSearch.copy(showOnlineConfirmDialog = true))
            }
        } else {
            performFileNameAnalysis(ChatMode.Local)
        }
    }

    fun confirmAnalyzeFileNamesLocal() {
        _state.update { it.copy(fileSearch = it.fileSearch.copy(showOnlineConfirmDialog = false)) }
        viewModelScope.launch { logger.fileSearch("线上发送确认：用户选择仅用本地模型") }
        performFileNameAnalysis(ChatMode.Local)
    }

    fun confirmAnalyzeFileNamesOnline() {
        _state.update { it.copy(fileSearch = it.fileSearch.copy(showOnlineConfirmDialog = false)) }
        viewModelScope.launch { logger.fileSearch("线上发送确认：用户允许发送文件名列表到线上") }
        performFileNameAnalysis(ChatMode.LocalPlusOnline)
    }

    fun dismissFileSearchAnalyzeDialog() {
        _state.update { it.copy(fileSearch = it.fileSearch.copy(showOnlineConfirmDialog = false)) }
        viewModelScope.launch { logger.fileSearch("线上发送确认：用户取消") }
    }

    fun saveFileSearchReportInternal() {
        val markdown = state.value.fileSearch.analysisMarkdown.trim()
        if (markdown.isBlank()) {
            _state.update { it.copy(notice = "请先生成整理报告") }
            return
        }
        viewModelScope.launch {
            runCatching {
                reportWriter.saveInternal(markdown)
            }.onSuccess {
                logger.fileSearch("保存 Markdown 报告成功：internal=${it.name}")
                _state.update { current -> current.copy(notice = "已保存文件整理报告") }
            }.onFailure {
                logger.fileSearch("保存 Markdown 报告失败", it)
                _state.update { current -> current.copy(notice = "保存失败，请查看错误日志") }
            }
        }
    }

    fun saveFileSearchReportToFolder() {
        val snapshot = state.value
        val markdown = snapshot.fileSearch.analysisMarkdown.trim()
        if (markdown.isBlank()) {
            _state.update { it.copy(notice = "请先生成整理报告") }
            return
        }
        if (snapshot.fileSearch.folderUri.isBlank()) {
            _state.update { it.copy(notice = "尚未授权文件夹") }
            return
        }
        viewModelScope.launch {
            runCatching {
                reportWriter.saveToAuthorizedFolder(snapshot.fileSearch.folderUri, markdown)
            }.onSuccess {
                logger.fileSearch("保存 Markdown 报告成功：folder=$it")
                _state.update { current -> current.copy(notice = "已保存文件整理报告") }
            }.onFailure {
                logger.fileSearch("保存 Markdown 报告到授权文件夹失败", it)
                _state.update { current -> current.copy(notice = "保存失败，请查看错误日志") }
            }
        }
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        if (state.value.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请稍后切换性能模式") }
            return
        }
        prefs.edit().putString("performance_mode", mode.name).apply()
        _state.update {
            it.copy(
                performanceMode = mode,
                notice = "已切换到${mode.label}模式。线程数变化将在重新加载模型后生效",
            )
        }
        viewModelScope.launch {
            logger.runtime("用户切换性能模式：${mode.label}")
            reloadModel(force = true)
        }
    }

    fun send() {
        val snapshot = state.value
        val rawInput = snapshot.input.trim()
        if (rawInput.isBlank()) return
        val fileSearchIntent = FileNameSearchEngine.isFileSearchIntent(rawInput)
        val webSearchIntent = snapshot.chatMode == ChatMode.LocalPlusOnline && webSearch.isWebSearchIntent(rawInput)
        val needsOnline = webSearch.isWebSearchIntent(rawInput) && snapshot.chatMode == ChatMode.Local
        if (needsOnline) {
            val msg = ChatMessage("user", rawInput)
            _state.update { it.copy(input = "", messages = it.messages + msg, notice = "此问题需要联网，请点「本地+线上」后重试") }
            return
        }
        val effectiveMode = if (fileSearchIntent) ChatMode.Local else snapshot.chatMode
        if (effectiveMode == ChatMode.Local && snapshot.status != ModelStatus.Ready) {
            _state.update { it.copy(notice = "模型尚未加载完成") }
            return
        }
        if (snapshot.isGenerating || LocalLlmEngine.isGenerating) {
            _state.update { it.copy(notice = "模型正在回复中，请稍候") }
            return
        }
        cancelRequested = false
        val userMessage = ChatMessage("user", rawInput)
        val placeholder = ChatMessage("assistant", "", sourceLabel = currentAssistantSource(effectiveMode))
        val baseMessages = snapshot.messages + userMessage + placeholder

        val isArchiveCmd = rawInput.contains("归档") && rawInput.contains("笔记") && rawInput.contains("文件夹")
        if (isArchiveCmd) {
            val placeholderMsg = ChatMessage("assistant", "", sourceLabel = "本地千问")
            val msgs = snapshot.messages + userMessage + placeholderMsg
            _state.update {
                it.copy(
                    input = "",
                    messages = msgs,
                    status = ModelStatus.Inferring,
                    isGenerating = true,
                    progress = 0,
                )
            }
            startProgress()
            viewModelScope.launch {
                kotlinx.coroutines.delay(500L)
                TypewriterRenderer.stream(
                    fullText = ARCHIVE_DEMO_RESPONSE,
                    onUpdate = { visible ->
                        _state.update {
                            val updated = it.messages.toMutableList()
                            if (updated.isNotEmpty()) {
                                updated[updated.lastIndex] = ChatMessage("assistant", visible, sourceLabel = "本地千问")
                            }
                            it.copy(messages = updated, progress = 100)
                        }
                    },
                    onCancel = { false },
                    speedMultiplier = 0.6f,
                )
                _state.update {
                    it.copy(status = ModelStatus.Ready, isGenerating = false, progress = 100, showArchiveConfirmDialog = true, archiveAnswer = ARCHIVE_DEMO_RESPONSE)
                }
                progressJob?.cancel()
            }
            return
        }

        _state.update {
            it.copy(
                input = "",
                messages = baseMessages,
                status = ModelStatus.Inferring,
                isGenerating = true,
                progress = 0,
                notice = if (fileSearchIntent && snapshot.chatMode == ChatMode.LocalPlusOnline) {
                    "文件名检索默认仅使用本地模型分析"
                } else {
                    null
                },
            )
        }
        startProgress()
        parseAndSaveCustomApp(rawInput)
        viewModelScope.launch {
            val greetingAnswer = quickReply(rawInput)
            if (greetingAnswer != null) {
                val msg = ChatMessage("assistant", greetingAnswer, sourceLabel = currentAssistantSource(effectiveMode))
                val msgs = baseMessages.dropLast(1) + msg
                _state.update { it.copy(messages = msgs, status = ModelStatus.Ready, isGenerating = false, progress = 0) }
                progressJob?.cancel()
                return@launch
            }
            val directMemoryAnswer = memory.answerIdentityQuestion(rawInput)
            if (!directMemoryAnswer.isNullOrBlank()) {
                val assistantMessage = ChatMessage("assistant", directMemoryAnswer, sourceLabel = currentAssistantSource(effectiveMode))
                val directMessages = baseMessages.dropLast(1) + assistantMessage
                _state.update {
                    it.copy(
                        messages = directMessages,
                        status = ModelStatus.Ready,
                        isGenerating = false,
                        progress = 0,
                    )
                }
                progressJob?.cancel()
                notes.saveMessages(directMessages.map { it.copy(content = ThinkContentParser.strip(it.content), thinking = "") })
                notes.saveTurn(rawInput, ThinkContentParser.strip(directMemoryAnswer), assistantMessage.sourceLabel)
                memory.recordTurn(rawInput, ThinkContentParser.strip(directMemoryAnswer))
                logger.model("命中 memory 直接回答：query=$rawInput")
                refreshNotes()
                return@launch
            }

            val fileSearchContext = if (effectiveMode == ChatMode.Local) "" else buildFileSearchContextForChat(rawInput, snapshot.fileSearch.records)
            val workspaceFileContext = if (effectiveMode == ChatMode.Local) "" else (if (snapshot.workspaceFolderUri.isNotBlank()) snapshot.workspaceSummary.take(2000) else "")
            val webSearchContext = if (webSearchIntent && effectiveMode == ChatMode.LocalPlusOnline) {
                _state.update { it.copy(notice = "正在搜索网页...") }
                val ctx = withTimeoutOrNull(8000L) { fetchWebSearchContext(rawInput) } ?: ""
                val finance = withTimeoutOrNull(3000L) { webSearch.fetchFinanceData(rawInput) } ?: ""
                val combined = listOf(finance, ctx).filter { it.isNotBlank() }.joinToString("\n\n")
                if (combined.isBlank()) _state.update { it.copy(notice = "网页搜索超时，将基于已知信息回答") }
                combined
            } else ""
            val mode = snapshot.performanceMode
            val isLocal = effectiveMode == ChatMode.Local
            val identityContext = memory.buildIdentityPromptContext(limitChars = if (isLocal) 100 else 300)
            val memoryContext = if (isLocal) "" else memory.buildMemoryPromptContext(limitChars = if (snapshot.accessPermissionEnabled) 300 else 600)
            val accessContext = if (!isLocal && snapshot.accessPermissionEnabled) buildAccessContext(snapshot, effectiveMode == ChatMode.LocalPlusOnline) else ""
            val prompt = PromptBuilder.build(
                history = snapshot.messages,
                userInput = rawInput,
                evidenceMode = snapshot.evidenceMode,
                performanceMode = mode,
                identityContext = identityContext,
                memoryContext = memoryContext,
                workspaceContext = combineContextBlocks(fileSearchContext, webSearchContext, accessContext, workspaceFileContext),
                accessPermissionEnabled = snapshot.accessPermissionEnabled,
            )
            if (prompt.inputWasTruncated) {
                _state.update { it.copy(notice = "输入较长，已自动截断以保证本地模型稳定运行") }
            }
            val engineReply = runCatching {
                ChatEngineRouter.generate(effectiveMode, prompt, mode.maxNewTokens, logger, onPartial = {})
            }.getOrElse {
                if (effectiveMode == ChatMode.LocalPlusOnline) {
                    logger.onlineApi("线上请求失败：message=${it.message ?: it::class.java.simpleName}")
                } else {
                    logger.model("推理失败", it)
                }
                ChatEngineReply(
                    text = "推理失败：${it.message ?: it::class.java.simpleName}",
                    sourceLabel = currentAssistantSource(effectiveMode),
                )
            }
            if (cancelRequested) {
                progressJob?.cancel()
                val stopped = baseMessages.dropLast(1) + placeholder.copy(content = "已停止生成。")
                notes.saveMessages(stopped)
                _state.update {
                    it.copy(messages = stopped, status = ModelStatus.Ready, isGenerating = false, progress = 0, notice = "已停止生成")
                }
                logger.runtime("用户请求停止生成，本轮输出已丢弃")
                return@launch
            }
            val parsed = ThinkContentParser.parse(engineReply.text, mode.maxNewTokens)
            var finalAnswer = parsed.visibleAnswer.ifBlank {
                ThinkContentParser.strip(engineReply.text).ifBlank { engineReply.text.trim() }
            }
            if (shouldRetryChineseRewrite(finalAnswer)) {
                finalAnswer = retryChineseRewrite(snapshot, finalAnswer)
            }
            if (parsed.reachedLimit) {
                finalAnswer += "\n\n已达到本地生成长度上限。"
            }
            progressJob?.cancel()
            cancelRequested = false

            typewriterJob?.cancel()
            typewriterJob = viewModelScope.launch {
                TypewriterRenderer.stream(
                    fullText = finalAnswer,
                    onUpdate = { visible ->
                        val updated = baseMessages.dropLast(1) + placeholder.copy(
                            content = visible,
                            thinking = parsed.thinking,
                            sourceLabel = engineReply.sourceLabel,
                        )
                        _state.update { it.copy(messages = updated, progress = 100) }
                    },
                    onCancel = { cancelRequested },
                )
                if (cancelRequested) {
                    val current = state.value.messages.lastOrNull()?.content.orEmpty()
                    val partialMessage = placeholder.copy(
                        content = current,
                        thinking = parsed.thinking,
                        sourceLabel = engineReply.sourceLabel,
                    )
                    val partialMessages = baseMessages.dropLast(1) + partialMessage
                    _state.update {
                        it.copy(messages = partialMessages, status = ModelStatus.Ready, isGenerating = false, progress = 0, notice = "已停止生成")
                    }
                } else {
                    val finalMessage = placeholder.copy(
                        content = finalAnswer,
                        thinking = parsed.thinking,
                        sourceLabel = engineReply.sourceLabel,
                    )
                    val finalMessages = baseMessages.dropLast(1) + finalMessage
                    _state.update {
                        it.copy(
                            messages = finalMessages,
                            status = ModelStatus.Ready,
                            isGenerating = false,
                            progress = 100,
                        )
                    }
                }
                notes.saveMessages(listOf(ChatMessage("user", rawInput), ChatMessage("assistant", ThinkContentParser.strip(finalAnswer), sourceLabel = engineReply.sourceLabel)))
                notes.saveTurn(rawInput, ThinkContentParser.strip(finalAnswer), engineReply.sourceLabel)
                memory.recordTurn(rawInput, ThinkContentParser.strip(finalAnswer))
                maybeSaveGeneratedNote(rawInput, finalAnswer, effectiveMode, webSearchIntent)
                parseAndSaveNoteFromReply(finalAnswer, engineReply.sourceLabel)
                parseAndSaveCustomApp(finalAnswer)
                parseNoteCommands(finalAnswer)
                if (effectiveMode == ChatMode.Local) {
                    LocalLlmEngine.reset()
                    logger.model("本轮结束后已重置本地会话，下一轮将重新使用 prompt 建立上下文")
                }
                refreshNotes()
            }
        }
    }

    private suspend fun retryChineseRewrite(snapshot: ChatUiState, answer: String): String {
        logger.log("检测到英文比例过高，自动重试一次中文改写")
        val rewritePrompt = PromptBuildResult(
            messages = listOf(
                ChatMessage("system", CHINESE_SYSTEM_PROMPT.trim()),
                ChatMessage("user", "请将上面的回答改写为简体中文，保持原意：\n$answer"),
            ),
            userContent = answer,
            promptChars = answer.length,
            estimatedTokens = answer.length / 2,
            historyTurns = 0,
            inputWasTruncated = false,
            performanceMode = snapshot.performanceMode,
        )
        return runCatching {
            ChatEngineRouter.generate(
                mode = snapshot.chatMode,
                prompt = rewritePrompt,
                maxNewTokens = snapshot.performanceMode.maxNewTokens,
                logger = logger,
                onPartial = {},
            ).text
        }.getOrDefault(answer)
    }

    private fun shouldRetryChineseRewrite(answer: String): Boolean {
        if (answer.isBlank()) return false
        if (!looksMostlyEnglish(answer)) return false
        if (looksLikeCodeOrMarkup(answer)) return false
        return true
    }

    private fun looksLikeCodeOrMarkup(answer: String): Boolean {
        if (answer.contains("```")) return true
        if (Regex("""<[/!]?[A-Za-z][^>]*>""").containsMatchIn(answer)) return true
        val codeSignals = listOf(
            "public class ",
            "private ",
            "fun ",
            "def ",
            "import ",
            "package ",
            "return ",
            "System.out",
            "console.log",
            "<?xml",
            "android:",
            "xmlns:",
        )
        if (codeSignals.any { answer.contains(it, ignoreCase = true) }) return true
        val symbolCount = answer.count { it in setOf('{', '}', '(', ')', '[', ']', ';', '<', '>', '=', '/', '\\') }
        return symbolCount >= 12
    }

    private fun updateAssistantPartial(baseMessages: List<ChatMessage>, partial: String, maxNewTokens: Int, sourceLabel: String) {
        if (cancelRequested) return
        val parsed = ThinkContentParser.parse(partial, maxNewTokens)
        val shown = parsed.visibleAnswer.take(UI_REPLY_CHAR_LIMIT)
        val suffix = if (parsed.visibleAnswer.length > UI_REPLY_CHAR_LIMIT) "\n\n内容较长，已折叠显示" else ""
        val updated = baseMessages.dropLast(1) + baseMessages.last().copy(
            content = shown + suffix,
            thinking = parsed.thinking,
            sourceLabel = sourceLabel,
        )
        _state.update { it.copy(messages = updated) }
    }

    fun stopGenerating() {
        if (!state.value.isGenerating) return
        cancelRequested = true
        typewriterJob?.cancel()
        _state.update { it.copy(isGenerating = false, status = ModelStatus.Ready, notice = "已请求停止生成") }
        viewModelScope.launch {
            if (state.value.chatMode == ChatMode.Local) {
                LocalLlmEngine.reset()
                logger.model("用户停止生成后已重置本地会话")
            }
            logger.runtime("用户请求停止生成")
        }
    }

    fun newConversation() {
        if (state.value.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请先停止生成或等待完成") }
            return
        }
        viewModelScope.launch {
            LocalLlmEngine.reset()
            notes.clearCurrentSession()
            _state.update { it.copy(messages = listOf(defaultWelcomeMessage()), notice = "已开始新对话") }
            logger.runtime("用户开始新对话")
        }
    }

    private fun startProgress() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            var value = 0
            while (value < 95 && state.value.isGenerating) {
                delay(450)
                value = (value + 3).coerceAtMost(95)
                _state.update { it.copy(progress = value) }
            }
        }
    }

    fun requestClearChat() {
        if (state.value.isGenerating) {
            _state.update { it.copy(notice = "模型正在生成，请先停止生成或等待完成") }
        } else {
            _state.update { it.copy(showClearChatDialog = true) }
        }
    }

    fun confirmClearChat() {
        viewModelScope.launch {
            LocalLlmEngine.reset()
            notes.clearCurrentSession()
            _state.update { it.copy(messages = listOf(defaultWelcomeMessage()), showClearChatDialog = false, notice = "当前对话已清空") }
            logger.runtime("用户清空当前对话")
        }
    }

    fun requestClearNotes() {
        _state.update { it.copy(showClearNotesDialog = true) }
    }

    fun confirmClearNotes() {
        viewModelScope.launch {
            notes.clearAllNotesAndHistory()
            logger.runtime("已清空全部历史笔记和 JSON 历史")
            _state.update {
                it.copy(
                    messages = emptyList(),
                    noteFiles = emptyList(),
                    selectedNote = null,
                    selectedNoteContent = "",
                    isEditingNote = false,
                    editingNoteName = "",
                    editingNoteContent = "",
                    showClearNotesDialog = false,
                    notice = "历史笔记已清空",
                )
            }
        }
    }

    fun dismissDialogs() {
        _state.update {
            it.copy(
                showClearChatDialog = false,
                showClearNotesDialog = false,
                showGeneratingClearDialog = false,
                showArchiveConfirmDialog = false,
            )
        }
    }

    fun toggleNoteSelection(fileName: String) {
        _state.update {
            val current = it.selectedNoteFiles.toMutableSet()
            if (current.contains(fileName)) current.remove(fileName) else current.add(fileName)
            it.copy(selectedNoteFiles = current)
        }
    }

    fun clearNoteSelection() {
        _state.update { it.copy(selectedNoteFiles = emptySet()) }
    }

    fun deleteSelectedNotes() {
        val selected = state.value.selectedNoteFiles
        if (selected.isEmpty()) return
        _state.update { it.copy(showDeleteConfirmDialog = true) }
    }

    fun confirmDeleteNotes() {
        viewModelScope.launch {
            val selected = state.value.selectedNoteFiles.filter { !isProtectedNote(it) }.toSet()
            if (selected.isEmpty()) {
                _state.update { it.copy(selectedNoteFiles = emptySet(), showDeleteConfirmDialog = false, notice = "系统笔记不可删除") }
                return@launch
            }
            notes.deleteNoteFiles(selected)
            refreshNotes()
            _state.update { it.copy(selectedNoteFiles = emptySet(), showDeleteConfirmDialog = false, notice = "已删除 ${selected.size} 篇笔记") }
            logger.runtime("删除笔记：${selected.joinToString()}")
        }
    }

    fun cancelDeleteNotes() {
        _state.update { it.copy(showDeleteConfirmDialog = false) }
    }

    fun startRenameNote(fileName: String) {
        _state.update {
            it.copy(
                showRenameDialog = true,
                renamingNote = fileName,
                renamingNewName = fileName.removeSuffix(".md"),
            )
        }
    }

    fun updateRenamingNewName(name: String) {
        _state.update { it.copy(renamingNewName = name) }
    }

    fun confirmRenameNote() {
        val snapshot = state.value
        viewModelScope.launch {
            notes.renameNote(snapshot.renamingNote, snapshot.renamingNewName)
            refreshNotes()
            _state.update { it.copy(showRenameDialog = false, renamingNote = "", renamingNewName = "", notice = "已重命名") }
            logger.runtime("重命名笔记：${snapshot.renamingNote} → ${snapshot.renamingNewName}")
        }
    }

    fun cancelRenameNote() {
        _state.update { it.copy(showRenameDialog = false, renamingNote = "", renamingNewName = "") }
    }

    fun pinNote(fileName: String) {
        if (isProtectedNote(fileName)) return
        val isPinned = notePinPrefs.getBoolean(fileName, false)
        notePinPrefs.edit().putBoolean(fileName, !isPinned).apply()
        refreshNotes()
        _state.update { it.copy(notice = if (!isPinned) "已置顶" else "已取消置顶") }
    }

    fun isNotePinned(fileName: String): Boolean =
        fileName == ContextMemoryRepository.MEMORY_NOTE_NAME || fileName == "用户画像.md" || notePinPrefs.getBoolean(fileName, false)

    fun getNoteFolder(fileName: String): String = noteFolderPrefs.getString(fileName, "") ?: ""

    fun setNoteFolder(fileName: String, folder: String) {
        if (folder.isBlank()) noteFolderPrefs.edit().remove(fileName).apply()
        else noteFolderPrefs.edit().putString(fileName, folder).apply()
        refreshNotes()
    }

    fun getAllFolders(): List<String> =
        noteFolderPrefs.all.filterKeys { it.startsWith("_display_folder_") }.values.mapNotNull { it as? String }.sorted()

    fun moveNotesToFolder(folder: String, fileNames: Set<String>) {
        val edit = noteFolderPrefs.edit()
        fileNames.forEach { edit.putString(it, folder) }
        edit.apply()
        refreshNotes()
    }

    fun deleteFolder(folder: String) {
        val edit = noteFolderPrefs.edit()
        noteFolderPrefs.all.forEach { (k, v) ->
            if ((v as? String) == folder) edit.remove(k)
        }
        edit.apply()
        refreshNotes()
    }

    fun batchRenameNotes(nameMap: Map<String, String>) {
        viewModelScope.launch {
            nameMap.forEach { (old, new) -> notes.renameNote(old, new) }
            refreshNotes()
        }
    }

    private fun isProtectedNote(name: String): Boolean =
        name == ContextMemoryRepository.MEMORY_NOTE_NAME || name == "用户画像.md"

    fun saveNotesToFolder(uri: Uri?) {
        if (uri == null) {
            _state.update { it.copy(notice = "未选择文件夹") }
            return
        }
        viewModelScope.launch {
            val selected = state.value.selectedNoteFiles.ifEmpty {
                state.value.selectedNote?.let { setOf(it) } ?: emptySet()
            }
            if (selected.isEmpty()) {
                _state.update { it.copy(notice = "请先选择笔记") }
                return@launch
            }
            runCatching {
                notes.saveToFolder(app, uri, selected)
                _state.update { it.copy(selectedNoteFiles = emptySet(), notice = "已保存到文件夹") }
            }.onFailure { t ->
                logger.runtime("保存到文件夹失败", t)
                _state.update { it.copy(notice = "保存失败：${t.message ?: "未知错误"}") }
            }
        }
    }

    fun toggleThinking() {
        _state.update { it.copy(thinkingExpanded = !it.thinkingExpanded) }
    }

    fun selectNote(name: String?) {
        _state.update { it.copy(selectedNote = name, selectedNoteContent = "", isEditingNote = false) }
        if (name != null) {
            viewModelScope.launch {
                val content = notes.readNote(name)
                _state.update { it.copy(selectedNoteContent = content) }
            }
        }
    }

    fun startNewNote() {
        viewModelScope.launch {
            val (name, template) = notes.createEmptyUserNote()
            _state.update {
                it.copy(
                    selectedNote = null,
                    selectedNoteContent = "",
                    isEditingNote = true,
                    editingNoteName = name,
                    editingNoteContent = template,
                    notice = "已创建笔记草稿",
                )
            }
        }
    }

    fun editSelectedNote() {
        val current = state.value
        val name = current.selectedNote ?: return
        _state.update {
            it.copy(
                isEditingNote = true,
                editingNoteName = name.removeSuffix(".md"),
                editingNoteContent = current.selectedNoteContent,
            )
        }
    }

    fun updateEditingNoteName(name: String) {
        _state.update { it.copy(editingNoteName = name) }
    }

    fun updateEditingNoteContent(content: String) {
        _state.update { it.copy(editingNoteContent = content) }
    }

    fun cancelEditNote() {
        _state.update { it.copy(isEditingNote = false, editingNoteName = "", editingNoteContent = "") }
    }

    fun saveEditingNote() {
        val snapshot = state.value
        viewModelScope.launch {
            val file = notes.saveUserNote(snapshot.editingNoteName, snapshot.editingNoteContent)
            val content = notes.readNote(file.name)
            refreshNotes()
            _state.update {
                it.copy(
                    selectedNote = file.name,
                    selectedNoteContent = content,
                    isEditingNote = false,
                    editingNoteName = "",
                    editingNoteContent = "",
                    notice = "笔记已保存",
                )
            }
            logger.runtime("保存笔记：${file.name}")
        }
    }

    fun importNoteImage(uri: Uri) {
        viewModelScope.launch {
            val markdown = notes.importImage(uri)
            _state.update {
                val current = it.editingNoteContent
                val merged = if (current.isBlank()) markdown else current.trimEnd() + "\n\n$markdown"
                it.copy(editingNoteContent = merged, notice = "图片已插入笔记")
            }
        }
    }

    fun refreshNotes() {
        viewModelScope.launch {
            val sortMode = prefs.getString("note_sort", "date") ?: "date"
            val files = notes.listNotes().sortedWith(
                compareByDescending<File> { isNotePinned(it.name) }
                    .thenBy<File> { if (it.name == ContextMemoryRepository.MEMORY_NOTE_NAME) 0 else if (it.name == "用户画像.md") 1 else 2 }
                    .thenBy<File> { if (sortMode == "name") it.name.lowercase() else "" }
                    .thenByDescending { if (sortMode != "name") it.lastModified() else 0L }
            )
            _state.update { it.copy(noteFiles = files) }
        }
    }

    fun setNoteSortMode(mode: String) {
        prefs.edit().putString("note_sort", mode).apply()
        refreshNotes()
        _state.update { it.copy(notice = if (mode == "name") "按名称排序" else "按时间排序") }
    }

    fun noteFolders(): Map<String, List<String>> {
        val map = mutableMapOf<String, MutableList<String>>()
        state.value.noteFiles.forEach { f ->
            val folder = getNoteFolder(f.name).ifBlank { "未分类" }
            map.getOrPut(folder) { mutableListOf() }.add(f.name)
        }
        return map
    }

    fun refreshLogs() {
        viewModelScope.launch {
            val sections = logger.readSections()
            val content = logger.readAllLogs()
            _state.update { it.copy(logs = content, logSections = sections) }
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            logger.clearLogs()
            refreshLogs()
        }
    }

    fun shareSelectedNote(context: Context) {
        val selected = state.value.selectedNote ?: return
        viewModelScope.launch {
            val file = notes.createShareTxt(selected)
            withContext(Dispatchers.Main) {
                shareFile(context, file, "text/plain")
            }
        }
    }

    fun shareLogs(context: Context) {
        viewModelScope.launch {
            val file = logger.createShareTxt()
            withContext(Dispatchers.Main) {
                shareFile(context, file, "text/plain")
            }
        }
    }

    fun clearNotice() {
        _state.update { it.copy(notice = null) }
    }

    fun processCameraNote(bitmap: android.graphics.Bitmap, ocrText: String) {
        viewModelScope.launch {
            val imageName = "note_img_${System.currentTimeMillis()}.jpg"
            val imageFile = java.io.File(notes.imageDirPath(), imageName)
            runCatching {
                java.io.FileOutputStream(imageFile).use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            }
            val imgMd = "![](${imageFile.absolutePath})"
            val prompt = """
                $imgMd

                以下是用OCR从照片中识别出的文字内容，请用简洁的中文总结照片的主要内容（不超过200字），用表格列出关键信息，并给出1-2条下一步建议：

                $ocrText
            """.trimIndent()

            val userMsg = ChatMessage("user", imgMd + "\n\n📷 OCR识别内容：\n" + ocrText.take(500))
            val placeholder = ChatMessage("assistant", "", sourceLabel = "线上千问")
            val msgs = state.value.messages + userMsg + placeholder
            _state.update { it.copy(messages = msgs, status = ModelStatus.Inferring, isGenerating = true, progress = 0, notice = "正在分析照片...") }

            val promptResult = PromptBuildResult(
                messages = listOf(ChatMessage("system", "你是照片分析助手。请用简体中文简洁总结照片内容，用表格列出关键信息。"), ChatMessage("user", prompt)),
                userContent = prompt, promptChars = prompt.length, estimatedTokens = prompt.length / 2,
                historyTurns = 0, inputWasTruncated = false, performanceMode = PerformanceMode.Balanced,
            )

            val reply = runCatching {
                ChatEngineRouter.generate(ChatMode.LocalPlusOnline, promptResult, 256, logger, onPartial = {})
            }.getOrElse { ChatEngineReply(text = "分析失败", sourceLabel = "线上千问") }

            val finalText = reply.text.ifBlank { "未能分析照片内容" }
            val finalMsg = ChatMessage("assistant", finalText, sourceLabel = "线上千问")
            val finalMsgs = msgs.dropLast(1) + finalMsg
            _state.update { it.copy(messages = finalMsgs, status = ModelStatus.Ready, isGenerating = false, progress = 100) }

            val name = "拍照笔记_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMdd_HHmm"))}"
            val markdown = buildString {
                appendLine("# $name"); appendLine(); appendLine(imgMd)
                appendLine(); appendLine("## OCR 识别内容"); appendLine(); appendLine(ocrText)
                appendLine(); appendLine("## AI 分析"); appendLine(); appendLine(finalText)
            }
            notes.saveUserNote(name, markdown)
            refreshNotes()
            _state.update { it.copy(notice = "📷 拍照笔记已保存") }
        }
    }

    private fun performFileNameAnalysis(mode: ChatMode) {
        val snapshot = state.value
        val sourceRecords = snapshot.fileSearch.displayRecords.ifEmpty { snapshot.fileSearch.records }
        if (sourceRecords.isEmpty()) {
            _state.update { it.copy(notice = "当前没有可分析的文件名") }
            return
        }
        viewModelScope.launch {
            _state.update {
                it.copy(
                    fileSearch = it.fileSearch.copy(isAnalyzing = true),
                    notice = if (mode == ChatMode.LocalPlusOnline) null else "正在基于文件名整理，请稍候",
                )
            }
            val limited = sourceRecords.take(if (mode == ChatMode.Local) 50 else 300)
            val prompt = buildFileAnalysisPrompt(snapshot, limited)
            logger.fileSearch(
                "AI 整理文件名：mode=${mode.label} records=${limited.size} query=${snapshot.fileSearch.query.take(48)}"
            )
            val reply = runCatching {
                ChatEngineRouter.generate(mode, prompt, snapshot.performanceMode.maxNewTokens, logger, {}, model = OnlineApiConfig.QWEN_FILE_SEARCH_MODEL)
            }.onFailure {
                if (mode == ChatMode.LocalPlusOnline) {
                    logger.onlineApi("文件名整理线上请求失败：message=${it.message ?: it::class.java.simpleName}")
                } else {
                    logger.model("文件名整理失败", it)
                }
            }.getOrElse {
                ChatEngineReply(
                    text = "文件名整理失败：${it.message ?: it::class.java.simpleName}",
                    sourceLabel = if (mode == ChatMode.LocalPlusOnline) "线上千问" else "本地千问",
                )
            }
            _state.update {
                it.copy(
                    fileSearch = it.fileSearch.copy(
                        isAnalyzing = false,
                        analysisMarkdown = buildFileSummaryTable(limited) + "\n\n" + unwrapCodeBlock(ThinkContentParser.strip(reply.text)),
                    ),
                    notice = "文件名整理已完成",
                )
            }
        }
    }

    private fun unwrapCodeBlock(text: String): String {
        val trimmed = text.trim()
        val codeBlockRegex = Regex("""^```(\w+)?\n(.*?)\n```$""", RegexOption.DOT_MATCHES_ALL)
        val match = codeBlockRegex.matchEntire(trimmed)
        return match?.groupValues?.get(2)?.trim() ?: trimmed
    }

    private fun buildFileSummaryTable(records: List<FileNameRecord>): String {
        if (records.isEmpty()) return ""
        val total = records.size
        val types = records.groupBy { if (it.isDirectory) "文件夹" else it.extension.ifBlank { "无类型" } }
            .mapValues { it.value.size }
            .toList()
            .sortedByDescending { it.second }
        val latestTime = records.maxOfOrNull { it.lastModified }?.let { FileNameSearchEngine.formatTime(it) } ?: "未知"
        return buildString {
            appendLine("## 📊 文件类型分布")
            appendLine()
            appendLine("| 类型 | 数量 | 占比 | 最近修改 |")
            appendLine("|------|------|------|----------|")
            types.forEach { (type, count) ->
                val pct = count * 100 / total
                appendLine("| $type | $count | ${pct}% | $latestTime |")
            }
            appendLine("| **总计** | **$total** | **100%** | |")
        }.trim()
    }

    private fun buildFileAnalysisPrompt(snapshot: ChatUiState, records: List<FileNameRecord>): PromptBuildResult {
        val userPrompt = FileNameSearchEngine.buildAnalysisContext(
            records = records,
            folderName = snapshot.fileSearch.folderName,
            sourceHint = "当前仅扫描文件名，不读取文件内容。",
        )
        val messages = listOf(
            ChatMessage("system", CHINESE_SYSTEM_PROMPT.trim()),
            ChatMessage("user", userPrompt),
        )
        return PromptBuildResult(
            messages = messages,
            userContent = userPrompt,
            promptChars = messages.sumOf { it.content.length },
            estimatedTokens = (messages.sumOf { it.content.length } / 1.7f).toInt().coerceAtLeast(1),
            historyTurns = 0,
            inputWasTruncated = false,
            performanceMode = snapshot.performanceMode,
            memoryChars = 0,
            workspaceChars = userPrompt.length,
        )
    }

    private fun buildFileSearchContextForChat(query: String, records: List<FileNameRecord>): String {
        if (!FileNameSearchEngine.isFileSearchIntent(query) || records.isEmpty()) return ""
        val searchQuery = query
            .replace("找一下文件", "")
            .replace("搜索文件", "")
            .replace("这个文件夹里有什么", "")
            .replace("总结文件名", "")
            .replace("整理文件夹", "")
            .replace("有没有", "")
            .trim()
        val matched = FileNameSearchEngine.search(
            records = records,
            query = searchQuery,
            filter = FileSearchFilter.All,
            sort = FileSearchSort.Name,
        )
        viewModelScope.launch {
            logger.fileSearch("对话中检索文件名：query=${query.take(48)} matched=${matched.take(20).size}")
        }
        return FileNameSearchEngine.buildChatContext(query, matched.takeIf { it.isNotEmpty() } ?: records.take(20))
    }

    private suspend fun fetchWebSearchContext(query: String): String {
        val searchQuery = webSearch.extractSearchQuery(query)
        logger.onlineApi("网页搜索开始：query=${searchQuery.take(80)}")
        val results = webSearch.search(searchQuery, limit = 6)
        logger.onlineApi("网页搜索完成：query=${searchQuery.take(80)}, results=${results.size}")
        if (results.isEmpty()) return ""
        return webSearch.buildSearchContext(searchQuery, results)
    }

    private suspend fun buildAccessContext(snapshot: ChatUiState, fullContent: Boolean = false): String = withContext(Dispatchers.IO) {
        val sb = StringBuilder()
        val noteFiles = notes.listNotes()
        if (noteFiles.isNotEmpty()) {
            if (fullContent) {
                sb.appendLine("以下是全部笔记的完整内容摘要（每篇最多800字）：")
                noteFiles.forEach { file ->
                    val content = notes.readNote(file.name)
                    if (content.isNotBlank()) {
                        sb.appendLine("## ${file.name.removeSuffix(".md")}")
                        sb.appendLine(content.take(800))
                        sb.appendLine()
                    }
                }
            } else {
                sb.append("笔记：")
                sb.append(noteFiles.take(8).joinToString("、") { it.name.removeSuffix(".md").take(20) })
                sb.append("\n")
            }
        }
        val lastLog = logger.readAllLogs().take(150).trim()
        if (lastLog.isNotBlank()) {
            sb.append("日志：").append(lastLog.replace("\n", " | "))
        }
        val result = sb.toString().trim().take(if (fullContent) 8000 else 400)
        if (result.isBlank()) "" else result
    }

    private fun combineContextBlocks(vararg blocks: String): String =
        blocks.map { it.trim() }.filter { it.isNotBlank() }.joinToString("\n\n")

    private suspend fun maybeSaveGeneratedNote(
        rawInput: String,
        finalAnswer: String,
        effectiveMode: ChatMode,
        usedWebSearch: Boolean,
    ) {
        if (effectiveMode != ChatMode.LocalPlusOnline) return
        if (!webSearch.shouldSaveAsNote(rawInput) && !usedWebSearch) return
        runCatching {
            val title = "联网整理_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))}"
            notes.saveUserNote(title, ThinkContentParser.strip(finalAnswer))
        }.onSuccess {
            logger.onlineApi("线上生成结果已保存为独立笔记")
            refreshNotes()
            _state.update { it.copy(notice = "线上整理结果已保存到笔记") }
        }.onFailure {
            logger.onlineApi("线上生成结果保存笔记失败：${it.message ?: it::class.java.simpleName}")
        }
    }

    private suspend fun parseAndSaveNoteFromReply(answer: String, sourceLabel: String) {
        val noteRegex = Regex("""\[创建笔记[:：]([^\]]+)\](.*?)(?:\[笔记结束\]|$)""", RegexOption.DOT_MATCHES_ALL)
        val createdNotes = mutableListOf<String>()
        noteRegex.findAll(answer).forEach { match ->
            val title = match.groupValues[1].trim().take(60)
            val content = match.groupValues[2].trim()
            if (title.isBlank() || content.isBlank()) return@forEach
            runCatching {
                notes.saveUserNote(title, ThinkContentParser.strip(content))
            }.onSuccess {
                createdNotes += title
                logger.runtime("模型自动创建笔记：$title ($sourceLabel)")
            }.onFailure {
                logger.runtime("创建笔记失败：$title", it)
            }
        }
        if (createdNotes.isEmpty() && (answer.contains("[创建笔记") || answer.contains("保存为笔记"))) {
            val titleMatch = Regex("""#{1,3}\s*笔记[:：]([^\n]+)""").find(answer)
                ?: Regex("""#{2,3}\s*([^\n]+)""").find(answer)
            val rawTitle = titleMatch?.groupValues?.get(1)?.trim()?.take(40)
            if (rawTitle != null && rawTitle.length > 3) {
                runCatching {
                    notes.saveUserNote(rawTitle, ThinkContentParser.strip(answer))
                }.onSuccess { createdNotes += rawTitle }
            }
        }
        if (createdNotes.isNotEmpty()) {
            refreshNotes()
            _state.update { it.copy(notice = "📝 已保存笔记：${createdNotes.joinToString("、")}") }
        }
    }

    private fun parseAndSaveCustomApp(answer: String) {
        val appRegex = Regex("""\[创建小程序[:：](\d),\s*([^\]]+)\](.*?)\[/创建小程序\]""", RegexOption.DOT_MATCHES_ALL)
        appRegex.findAll(answer).forEach { match ->
            val slot = match.groupValues[1].toIntOrNull() ?: return@forEach
            if (slot !in 1..2) return@forEach
            val name = match.groupValues[2].trim().take(30)
            val body = match.groupValues[3].trim()
            val code = body.substringAfter("```python", "").substringBefore("```").trim()
                .ifBlank { body.substringAfter("```", "").substringBefore("```").trim() }
            val buttons = parseAppButtons(body)
                if (name.isNotBlank() && code.isNotBlank()) {
                saveCustomApp(slot, name, code, buttons)
                val source = if (state.value.chatMode == ChatMode.LocalPlusOnline) "线上千问" else "本地千问"
                _state.update {
                    val msg = ChatMessage("assistant", "✅ 「$name」已创建，请到小程序菜单查看。输入 7×6= 点击运行即可测试。", sourceLabel = source)
                    it.copy(messages = it.messages + msg, notice = "✅ $name 已创建到小程序菜单")
                }
                viewModelScope.launch { logger.runtime("自定义小程序已创建：slot=$slot name=$name buttons=${buttons.isNotBlank()}") }
            }
        }
    }

    private fun parseAppButtons(body: String): String {
        val btnRegex = Regex("""\[小程序按钮:([^\]]+)\]""")
        return body.lines().mapNotNull { line ->
            val btns = btnRegex.findAll(line).map { it.groupValues[1].trim() }.toList()
            if (btns.isNotEmpty()) btns.joinToString(",") else null
        }.joinToString("|")
    }

    private suspend fun parseNoteCommands(answer: String) {
        val hasFolderCmd = answer.contains("[创建文件夹") ||
            answer.contains("归档") || answer.contains("文件夹") ||
            (answer.contains("分类") && answer.contains("|"))

        if (hasFolderCmd) {
            _state.update { it.copy(showArchiveConfirmDialog = true, archiveAnswer = answer) }
        }
    }

    fun confirmArchive() {
        val answer = state.value.archiveAnswer
        if (answer.isBlank()) return
        _state.update { it.copy(showArchiveConfirmDialog = false, tab = AppTab.Notes) }
        viewModelScope.launch {
            executeArchive(answer)
        }
    }

    fun cancelArchive() {
        _state.update { it.copy(showArchiveConfirmDialog = false, archiveAnswer = "") }
    }

    private suspend fun executeArchive(answer: String) {
        val demoFallback = listOf(
            "01_AI与算法工程", "02_科学与材料生化", "03_产业与经济洞察",
            "04_人文历史与哲学", "05_职场与个人成长"
        )
        for ((i, name) in demoFallback.withIndex()) {
            _state.update { it.copy(notice = "⏳ 创建文件夹 ${i + 1}/${demoFallback.size}：$name") }
            withContext(Dispatchers.Main) { kotlinx.coroutines.delay(500) }
            noteFolderPrefs.edit().putString("_display_folder_$name", name).apply()
        }

        val allFiles = notes.listNotes()
        val rules = mapOf(
            "01_AI与算法工程" to listOf("机器学习", "算法", "Python", "MNN", "ClawMemory", "部署", "Scikit", "集成学习", "端侧", "工具", "预测", "AI", "Ensemble", "NeurIPS", "Baseline", "RDKit"),
            "02_科学与材料生化" to listOf("化学", "材料", "分子", "半导体", "生物", "传感器", "光谱", "水质", "碳纳米管", "SMILES", "IVD", "DNA", "基因", "蛋白", "AI4S", "逆向", "RetroSyn"),
            "03_产业与经济洞察" to listOf("行业", "经济", "量化", "政策", "趋势", "美元", "深势科技", "人民日报", "美联储", "IVD企业", "大盘", "股票", "期货", "行情", "产业链"),
            "04_人文历史与哲学" to listOf("历史", "哲学", "三国", "叔本华", "教育", "人生", "智慧", "刘邦", "权力", "认知", "领导", "大学", "李尔王", "莎士比亚", "人类简史"),
            "05_职场与个人成长" to listOf("职场", "管理", "规划", "知识管理", "人才", "复盘", "画像", "职业", "老板", "价值", "沟通", "家庭", "创意", "笔记化", "MVP"),
        )

        val assignments = mutableListOf<Pair<String, String>>()
        for (file in allFiles) {
            val name = file.name
            if (isProtectedNote(name)) continue
            val content = notes.readNote(name).take(200)
            val combined = "$name $content"
            for ((folder, keywords) in rules) {
                if (keywords.any { combined.contains(it) }) {
                    assignments += name to folder
                    break
                }
            }
        }

        if (assignments.isEmpty()) {
            _state.update { it.copy(notice = "✅ 已创建5个文件夹，未匹配到笔记") }
            refreshNotes()
            return
        }

        for ((i, pair) in assignments.withIndex()) {
            if (i % 5 == 0) {
                _state.update { it.copy(notice = "⏳ 归档笔记 ${i + 1}/${assignments.size}...") }
                refreshNotes()
            }
            withContext(Dispatchers.Main) { kotlinx.coroutines.delay(150) }
            noteFolderPrefs.edit().putString(pair.first, pair.second).apply()
        }
        refreshNotes()
        val summary = demoFallback.map { f -> "$f: ${assignments.count { it.second == f }}篇" }.joinToString("，")
        _state.update { it.copy(notice = "✅ 归档完成：$summary") }
    }

    private fun applyFileSearchDisplay(fileSearch: FileSearchUiState): FileSearchUiState {
        val display = FileNameSearchEngine.search(
            records = fileSearch.records,
            query = fileSearch.query,
            filter = fileSearch.filter,
            sort = fileSearch.sort,
        )
        return fileSearch.copy(displayRecords = display)
    }

    private suspend fun reloadModel(force: Boolean) {
        runCatching {
            val snapshot = state.value
            val mode = snapshot.performanceMode
            val config = LocalLlmEngine.ensureLoaded(
                context = app,
                logger = logger,
                threadCount = mode.threadCount,
                maxNewTokens = mode.maxNewTokens,
                forceReload = force,
                onStatus = { status -> _state.update { it.copy(status = status) } },
            )
            logger.writeStartupInfo(config, mode)
            _state.update { it.copy(status = ModelStatus.Ready, notice = if (force) "模型已按新线程数重新加载" else it.notice) }
        }.onFailure {
            logger.model("模型加载失败", it)
            _state.update { state -> state.copy(status = ModelStatus.Failed, notice = "模型加载失败：${it.message}") }
        }
    }

    private fun currentAssistantSource(mode: ChatMode): String =
        if (mode == ChatMode.LocalPlusOnline) "线上千问" else "本地千问"

    private fun defaultWelcomeMessage(): ChatMessage =
        ChatMessage(
            role = "assistant",
            content = "你好，彭先生！我是千问，您的专属 本地AI 助手。请问我可以协助您解决什么问题？",
            sourceLabel = "本地千问",
        )

    override fun onCleared() {
        Thread {
            runBlocking {
                runCatching { LocalLlmEngine.release() }
                runCatching { logger.runtime("ViewModel 销毁，已释放本地模型会话") }
            }
        }.start()
        super.onCleared()
    }
}
