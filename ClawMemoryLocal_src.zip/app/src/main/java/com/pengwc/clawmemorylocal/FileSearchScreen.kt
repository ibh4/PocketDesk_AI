package com.pengwc.clawmemorylocal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FileSearchScreen(
    state: FileSearchUiState,
    onBack: () -> Unit,
    onPickFolder: () -> Unit,
    onRefreshScan: () -> Unit,
    onCancelScan: () -> Unit,
    onDisconnectFolder: () -> Unit,
    onClearIndex: () -> Unit,
    onQueryChange: (String) -> Unit,
    onFilterChange: (FileSearchFilter) -> Unit,
    onSortChange: (FileSearchSort) -> Unit,
    onAnalyze: () -> Unit,
    onSaveReportInternal: () -> Unit,
    onSaveReportToFolder: () -> Unit,
    onConfirmAnalyzeLocal: () -> Unit,
    onConfirmAnalyzeOnline: () -> Unit,
    onDismissAnalyzeDialog: () -> Unit,
    onToggleReadWrite: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AppPageBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            OutlinedButton(onClick = onBack) { Text("← 返回", color = PrimaryPurple, fontSize = 12.sp) }
            val modeLabel = if (state.readWriteEnabled) "读写" else "只读"
            val modeColor = if (state.readWriteEnabled) Color(0xFFDC2626) else Color(0xFF16A34A)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .border(1.dp, DividerSoft, RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("📂", fontSize = 13.sp)
                        Text(
                            text = state.folderName.ifBlank { "未选择文件夹" },
                            color = AiTextColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(modeColor.copy(alpha = 0.12f), RoundedCornerShape(5.dp))
                            .border(0.8.dp, modeColor, RoundedCornerShape(5.dp))
                            .clickable { onToggleReadWrite() }
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    ) {
                        Text(modeLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = modeColor)
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = if (state.lastScannedAt.isNotBlank()) "扫描：${state.lastScannedAt}" else "尚未扫描",
                        color = SecondaryTextColor,
                        fontSize = 10.sp,
                    )
                }
            }
        }
        ActionButtons(
            state = state,
            onPickFolder = onPickFolder,
            onRefreshScan = onRefreshScan,
            onCancelScan = onCancelScan,
            onDisconnectFolder = onDisconnectFolder,
            onClearIndex = onClearIndex,
        )
        if (state.isScanning) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = PrimaryPurple,
                trackColor = Color(0xFFE5E7EB),
            )
            Text(state.scanProgressText.ifBlank { "扫描中..." }, color = SecondaryTextColor, fontSize = 12.sp)
        }
        OutlinedTextField(
            value = state.query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("搜索文件名或路径") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = InputBackground,
                unfocusedContainerColor = InputBackground,
                focusedBorderColor = InputBorder,
                unfocusedBorderColor = InputBorder,
            ),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onAnalyze,
                enabled = state.records.isNotEmpty() && !state.isAnalyzing && !state.isScanning,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
            ) {
                Text(if (state.isAnalyzing) "整理中..." else "让 AI 整理文件名")
            }
            OutlinedButton(
                onClick = onSaveReportInternal,
                enabled = state.analysisMarkdown.isNotBlank() && !state.isAnalyzing,
            ) { Text("保存报告", color = PrimaryPurple) }
            if (state.folderUri.isNotBlank() && state.readWriteEnabled) {
                OutlinedButton(
                    onClick = onSaveReportToFolder,
                    enabled = state.analysisMarkdown.isNotBlank() && !state.isAnalyzing,
                ) { Text("写入文件夹", color = PrimaryPurple, fontSize = 12.sp) }
            }
        }
        if (state.analysisMarkdown.isNotBlank()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(16.dp))
                    .border(1.dp, DividerSoft, RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("AI 整理结果", color = AiTextColor, fontWeight = FontWeight.SemiBold)
                MarkdownView(markdown = state.analysisMarkdown)
            }
        }
        Text("筛选", color = SecondaryTextColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        OptionRow {
            FileSearchFilter.entries.forEach { filter ->
                SimpleChoiceChip(
                    label = filter.label,
                    selected = state.filter == filter,
                    onClick = { onFilterChange(filter) },
                )
            }
        }
        Text("排序", color = SecondaryTextColor, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        OptionRow {
            FileSearchSort.entries.forEach { sort ->
                SimpleChoiceChip(
                    label = sort.label,
                    selected = state.sort == sort,
                    onClick = { onSortChange(sort) },
                )
            }
        }
        Text(
            "搜索结果（${state.displayRecords.size}）",
            color = AiTextColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
        if (state.displayRecords.isEmpty()) {
            ResultCard(
                title = "暂无结果",
                content = if (state.records.isEmpty()) "请先选择文件夹并扫描。" else "当前筛选条件下没有匹配的文件名。",
            )
        } else {
            state.displayRecords.take(80).forEach { record ->
                FileRecordCard(record)
            }
        }
        Text("请不要在未确认来源的情况下，把文件名列表发送到线上。", color = Color(0xFFF59E0B), fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
    }

    if (state.showOnlineConfirmDialog) {
        AlertDialog(
            onDismissRequest = onDismissAnalyzeDialog,
            title = { Text("是否发送文件名列表到线上千问？") },
            text = { Text("本次仅发送文件名、相对路径、扩展名、大小和修改时间，不发送文件内容。是否继续？") },
            confirmButton = {
                Button(
                    onClick = onConfirmAnalyzeOnline,
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
                ) { Text("发送到线上") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = onConfirmAnalyzeLocal) { Text("仅用本地模型", color = PrimaryPurple) }
                    TextButton(onClick = onDismissAnalyzeDialog) { Text("取消", color = SecondaryTextColor) }
                }
            },
        )
    }
}

@Composable
private fun ActionButtons(
    state: FileSearchUiState,
    onPickFolder: () -> Unit,
    onRefreshScan: () -> Unit,
    onCancelScan: () -> Unit,
    onDisconnectFolder: () -> Unit,
    onClearIndex: () -> Unit,
) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Button(
            onClick = onPickFolder,
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple, contentColor = Color.White),
        ) { Text("选择文件夹", fontSize = 12.sp) }
        OutlinedButton(onClick = if (state.isScanning) onCancelScan else onRefreshScan) {
            Text(if (state.isScanning) "取消扫描" else "刷新扫描", color = PrimaryPurple, fontSize = 12.sp)
        }
        OutlinedButton(onClick = onClearIndex) { Text("清空索引", color = PrimaryPurple, fontSize = 12.sp) }
        if (state.folderUri.isNotBlank()) {
            OutlinedButton(onClick = onDisconnectFolder) {
                Text("断开文件夹", color = PrimaryPurple, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun FileRecordCard(record: FileNameRecord) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, DividerSoft, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text(record.name, color = AiTextColor, fontWeight = FontWeight.SemiBold)
        Text(record.relativePath, color = SecondaryTextColor, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            InfoPill(if (record.isDirectory) "文件夹" else record.extension.ifBlank { "无类型" })
            Text(FileNameSearchEngine.readableSize(record.sizeBytes), color = SecondaryTextColor, fontSize = 12.sp)
            Text(FileNameSearchEngine.formatTime(record.lastModified), color = SecondaryTextColor, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ResultCard(title: String, content: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(16.dp))
            .border(1.dp, DividerSoft, RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = AiTextColor, fontWeight = FontWeight.SemiBold)
        Text(content, color = AiTextColor, fontSize = 13.sp)
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFEFF6FF), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFFDBEAFE), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(title, color = Color(0xFF1E3A8A), fontWeight = FontWeight.SemiBold)
        Text(body, color = SecondaryTextColor, fontSize = 12.sp)
    }
}

@Composable
private fun OptionRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) { content() }
}

@Composable
private fun SimpleChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(if (selected) PrimaryPurple else Color.White, RoundedCornerShape(4.dp))
            .border(0.6.dp, InputBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
            .then(Modifier),
    ) {
        TextButton(onClick = onClick, modifier = Modifier.padding(0.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 0.dp, vertical = 0.dp)) {
            Text(
                label,
                color = if (selected) Color.White else AiTextColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun InfoPill(text: String) {
    Box(
        modifier = Modifier
            .background(Color(0xFFEFF6FF), RoundedCornerShape(99.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp),
    ) {
        Text(text, color = Color(0xFF1E3A8A), fontSize = 11.sp)
    }
}
