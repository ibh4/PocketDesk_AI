import contextlib
import io
import json
import time
import traceback


def run_user_code(code: str) -> str:
    stdout = io.StringIO()
    stderr = io.StringIO()
    started = time.perf_counter()
    result = {
        "success": False,
        "stdout": "",
        "stderr": "",
        "traceback": "",
        "duration_ms": 0,
    }
    try:
        compiled = compile(code, "<user_code>", "exec")
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(compiled)
        result["success"] = True
    except Exception:
        result["traceback"] = traceback.format_exc()
    finally:
        result["stdout"] = stdout.getvalue()
        result["stderr"] = stderr.getvalue()
        result["duration_ms"] = int((time.perf_counter() - started) * 1000)
    return json.dumps(result, ensure_ascii=False)
