#include <jni.h>
#include <android/log.h>
#include <sstream>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include "llm/llm.hpp"

using MNN::Transformer::ChatMessages;
using MNN::Transformer::Llm;

namespace {

struct Session {
    Llm* llm = nullptr;
    std::string systemPrompt;
    int threadCount = 2;
    int maxNewTokens = 256;
    std::mutex mutex;
};

class CallbackStreamBuf : public std::stringbuf {
public:
    CallbackStreamBuf(JNIEnv* env, jobject callback)
        : env_(env), callback_(callback) {
        jclass cls = env_->GetObjectClass(callback_);
        onToken_ = env_->GetMethodID(cls, "onToken", "(Ljava/lang/String;)Z");
    }

    std::string result() const { return result_; }

protected:
    std::streamsize xsputn(const char* s, std::streamsize n) override {
        std::string token(s, static_cast<size_t>(n));
        result_ += token;
        emit(token);
        return n;
    }

    int overflow(int c) override {
        if (c != EOF) {
            char ch = static_cast<char>(c);
            std::string token(1, ch);
            result_ += token;
            emit(token);
        }
        return c;
    }

private:
    void emit(const std::string& token) {
        if (!onToken_ || token.empty()) return;
        jstring jToken = env_->NewStringUTF(token.c_str());
        env_->CallBooleanMethod(callback_, onToken_, jToken);
        env_->DeleteLocalRef(jToken);
    }

    JNIEnv* env_;
    jobject callback_;
    jmethodID onToken_ = nullptr;
    std::string result_;
};

std::string jstringToString(JNIEnv* env, jstring value) {
    if (!env || !value) return "";
    const char* raw = env->GetStringUTFChars(value, nullptr);
    std::string out(raw ? raw : "");
    if (raw) env->ReleaseStringUTFChars(value, raw);
    return out;
}

std::string runtimeConfigJson(int threadCount, int maxNewTokens) {
    threadCount = std::max(1, std::min(threadCount, 4));
    maxNewTokens = std::max(1, std::min(maxNewTokens, 512));
    std::ostringstream os;
    os << "{"
       << "\"async\":false,"
       << "\"use_mmap\":true,"
       << "\"reuse_kv\":false,"
       << "\"prompt_cache\":false,"
       << "\"backend_type\":\"cpu\","
       << "\"thread_num\":" << threadCount << ","
       << "\"max_new_tokens\":" << maxNewTokens << ","
       << "\"is_visual\":false,"
       << "\"is_audio\":false,"
       << "\"has_talker\":false,"
       << "\"mllm\":{\"backend_type\":\"cpu\",\"thread_num\":" << threadCount << ",\"precision\":\"low\",\"memory\":\"low\"},"
       << "\"jinja\":{\"context\":{\"enable_thinking\":false}}"
       << "}";
    return os.str();
}

} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_pengwc_clawmemorylocal_NativeMnnLlm_nativeInit(
        JNIEnv* env,
        jobject,
        jstring configPath,
        jstring systemPrompt,
        jint threadCount,
        jint maxNewTokens) {
    if (!env || !configPath) return 0;
    auto* session = new Session();
    auto config = jstringToString(env, configPath);
    session->systemPrompt = jstringToString(env, systemPrompt);
    session->threadCount = std::max(1, std::min(static_cast<int>(threadCount), 4));
    session->maxNewTokens = std::max(1, std::min(static_cast<int>(maxNewTokens), 512));
    if (config.empty()) {
        delete session;
        return 0;
    }
    session->llm = Llm::createLLM(config);
    if (!session->llm) {
        delete session;
        return 0;
    }
    session->llm->set_config(runtimeConfigJson(session->threadCount, session->maxNewTokens));
    if (!session->llm->load()) {
        Llm::destroy(session->llm);
        delete session;
        return 0;
    }
    return reinterpret_cast<jlong>(session);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_pengwc_clawmemorylocal_NativeMnnLlm_nativeGenerate(
        JNIEnv* env,
        jobject,
        jlong ptr,
        jobjectArray roles,
        jobjectArray contents,
        jint maxNewTokens,
        jobject callback) {
    auto* session = reinterpret_cast<Session*>(ptr);
    if (!session || !session->llm) {
        return env->NewStringUTF("模型未加载");
    }
    if (!roles || !contents || !callback) {
        return env->NewStringUTF("nativeGenerate 参数为空");
    }
    std::unique_lock<std::mutex> lock(session->mutex, std::try_to_lock);
    if (!lock.owns_lock()) {
        return env->NewStringUTF("模型正在生成中，请稍候");
    }

    ChatMessages history;
    history.emplace_back("system", session->systemPrompt);
    const jsize size = env->GetArrayLength(roles);
    const jsize contentSize = env->GetArrayLength(contents);
    if (size != contentSize) {
        return env->NewStringUTF("nativeGenerate roles/contents 数量不一致");
    }
    for (jsize i = 0; i < size; ++i) {
        auto role = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto content = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        std::string roleStr = jstringToString(env, role);
        std::string contentStr = jstringToString(env, content);
        if (roleStr != "system") {
            history.emplace_back(roleStr, contentStr);
        }
        env->DeleteLocalRef(role);
        env->DeleteLocalRef(content);
    }

    try {
        int limit = std::max(1, std::min(static_cast<int>(maxNewTokens), 512));
        session->llm->set_config(runtimeConfigJson(session->threadCount, limit));
        CallbackStreamBuf buf(env, callback);
        std::ostream output(&buf);
        session->llm->response(history, &output, nullptr, limit);
        auto* context = session->llm->getContext();
        std::string result = context && !context->generate_str.empty()
            ? context->generate_str
            : buf.result();
        return env->NewStringUTF(result.c_str());
    } catch (const std::exception& e) {
        std::string msg = std::string("nativeGenerate 异常：") + e.what();
        return env->NewStringUTF(msg.c_str());
    } catch (...) {
        return env->NewStringUTF("nativeGenerate 未知异常");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_pengwc_clawmemorylocal_NativeMnnLlm_nativeReset(JNIEnv*, jobject, jlong ptr) {
    auto* session = reinterpret_cast<Session*>(ptr);
    if (session && session->llm) {
        session->llm->reset();
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_pengwc_clawmemorylocal_NativeMnnLlm_nativeRelease(JNIEnv*, jobject, jlong ptr) {
    auto* session = reinterpret_cast<Session*>(ptr);
    if (!session) return;
    if (session->llm) {
        Llm::destroy(session->llm);
        session->llm = nullptr;
    }
    delete session;
}
