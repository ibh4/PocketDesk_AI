# 口袋智桌 / PocketDesk AI 图标设计说明

当前启动器名称：
- `PocketDesk AI`

## 源 SVG 路径

- 原始 SVG：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/raw/pocketdesk_icon_source.svg`
- 文档备份：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/docs/icon/pocketdesk_icon_source.svg`

当前使用的 SVG 为：
- `alien-svgrepo-com.svg`

## 最终采用方案

- **最终启动器图标：VectorDrawable + adaptive icon**
- **PNG 渲染图保留为预览与备用资源**

原因是源 SVG 含有以下 Android VectorDrawable 不稳定或不支持的特性：
- `<style>` / class 样式
- 多个 `linearGradient`
- `xlink`
- `stroke-dasharray`
- `opacity`
- `isolation`

为了尽量保证 Android 启动器兼容性，同时避免位图被桌面再次裁切得太厉害，最终采用：
- 从 SVG 中手工提取主体路径
- 生成 `drawable/ic_launcher_foreground.xml`
- 生成 `drawable/ic_launcher_background.xml`
- 使用 `mipmap-anydpi-v26` 的 adaptive icon 入口
- PNG 版本保留为备用资源

## 设计理念

当前这套图标采用外星人风格 SVG，并将主体手工转成了 Android VectorDrawable。这样在启动器里可以直接用矢量前景，缩放更稳，也更适合 adaptive icon。

## 图标包含的元素

### 1. 外星人主体
- 作为主视觉中心
- 提升小尺寸下的辨识度

### 2. 绿色与浅绿配色
- 构成主体轮廓和头部层次
- 让图标在桌面上更醒目

### 3. 深色面部 / 眼睛区域
- 形成高对比中心焦点

### 4. 圆角背景底板
- 由 SVG 自带圆角背景直接承载
- 避免 Android 启动器再次裁切后只剩局部

## 元素与功能对应关系

| 元素 | 功能含义 |
| --- | --- |
| 外星人主体 | 强识别度的主图标形象 |
| 圆角背景 | 启动器图标完整承载面 |
| 深色面部区域 | 视觉焦点与层次感 |

## 使用的颜色

| 名称 | 色号 | 用途 |
| --- | --- | --- |
| 主绿 | `#91DC5A` | 主体轮廓 |
| 深绿 | `#4B925E` | 顶部细节 |
| 深绿暗部 | `#32623F` | 头部阴影 |
| 深色面部 | `#1E2E3B` | 面部与眼睛区域 |
| 次级深色 | `#3C5D76` | 下方结构层次 |
| 白色 | `#FFFFFF` | 面部高光 |

## 最终启动器资源路径

- 前景 VectorDrawable：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/drawable/ic_launcher_foreground.xml`
- 背景 VectorDrawable：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/drawable/ic_launcher_background.xml`
- adaptive icon：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml`

- 备用 PNG：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/drawable-nodpi/ic_pocketdesk_foreground_image.png`
- 启动器图标：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-mdpi/ic_launcher.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-hdpi/ic_launcher.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xhdpi/ic_launcher.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xxhdpi/ic_launcher.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
- 圆形启动器图标：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-mdpi/ic_launcher_round.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-hdpi/ic_launcher_round.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png`
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png`

## 备份设计资源路径

- 原图前景 XML（旧方案保留）：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/drawable/ic_pocketdesk_foreground.xml`
- 原图背景 XML（旧方案保留）：
  `/Users/pwngwc/Apkcode/ClawMemoryLocal/app/src/main/res/drawable/ic_pocketdesk_background.xml`

## 图标转换损失 / 简化说明

- 保留了源 SVG 的主体视觉
- 由于 Android VectorDrawable 不支持整套原始 SVG 的所有能力，当前只手工保留了最核心的主体形状
- 舍弃了部分细碎高光和装饰线条，但主体辨识度更高

## 后续如何修改主色

如果后面需要统一更换图标主色，优先修改：

1. `pocketdesk_icon_source.svg`
   - 如果希望整体换图或换色，优先改这个源 SVG 再重新导出 PNG
2. `ic_pocketdesk_foreground_image.png`
   - 如果只是微调显示大小，也可以直接替换这张渲染后的 PNG
