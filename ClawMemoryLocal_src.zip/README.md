# ClawMemoryLocal

ClawMemoryLocal is a local-first Android APK for text chat, daily Markdown memory notes, and an optional Qwen online mode for testing.

- Model source: `taobao-mnn/Qwen3.5-0.8B-MNN`
- The model is bundled under APK assets at `app/src/main/assets/models/Qwen3.5-0.8B-MNN/`
- On first launch, the app copies the bundled model to `context.filesDir/models/Qwen3.5-0.8B-MNN/`
- The MNN-LLM loader receives `context.filesDir/models/Qwen3.5-0.8B-MNN/config.json`
- Default mode is local MNN inference
- Optional `本地+线上` mode can call a Qwen OpenAI-compatible API after you fill in `OnlineApiConfig.kt`
- Every chat turn is saved as structured local JSON and appended to a daily Markdown note
- Daily notes are stored under `context.getExternalFilesDir(null)/ClawMemoryLocal/note/yyyy-MM-dd.md`

## Build

```sh
./gradlew assembleDebug
```

Output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## 千问 API 测试配置

本测试版的千问 API Key 写在：

```text
app/src/main/java/com/pengwc/clawmemorylocal/OnlineApiConfig.kt
```

需要修改这 3 个字段：

- `QWEN_API_KEY`
- `QWEN_BASE_URL`
- `QWEN_MODEL`

示例文件里只保留占位符，不包含真实 API Key。应用不会把 API Key 打印到日志、历史笔记、分享文件中。

## 无真机生成 GUI 截图

本项目使用 Paparazzi 生成 Jetpack Compose 界面截图。该流程不需要真机、不需要模拟器，也不会启动 APK 或初始化本地模型。

运行命令：

```sh
source ~/.zshrc
./gradlew recordPaparazziDebug
```

截图输出目录：

```text
app/src/test/snapshots/images/
```

同时会生成 HTML 报告：

```text
app/build/reports/paparazzi/debug/index.html
```

当前生成页面：

- 本地对话页：顶部控制区默认收起
- 本地对话页：顶部控制面板展开
- 历史笔记页：中文模拟日期列表
- 错误日志页：运行、模型、崩溃、性能日志模拟数据

这些截图全部使用模拟数据渲染，不依赖真实 Qwen/MNN 模型运行。

## Scope

This first version intentionally excludes Qwen API calls, Obsidian sync, camera, recording, image understanding, speech transcription, vector search, and user profiling. It only validates bundled model loading, local Qwen text chat, and daily Markdown note generation.

## Large APK Fallbacks

Plan A: keep the model bundled, but package it as an assets zip and unzip it on first launch.

Plan B: do not bundle the model; ask the user to place it at `/sdcard/Download/Qwen3.5-0.8B-MNN/`, then copy/import it into the app's internal model directory.
